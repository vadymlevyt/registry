# КОНТЕКСТ — Чат «Досьє справи»
# Legal BMS | АБ Левицького
# Дата: 09.04.2026
# Призначення: перехід з адмін-чату в чат досьє

---

## ЩО ЦЕЙ ЧАТ

Тематичний чат для модуля **CaseDossier** (Досьє справи).
Виконавець — Claude Code в Codespaces (curly-space-zebra).

Адмін-чат (цей) — архітектура і планування.
Цей чат — реалізація і фікси конкретного модуля.

---

## ПОТОЧНИЙ СТАН СИСТЕМИ

**URL:** vadymlevyt.github.io/registry/
**Репо:** github.com/vadymlevyt/registry
**Стек:** React 18 + Vite 6, GitHub Pages, GitHub Codespaces
**Модель:** Claude Code Opus 4.6, 1M context

### Що реалізовано в досьє (CaseDossier):

**Вкладка Огляд:**
- Інформація про справу (суд, номер, категорія, next_action, deadline)
- hearings[] — масив засідань (замінено hearing_date/time)
- Блок Сховище — папка справи на Drive (назва + кнопка Відкрити)
- Блок Контекст справи — кнопка "Створити контекст" (частково)
- Провадження — список проваджень справи
- Нотатки по справі — додати, редагувати, видалити, прикріпити

**Вкладка Матеріали:**
- Список документів справи (37+ документів для Брановського)
- Документи нарізані з 65-сторінкового PDF і записані на Drive

**Вкладка Робота з документами (Document Processor):**
- Завантаження PDF drag & drop або вибір файлу
- Аналіз через Claude API (document block) — один запит
- Показує структуру документів деревом у чаті
- Нарізка через pdf-lib після підтвердження
- Запис на Drive в 02_ОБРОБЛЕНІ ✅ ПРАЦЮЄ
- Матеріали оновлюються після запису ✅

**Агент досьє:**
- Sonnet — чат справа в панелі
- Знає базову інформацію про справу

---

## БАГИ ЩО ПОТРІБНО ПОФІКСИТИ

### БАГ 1 — Кнопка 📌 прикріплення нотаток (КРИТИЧНО)

**Поточна поведінка (НЕПРАВИЛЬНО):**
- Кнопка постійно червона незалежно від стану
- Не оновлюється без F5

**Потрібна поведінка (ПРАВИЛЬНО):**
- НЕ прикріплена → нахилена (-45deg) + СІРА (#666)
- Прикріплена → вертикальна (0deg) + ЧЕРВОНА (#e53935)
- Зміна відбувається ОДРАЗУ без F5

**Правильний код:**
```jsx
const isPinned = (caseData?.pinnedNoteIds || []).includes(note.id);

<button
  onClick={() => isPinned
    ? onUnpinNote(note.id, caseData.id)
    : onPinNote(note.id, caseData.id)
  }
  style={{
    background: 'none', border: 'none', cursor: 'pointer',
    fontSize: 16, padding: '2px 4px', display: 'inline-block',
    transform: isPinned ? 'rotate(0deg)' : 'rotate(-45deg)',
    color: isPinned ? '#e53935' : '#666',
    transition: 'transform 0.2s ease, color 0.2s ease',
  }}
>📌</button>
```

**Причина не оновлюється:** CaseDossier має локальний useState для caseData або notes.
Треба читати pinnedNoteIds напряму з props.caseData — тоді при setCases в App.jsx
компонент автоматично перерендериться.

Виправити в ОБОХ файлах:
- src/components/CaseDossier/index.jsx
- src/components/Notebook/index.jsx (там теж постійно червона)

### БАГ 2 — Контекстний файл не знаходить PDF

**Симптом:** "Не знайдено 02_ОБРОБЛЕНІ і 01_ОРИГІНАЛИ серед: жодної підпапки"

**Причина виявлена:** помилка OAuth — "Request had invalid authentication credentials"
Токен Drive живе ~1 годину. Після перепідключення Drive треба перевірити чи знаходить.

**Алгоритм пошуку (правильний):**
```js
// 1. Взяти folderId з caseData.storage.driveFolderId
// 2. Отримати підпапки БЕЗ фільтра по назві (кирилиця ненадійна в query)
// 3. Знайти 02_ОБРОБЛЕНІ в JS: folders.find(f => f.name === '02_ОБРОБЛЕНІ')
// 4. Якщо є — шукати файли там (mimeType != folder)
// 5. Якщо порожня — шукати в 01_ОРИГІНАЛИ
// 6. Якщо обидві порожні — повідомити
```

**Обробка протухлого токена:**
```js
if (res.status === 401) {
  showMsg('❌ Токен Drive протух. Натисніть "Підключити Drive" і спробуйте знову.');
  return;
}
```

### БАГ 3 — Редагування нотаток (можливо вже є)
Перевірити чи реалізовано редагування нотаток в досьє.
Якщо ні — додати кнопку ✏️ → textarea → Зберегти/Скасувати.

---

## ВЕЛИКИЙ TASK: АРХІТЕКТУРА ДАНИХ v3

Реалізовано Claude Code 08.04.2026 (7 пунктів за 18 хвилин):

### ✅ ЗРОБЛЕНО:

1. **hearings[]** — `hearing_date/time` замінено на масив засідань
   - Хелпери: `getNextHearing()`, `getHearingDate()`, `getHearingTime()`
   - `normalizeCase()` для міграції старих даних

2. **agentHistory** — видалено з об'єкта справи
   - Готово для окремого `agent_history.json` в папці справи

3. **pinnedNoteIds[]** — замість `pinned: boolean`
   - `pinNote(noteId, caseId)` працює через setCases

4. **notes{}** — плоский масив розділено на категорії
   - `{cases:[], general:[], content:[], system:[], records[]}`
   - Міграція старого формату реалізована
   - Notebook адаптований

5. **calendarEvents** — hearing events генеруються з hearings[] з hearingId
   - Calendar використовує `getHearingDate()`

6. **Backup** — `backupRegistryData()` в driveService.js
   - Раз на добу перед Drive sync
   - Зберігає в `_backups/`, тримає останні 7 копій

7. **case_context.md** — кнопка в досьє
   - Збирає PDF з 02_ОБРОБЛЕНІ (або 01_ОРИГІНАЛИ)
   - Відправляє в Claude Sonnet як document blocks
   - Зберігає MD на Drive
   - Архівує старі контексти

### ❌ НЕ РЕАЛІЗОВАНО (наступні кроки):

8. **institutional_memory.md** + інтерфейс в Аналізі системи
   - MD формат (не JSON)
   - Перегляд/Редагування/Завантажити/Оновити зараз
   - Кнопка ⭐ В базу знань

9. **n8n тижневий запуск Opus** о 23:00 для оновлення пам'яті

10. **Валідація повноважень в App.jsx**
    ```js
    updateCase(caseId, field, value, agentId) {
      if (!hasPermission(agentId, 'updateCase', caseId)) throw new Error();
    }
    ```

11. **Агент аналізу системи** з доступом до GitHub API

12. **Річне очищення засідань** з архівним звітом

13. **RAG** — після 2-3 місяців активного використання

---

## АРХІТЕКТУРА ДАНИХ (фінальна)

### registry_data.json:
```json
{
  "cases": [{
    "id": "case_001",
    "name": "Брановський",
    "court": "Пустомитівський районний суд",
    "case_no": "450/2275/25",
    "category": "civil",
    "status": "active",
    "next_action": "...",
    "deadline": "2026-04-10",
    "deadline_type": "hearing",
    "hearings": [{
      "id": "hrg_001",
      "date": "2026-04-15",
      "time": "10:00",
      "court": "...",
      "notes": "",
      "status": "scheduled"
    }],
    "storage": {
      "driveFolderId": "1abc...",
      "driveFolderName": "Брановський_450/2275/25",
      "lastSyncAt": "2026-04-08T23:45:00"
    },
    "documents": [{
      "id": "doc_001",
      "name": "Позовна заява",
      "type": "pleading",
      "pageCount": 7,
      "folder": "02_ОБРОБЛЕНІ",
      "driveFileId": "1xyz...",
      "addedAt": "2026-04-08"
    }],
    "pinnedNoteIds": ["note_001"]
  }],
  "calendarEvents": [{
    "id": "evt_001",
    "type": "hearing",
    "caseId": "case_001",
    "hearingId": "hrg_001",
    "title": "Засідання Брановський"
  }],
  "notes": {
    "cases": [{"id": "note_001", "caseId": "case_001", "text": "...", "ts": "..."}],
    "general": [],
    "content": [],
    "system": [],
    "records": []
  }
}
```

### Структура папки справи на Drive:
```
Брановський_450/2275/25/
├── 00_INBOX/
├── 01_ОРИГІНАЛИ/
├── 02_ОБРОБЛЕНІ/     ← 27 нарізаних PDF ✅
├── 03_ФРАГМЕНТИ/
├── 04_ПОЗИЦІЯ/
├── 05_ЗОВНІШНІ/
├── agent_history.json  ← планується
├── case_context.md     ← планується (кнопка є, фікс потрібен)
└── archive/
```

---

## ІЄРАРХІЯ АГЕНТІВ

```
Головний агент (Opus)
├── QI агент
├── Дашборд агент
├── Агент досьє
│   └── Document Processor (субагент)
├── Агент Content Hub
│   └── 4 субагенти
├── Агент аналізу системи
└── Агент ЄСІТС (в розробці)
```

### Повноваження агента досьє:
```
Читає:  свою справу повністю + інші справи по потребі
Змінює: всі поля СВОЄЇ справи крім storage{}
        notes.cases[] своєї справи
        pinnedNoteIds[] своєї справи
        documents[] своєї справи
        agent_history.json автоматично
        створює нові справи
НЕ може: видалити справу
         змінювати storage{}
         змінювати дані ІНШИХ справ
```

---

## ТЕХНІЧНІ ПРАВИЛА

1. Завжди гілка main — не окремі гілки
2. Після merge — перевіряти дублікати і мертвий код
3. Blank page = необроблена JS помилка → try/catch скрізь
4. Апострофи в українському тексті → подвійні лапки
5. API ключ в компоненті → читати з localStorage напряму
6. TASK.md в репо → один файл, перезаписується
7. Drive — НІКОЛИ не фільтрувати по кирилиці в query
   Отримати всі підпапки → знайти в JS: `folders.find(f => f.name === '02_ОБРОБЛЕНІ')`
8. pinnedNoteIds читати з props.caseData — не з локального useState

---

## ПОРЯДОК РОБОТИ В ЦЬОМУ ЧАТІ

1. Спочатку пофіксити баги 1-3 (кнопка + контекст + редагування)
2. Потім тестування всього що зроблено в великому TASK
3. Далі реалізація пунктів 8-13 з великого TASK

Workflow:
- Обговорення → TASK.md → завантажити в репо →
  `claude` в терміналі Codespaces → перевірити на сайті
