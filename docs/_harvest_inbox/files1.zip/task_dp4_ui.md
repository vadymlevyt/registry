# TASK DP-4 — UI Document Processor v2 з 4 зонами, 7 перемикачами, фоновою обробкою

**Дата постановки:** 18.05.2026
**Тип:** Великий UI TASK (4 зони + перемикачі + topbar активація + 3 додаткові точки індикації ECITS + швидкі функції + ME Фаза 1)
**Передумова:** DP-1, DP-2, DP-3 завершено і у main
**Очікуваний час:** 10-14 годин (один великий TASK без розбиття на 4a/4b)
**Сесія:** ОКРЕМА свіжа сесія Claude Code

---

# ⚠️ КРИТИЧНО — ЦЕ ПЕРША ЗУСТРІЧ АДВОКАТА З НОВИМ DP

Підготовчі TASK 1-5 + DP-1, DP-2, DP-3 створили **фундамент**. Уся інфраструктура працює, але **адвокат її не бачить** — нема UI. DP-4 робить інфраструктуру **видимою і робочою**.

Це **визначальний момент** для:
- Першого враження адвоката від нового pipeline
- Реальної перевірки чи архітектура streaming/Web Worker працює на реальному пристрої
- Перевірки чи 4 зони UI дійсно зручні в реальному використанні

**Якщо UI зроблено правильно — адвокат відразу починає використовувати новий DP.** Якщо є фрикції — повертається до старих звичок.

Усі рішення UI вже встановлені обговореннями і мокапами. Цей TASK — їх **точна реалізація**, не переосмислення.

---

# ⚠️ ДИЗАЙН-ДИСЦИПЛІНА — НЕ ВІДСТУПАТИ

## Тільки CSS токени з `tokens.css` — НІЯКИХ inline стилів

Це жорстка дисципліна Legal BMS. Усі кольори, spacing, шрифти, тіні — **тільки через CSS змінні** з `tokens.css`. Inline `style={{ color: '#ff0000' }}` — заборонено. Inline `style={{ padding: '16px' }}` — заборонено. Усе через класи CSS.

**Палітра з tokens.css:**
- `--bg #0f1117` фон сторінки
- `--surface #191c27` фон карток і модалок
- `--border #2d3250` бордюри
- `--text #a8b3cf` основний текст
- `--text2 #6b7693` другорядний текст
- `--accent #3b82f6` акцент
- `--green #22c55e` успіх
- `--orange #f59e0b` попередження
- `--red #ef4444` помилка
- `--gold #e6b450` ключові документи

**Колір проваджень:**
- Перша інстанція — `--green`
- Апеляція — `--accent`
- Касація — `--yellow`
- Без провадження — `--text2`

**Шрифти:**
- `Manrope` (200-800) — тіло
- `Unbounded` (400-700) — заголовки

**Spacing шкала:** 4-8-12-16-20-24-32-40-48 (тільки ці значення)

**Радіуси:** 4 / 6 / 8 / 12px (тільки ці)

## Іконки — `lucide-react`, НЕ emoji

Усі інтерфейсні іконки — з бібліотеки `lucide-react`. Emoji дозволені **тільки** для стану і атмосфери: `⭐` (ключовий), `⚠` (потребує перегляду), `🔧` (інструмент у заголовку), `⤴ ⬇` (стрілки у меню), `📋` (буфер), `📤` (експорт), `🤖` (агент), `⟳` (оновити).

Для всіх дій — `lucide-react`: `Upload`, `Settings`, `FileText`, `AlertCircle`, `Check`, `X`, `Edit`, `MessageCircle`, `Trash`, `Download`, `Copy`, `Send`, `Loader`, `ChevronRight`, тощо.

**ЗАБОРОНЕНО** додавати emoji як заміну іконок. Якщо в існуючому коді знайдеш emoji — мігруй на lucide (TASK 7 уже зробив базову міграцію, але можуть бути залишки).

## Inline редагування vs модалки

**Створення нового елемента** → модалка з фірмовими компонентами Modal/Input/Select
**Редагування існуючого** → inline (клік → редаговане поле → blur/Enter зберігає)

Усі модалки фірмові — НЕ `window.alert`/`confirm`/`prompt`.

## Responsive design

Інтерфейс має працювати на:
- Десктоп (1920×1080+)
- Планшет горизонтально (1280×800)
- Планшет вертикально (800×1280)
- Телефон (мінімально 360×640)

Використовувати CSS Grid/Flexbox + `@media` queries з токенів. **НЕ JavaScript-based responsive**.

---

# ЕКСПЕРТНА АВТОНОМІЯ

## Принцип

Ти бачиш код напряму. Адміністративний Claude бачить його через звіт. Дизайн-рішення і структура встановлені (4 зони, 7 перемикачів, вкладки, мокапи), але **імплементація** — твоя зона експертизи.

## Коли діяти автономно

- Кращі імена CSS класів і React компонентів
- Чистіша інтеграція з існуючим компонентами Button/Input/Select/Chip/Card/Modal/Tabs/Toggle/Tooltip
- Edge case у responsive поведінці (наприклад дуже вузький екран)
- Косметичні фікси у scope (мертвий код, неконсистентні coments)
- Краща структура файлів (наприклад розбити DocumentProcessorV2.jsx на під-компоненти)

У звіті обов'язково поясни що зробив інакше і чому.

## Коли підіймати прапор ДО реалізації

- Запропонована UI структура має technical edge case (наприклад streamingExecutor не інтегрується чисто з UI як я описую)
- Існуючий компонент який треба використати має обмеження що блокує реалізацію
- Дизайн-рішення суперечать існуючому UI Legal BMS (наприклад я пропоную те що не відповідає поточним патернам)
- Є кращий UX патерн якого я не врахував у мокапах

У всіх таких випадках — зупинись і запитай ДО реалізації.

## Особливо важливо для DP-4

- Behavior-preserving для AddDocumentModal — single-file flow **не торкається**
- Streaming infrastructure (DP-3) **підключається через монтування у App.jsx**, не переробляється
- Топбар (DP-3) вже працює — DP-4 додає **повноекранний прогрес-екран** і UI взаємодії
- Усі ACTIONS вже існують з TASK 5 (`createActions(deps)`) — НЕ переробляти, тільки використовувати
- Усі швидкі функції (`standaloneCompressor`, `runOcrWithRetryUI`) вже є з DP-3 — тільки додати UI обгортку

---

# HANDOFF-БЛОК

## 1. Обов'язкове читання перед стартом (повне дослідження, не міні-аудит)

У цьому порядку, до будь-якої зміни:

### Архітектура і філософія
- `CLAUDE.md` (корінь) — архітектура, критичні правила
- `DEVELOPMENT_PHILOSOPHY.md` (корінь) — філософія розробки, "ембріон з повним ДНК", тонкі диригенти, AI-first
- `docs/audits/audit_before_dp1_v2.md` — аудит перед DP-1 (для розуміння системи)
- `docs/consultations/discussion_dp_v2_philosophy_response.md` — філософське рішення по архітектурі DP v2

### Звіти попередніх TASK
- `docs/reports/report_task_dp1_pipeline.md` — структура pipeline, точки розширення
- `docs/reports/report_task_dp2_archives_ecits.md` — stageOverrides патерн, ecitsInboxWatcher
- `docs/reports/report_task_dp3_streaming_reconstruction.md` — streaming, Web Worker, resume, Topbar
- Звіти підготовчих TASK 1-5 (для розуміння спадщини)

### UI/UX мокапи і дизайн-рішення (КРИТИЧНО — це УВЕСЬ ВІЗУАЛЬНИЙ КОНТРАКТ)
Якщо є у проектних знаннях:
- `dossier_ui_mockups.md` — ASCII-mockup'и інтерфейсу модуля Досьє включно з Document Processor. **БЛОК 1** — Design System, **БЛОК 7** — Document Processor (фінальна версія). Усі візуальні рішення (зони, перемикачі, вкладки, кнопки) — звідси
- `dossier_architecture_decisions.md` — архітектурні рішення UI (CSS токени, Inline vs Modal, зв'язок документ↔провадження↔дерево)
- `dp_v2_functionality_reference.md` — повний довідник функціоналу DP v2 (розділ 4 — Інтерфейс 4 зони)

Якщо файлів немає у проектних знаннях — зафіксуй у звіті і працюй з тим що тут описано.

### Існуючий код Legal BMS
- `src/styles/tokens.css` — повна палітра CSS змінних. **Усе нове CSS — звідси**
- `src/components/CaseDossier/AddDocumentModal.jsx` — приклад фірмової модалки на токенах (зразок)
- `src/components/CaseDossier/index.jsx` — поточна структура CaseDossier, де вкладка "Робота з документами"
- Базові UI компоненти `src/components/ui/` — Button, Input, Select, Chip, Card, Modal, Tabs, Toggle, Tooltip
- `src/components/JobProgressTopbar/` — створено у DP-3, **активується у DP-4**
- `src/services/documentPipeline/streamingExecutor.js` — координатор обробки, **активується у DP-4** через монтування у App.jsx

## 2. Зафіксувати baseline першою дією

До будь-якої зміни коду:

```
npm install
npm test           → записати Test Files / Tests
npm run build      → підтвердити що зелений
```

Це baseline для §9 acceptance. Будь-яка регресія — блокер.

## 3. Повноцінний аудит перед будь-якою зміною

**Це УЇЇ TASK з підвищеним ухилом на UI/дизайн. Mini-аудит недостатній.**

Витрать стільки часу на дослідження скільки потрібно. Не обмежуй себе. Конкретно потрібно:

### 3.1 UI-аудит — поточний стан

- **Структура CaseDossier:** яка вкладка зараз називається "Робота з документами", де поточний DocumentProcessor (якщо лишився рудимент), як інтегрований AddDocumentModal
- **Шапка справи:** які кнопки/елементи зараз, де додати "Бейдж INBOX" банер для ECITS
- **Реєстр справ (`CaseRegistry.jsx`):** структура рядка справи, куди додати індикатор `[🔔 N]`
- **Дашборд (`Dashboard.jsx`):** структура секцій, куди додати "Нові надходження з ЄСІТС"
- **App.jsx:** як зараз монтується топбар з DP-3, де додати `streamingExecutor` монтування

### 3.2 Дизайн-аудит — поточний стан tokens.css

- Які класи вже існують для аналогічних UI елементів (drop zone, toggle row, tab, badge)
- Які `--color-*-bg-soft` alpha-токени потрібні (з tracking_debt)
- Чи є патерн для прогрес-бара (потрібно для Зони 4 повноекранного прогрес-екрану)
- Що відсутнє і треба додати у tokens.css

### 3.3 Інтеграція streaming — як підключається

- Як `streamingExecutor` має монтуватись у App.jsx (через React Context чи прокидання через props)
- Як `ecitsInboxWatcher` підписується на eventBus і викликає `streamingExecutor.run()`
- Як `JobProgressTopbar` підключається до `jobProgressStore` (вже працює — звірити)
- Як повноекранний прогрес-екран інтегрується з `jobProgressStore`

### 3.4 Швидкі функції — як обгорнути

- `standaloneCompressor.js` (з DP-3) — який API, які параметри потрібні для UI обгортки
- OCR pipeline для "Розпізнати текст" — чи є готовий `runOcrWithRetryUI` helper, як його використати

Тільки після цього — план реалізації.

## 4. Що зробити (суть DP-4)

### 4.1 Активація streaming infrastructure у App.jsx

**Зараз** `streamingExecutor` створений у DP-3 але не вмонтований. У DP-4:

- Створити **React Context** `DocumentPipelineProvider` який тримає `streamingExecutor` як інстанс
- Монтувати у `App.jsx` поряд з іншими провайдерами (`TenantProvider`, `ActionsProvider`)
- Передавати `executor` через context у компоненти DP UI
- Підключити `ecitsInboxWatcher` через eventBus → `executor.run(input)` (auto-режим) або індикатори (manual-режим)
- Підключити `attachDrivePolling` для resume сценаріїв

**Інваріант:** streaming працює тільки коли вмонтовано. Без UI — інфраструктура спить, тести зелені.

### 4.2 Повний UI Document Processor v2 (заміна вкладки "Робота з документами" у CaseDossier)

**Файл:** `src/components/DocumentProcessorV2/index.jsx` + підкомпоненти

**Структура — 4 зони:**

#### Зона 1 — Вхідна

```jsx
<DropZoneArea>
  <DropZone /> {/* drag-n-drop файлів */}
  <FilePickerButton icon={<Upload />}>Вибрати файли</FilePickerButton>
  <DrivePickerButton icon={<FolderOpen />}>З Google Drive</DrivePickerButton>
  
  <InboxList /> {/* список 00_INBOX/ файлів з checkbox'ами */}
</DropZoneArea>
```

- Drag-n-drop через стандартні HTML drag events
- File picker — `<input type="file" multiple>` приховано, кнопка тригерить
- Drive picker — використати існуючий компонент (TASK 4.1 з підготовчих)
- Inbox list — читає з `case.driveFolderId/00_INBOX/`, дозволяє вибрати які файли обробляти
- Підтримує формати: PDF, JPG, PNG, HEIC, DOCX, XLSX, PPTX, RTF, ODT, TXT, MD, ZIP, RAR, 7z
- При додаванні нових файлів коли в INBOX вже є — показати модалку вибору (з мокапу):
  - "Додати до існуючих, обробити все разом"
  - "Обробити тільки нові, файли в INBOX залишити"
  - "Просто залишити в INBOX, повернутись пізніше"

#### Зона 2 — Налаштування (8 перемикачів)

```jsx
<SettingsArea>
  <SettingsSection title="ОРГАНІЗАЦІЯ">
    <Toggle label="Розкласти по провадженнях" defaultChecked />
    <Toggle label="Перевірка цілісності перед обробкою" defaultChecked />
  </SettingsSection>
  
  <SettingsSection title="ЯКІСТЬ ТЕКСТУ">
    <Toggle label="Очистити для читання" defaultChecked />
    <Toggle label="Згенерувати короткий зміст" defaultChecked />
  </SettingsSection>
  
  <SettingsSection title="ДОДАТКОВІ ДІЇ">
    <Toggle label="Стиснути всі файли пакета" />
    <Toggle label="Запропонувати дедлайни з документів" />
    <Toggle label="Оновити case_context.md" defaultChecked />
    <Toggle label="Заповнити картку справи з документів" />
  </SettingsSection>
  
  <SettingsPreview>
    ~5-7 хвилин · ~$0.30
  </SettingsPreview>
  
  <Button primary onClick={handleStart} icon={<Play />}>
    Розпочати обробку {selectedCount} документів
  </Button>
</SettingsArea>
```

**Перелік 8 перемикачів** (з дефолтами):

1. **Розкласти по провадженнях** — `ВКЛ`
2. **Перевірка цілісності перед обробкою** — `ВКЛ`
3. **Очистити для читання** (через Haiku) — `ВКЛ`
4. **Згенерувати короткий зміст** (200-500 символів для tooltip) — `ВКЛ`
5. **Стиснути всі файли пакета** (`compressAllFiles` config з DP-3) — `ВИМК`
6. **Запропонувати дедлайни з документів** — `ВИМК`
7. **Оновити case_context.md** — `ВКЛ`
8. **Заповнити картку справи з документів** — `ВИМК`

**Розрахунок часу і вартості:**
- Базується на кількості файлів і їх розмірі
- Грубо: 1 хв + 30 сек/файл + $0.05/файл
- Точна формула — можеш вирахувати з історії chunkDurationsMs (якщо є) або жорстко закодувати приблизну оцінку

**Кнопка "Розпочати":**
- Тільки активна якщо вибрано хоч один файл (з drop zone або INBOX)
- Викликає `streamingExecutor.run(input, options)` де `options` — стан перемикачів
- Після натиску — Зона 4 (прогрес) активна, Зона 3 готова приймати результат

#### Зона 3 — Аналіз і результат (3 вкладки)

```jsx
<ResultsArea>
  <Tabs>
    <Tab id="tree">Дерево</Tab>
    <Tab id="cutting">Нарізка</Tab>
    <Tab id="attention" badge={attentionCount}>Потребує уваги</Tab>
  </Tabs>
  
  <TabContent id="tree">
    {/* ЗАГЛУШКА до DP-6 */}
    <Placeholder>
      Дерево проваджень буде доступне після DP-6 (категоризація справи і шаблони).
      Зараз показуємо плоский список нарізаних документів.
    </Placeholder>
    <DocumentList documents={results.documents} />
  </TabContent>
  
  <TabContent id="cutting">
    <CuttingView documents={results.documents} unusedPages={results.unusedPages} />
  </TabContent>
  
  <TabContent id="attention">
    <AttentionSection title="Питання" items={results.decisions} />
    <AttentionSection title="Помилки" items={results.errors} />
    
    {(results.decisions.length > 0 || results.errors.length > 0) && (
      <ActionButtons>
        <Button onClick={resolveAll}>Вирішити всі питання підряд</Button>
        <Button secondary onClick={leaveForLater}>Залишити на потім</Button>
      </ActionButtons>
    )}
  </TabContent>
</ResultsArea>
```

**Вкладка "Дерево":** заглушка до DP-6. Показуємо просто список нарізаних документів без drag-n-drop між провадженнями. Повний інтерактивний UI (ProceedingForm Inline mode, перенесення документів) — у DP-6 разом з шаблонами проваджень.

**Вкладка "Нарізка":** показує план реконструкції:
- Список логічних документів з назвами, типами, межами сторінок
- Для кожного — кнопки `[Стиснути]` `[Розділити]` `[Об'єднати з...]`
- Список невикористаних сторінок (`unusedPages[]` з DP-3) з причинами
- Опція "Зберегти фрагменти у 03_ФРАГМЕНТИ" (галочка, дефолт ВКЛ)

**Вкладка "Потребує уваги":** об'єднана для питань і помилок:
- **Розділ "Питання"** — з `decisions[]`, кожен з варіантами вибору (кнопки)
- **Розділ "Помилки"** — з `errors[]` де `file_skipped: true`, з причинами і опціями (переробити, пропустити, виправити)
- Кнопки "Вирішити всі підряд" і "Залишити на потім"

#### Зона 4 — Прогрес і логи

**Це повноекранний прогрес-екран** який зараз у DP-3 заглушка-модалка. У DP-4 повна реалізація:

```jsx
<ProgressFullScreen>
  <Header>
    <CaseInfo>Брановський проти Іванова — 824/22-ц</CaseInfo>
    <CloseButton onClick={minimize}>{/* згорнути у topbar */}</CloseButton>
  </Header>
  
  <OverallProgress percent={overallPercent} eta={remainingMs}>
    Опрацьовано {processedDocs} з {totalDocs} документів
  </OverallProgress>
  
  <FileList>
    {files.map(file => (
      <FileRow status={file.status}>
        {file.status === 'done' && <CheckIcon />}
        {file.status === 'processing' && <LoaderIcon spin />}
        {file.status === 'needs_review' && <AlertIcon />}
        {file.status === 'error' && <XIcon />}
        <FileName>{file.name}</FileName>
        <ChunkProgress current={file.currentChunk} total={file.totalChunks} />
      </FileRow>
    ))}
  </FileList>
  
  <CurrentChunkDetails>
    Поточний chunk: сторінки {chunk.startPage}-{chunk.endPage} файлу {chunk.fileName}
  </CurrentChunkDetails>
  
  <Actions>
    <Button danger onClick={cancel}>Скасувати</Button>
    <Button secondary onClick={minimize}>Згорнути</Button>
  </Actions>
</ProgressFullScreen>
```

**Інтеграція з jobProgressStore (DP-3):**
- Підписується на стор через React hook
- Показує реальний прогрес з postMessage Worker (миттєво) + polling Drive 5с (fallback)
- ETA через `estimateRemainingMs` з `streamingExecutor`
- Згортання → іде у `JobProgressTopbar` (DP-3 готовий)
- Натиск на topbar → відкриває цей екран знову (повертається у CaseDossier тієї справи → DP вкладка → повноекранний прогрес)

**Скасування:**
- Викликає `streamingExecutor.cancel(jobId)`
- Якщо є готові документи — модалка "У вас N готових документів. Зберегти їх чи видалити все?" (логіка `keepPartial`/`discardAll` з DP-3 готова)

### 4.3 Швидкі функції — кнопки у заголовку DP

**Не tabs, не бічна панель, не floating** — кнопки у заголовку поряд з "🔧 Робота з документами" (Варіант 1 за рішенням).

```jsx
<DPHeader>
  <Title icon={<Wrench />}>Робота з документами</Title>
  <QuickActions>
    <Button icon={<FileText />} onClick={openRecognizeText}>Розпізнати текст</Button>
    <Button icon={<FileArchive />} onClick={openCompressFile}>Стиснути файл(и)</Button>
  </QuickActions>
</DPHeader>
```

**"Розпізнати текст":**
- Модалка `RecognizeTextModal`
- Вхід: один файл (drop zone або file picker)
- Виклик готового OCR pipeline без повного DP
- Результат: текст у модальному viewer з кнопками `[Зберегти у справу як документ]` `[Зберегти на пристрій (.txt)]` `[Скопіювати у буфер]` `[Закрити без збереження]`

**"Стиснути файл(и)":**
- Модалка `CompressFilesModal`
- Вхід: один або декілька файлів
- Виклик `standaloneCompressor.compressFiles()` з DP-3
- Опції куди зберегти результат:
  - "Зберегти у поточну справу (`01_ОРИГІНАЛИ/`)"
  - "Зберегти на пристрій (downloads)"
  - "Зберегти у іншу папку Drive" (через Drive picker)
  - "Надіслати email" (заглушка `not_implemented` з DP-3)
  - "Надіслати в messenger" (заглушка)

### 4.4 ECITS UI — три точки індикації нових надходжень

**Загальна логіка:**
- `ecitsInboxWatcher` (DP-2) монтується у App.jsx
- Слухає eventBus подію `ECITS_DOCUMENTS_RECEIVED`
- При надходженні:
  - Якщо `tenant.settings.ecitsAutoProcess === 'auto'` → автоматично запускає `streamingExecutor.run()` (UI показує що іде обробка)
  - Якщо `'manual'` (дефолт) → оновлює стан `inboxCount` для UI індикаторів

**Точка 1 — Бейдж у CaseDossier (банер зверху):**

```jsx
{inboxCount > 0 && (
  <ECITSBanner>
    <BanerIcon icon={<Mail />} />
    <BannerText>В INBOX {inboxCount} нових файлів від Court Sync</BannerText>
    <BannerActions>
      <Button onClick={openDPTab}>Обробити</Button>
      <Button secondary onClick={viewList}>Дивитись список</Button>
    </BannerActions>
  </ECITSBanner>
)}
```

**Точка 2 — Індикатор у Реєстрі справ:**

```jsx
<CaseRow>
  <CaseName>{case.name}</CaseName>
  {case.inboxCount > 0 && (
    <Badge color="warning" icon={<Mail />}>
      {case.inboxCount}
    </Badge>
  )}
  {/* інші колонки */}
</CaseRow>
```

Сортування реєстру можна додати: "Спочатку справи з новими надходженнями" (опційно якщо просто).

**Точка 3 — Секція у Дашборді:**

```jsx
{casesWithInbox.length > 0 && (
  <DashboardSection title="Нові надходження з ЄСІТС" icon={<Mail />}>
    <CaseList>
      {casesWithInbox.map(case => (
        <CaseRow>
          <CaseName>{case.name}</CaseName>
          <FileCount>{case.inboxCount} нових</FileCount>
          <Button onClick={() => openCase(case.id)}>Обробити</Button>
        </CaseRow>
      ))}
    </CaseList>
  </DashboardSection>
)}
```

### 4.5 Custom Splitter dataset — toggle і дисклеймер

У налаштуваннях DP або у Tenant Settings — окремий розділ:

```jsx
<DatasetSettings>
  <Toggle 
    label="Накопичувати приклади нарізки для тренування власної моделі"
    checked={splitterDatasetEnabled}
    onChange={toggleSplitterDataset}
  />
  
  {splitterDatasetEnabled && (
    <Counter>Поточний обсяг: {datasetCount} прикладів</Counter>
  )}
  
  <Disclaimer>
    {/* повний текст дисклеймера з DP-3 §8 звіту */}
  </Disclaimer>
</DatasetSettings>
```

Перемикач читає/пише `tenant.settings.splitterDatasetEnabled` через `getSplitterDatasetEnabled()`/відповідний setter.

### 4.6 ME Фаза 1 — точка входу "Записати без файлу"

**ВІДКЛАДЕНО** — за рішенням засновника. Не реалізовуємо у DP-4. Переноситься у ME-MVP Фазу 2 (Q3 2026) або раніше окремим TASK якщо знадобиться. У DP-4 **НЕ робимо**.

(Якщо handoff від адміна каже про це — це застаріла інформація. Перевірити роадмап `roadmap_full_2026-05-14.md`.)

### 4.7 Модалка "Дублікат" і `unusedPages` обробка

Коли pipeline знаходить дублікат або має невикористані сторінки — на вкладці "Потребує уваги" з'являється запис з варіантами:

**Дублікат:**
```
Документ "позов_15-04.pdf" схожий на існуючий "Позовна_заява_15-04-2024.pdf"
[Замінити]  [Додати як другий варіант]  [Скасувати додавання]
```

**Невикористані сторінки:**
```
3 сторінки не використано:
- Сторінка 4 з "том_1.pdf" — порожня
- Сторінка 9 з "том_1.pdf" — обривок
- Сторінка 3 з "пакет.pdf" — фотокопія

[Зберегти у 03_ФРАГМЕНТИ]  [Видалити]  [Переглянути кожну]
```

### 4.8 Адаптивний дизайн

**Перевірити на:**
- Десктоп (1920×1080+) — повний layout
- Планшет горизонтально (1280×800) — 4 зони вертикально як на десктопі
- Планшет вертикально (800×1280) — 4 зони послідовно (drop zone зверху, налаштування, результат, прогрес внизу)
- Телефон (360×640) — мінімально, не критично але не повинно ламатись

**Inbox banner і badge** — компактні на маленьких екранах.

**Швидкі функції у заголовку** — на маленьких екранах можуть переходити у dropdown ⋯.

## 5. Інваріанти — не порушувати

- **Тільки CSS токени з tokens.css** — нуль inline стилів
- **Іконки lucide-react** — нуль emoji крім дозволених (⭐ ⚠ 🔧 ⤴ ⬇ 📋 📤 🤖 ⟳)
- **Behavior-preserving для AddDocumentModal** — single-file flow не зачіпається
- **executeAction для всіх змін даних** — нічого напряму у state чи Drive повз шар
- **Streaming infrastructure НЕ переробляти** — тільки активувати через монтування у App.jsx
- **DP-1 диригент НЕ торкається** — все через stageOverrides + executor (вже зроблено у DP-3)
- **Топбар DP-3 НЕ переробляти** — тільки повноекранний прогрес-екран додається
- **Усі стани UI рендеряться з реальних даних** — нуль hardcoded preview
- **Responsive через CSS** — не JavaScript-based screen detection

## 6. Стан репо на старті

main HEAD містить TASK 1-5 + DP-1 + DP-2 + DP-3.

**Готові сервіси для UI:**
- `streamingExecutor.js` — координатор, треба змонтувати
- `jobProgressStore.js` — стор для прогрес-індикаторів
- `JobProgressTopbar` — компонент топбару, працює
- `ecitsInboxWatcher.js` — watcher, треба змонтувати
- `standaloneCompressor.js` — компресор для "Стиснути файл(и)"
- `datasetCollector.js` — збирач, поле `splitterDatasetEnabled` готове
- `documentBoundary/` — повна семантична нарізка
- Усі стадії pipeline через stageOverrides
- `tenant.settings.ecitsAutoProcess`, `splitterDatasetEnabled`, `compressAllFiles` (config)

**Що НЕ існує і має створитись:**
- `src/components/DocumentProcessorV2/` — повна папка з компонентами
- `src/components/ECITSBanner/` — банер для CaseDossier
- `src/components/RecognizeTextModal/`, `src/components/CompressFilesModal/`
- `src/components/ProgressFullScreen/` — повноекранний прогрес
- Інтеграція DPv2 у CaseDossier (замінює існуючу вкладку "Робота з документами")
- Інтеграція ECITS індикаторів у CaseRegistry, Dashboard
- Монтування `streamingExecutor` і `ecitsInboxWatcher` у App.jsx через Context

## 7. Правило #1 — гілка і push

Розробка на гілці `claude/*`. Push в main — тільки після зведення змін і підтвердження адвоката. Тільки чистий fast-forward, тільки при зелених тестах.

## 8. Чого НЕ робити

- НЕ використовувати inline стилі (`style={{}}`) — все через CSS токени
- НЕ використовувати emoji як іконки — тільки lucide-react
- НЕ переробляти streaming infrastructure (DP-3) — тільки активувати
- НЕ робити заглушки які потім доведеться переписувати — використовуй патерн stageOverrides
- НЕ реалізовувати "Записати без файлу" (ME Фаза 1 відкладена)
- НЕ робити інтерактивний UI ProceedingForm для Зони 3 Дерево (це DP-6)
- НЕ обходити executeAction
- НЕ створювати глобальні сінглтони — DI через React Context
- НЕ міняти AddDocumentModal flow — він працює як працює
- НЕ створювати нові .md у корені — звіти у `docs/reports/`
- НЕ використовувати `window.alert/confirm/prompt` — тільки фірмові модалки
- НЕ пушити в main без підтвердження адвоката

## 9. Acceptance criteria

- [ ] `streamingExecutor` змонтований у App.jsx через React Context
- [ ] `ecitsInboxWatcher` змонтований і слухає eventBus
- [ ] `JobProgressTopbar` (DP-3) показує реальний прогрес при активній обробці
- [ ] **Зона 1 Вхідна** — drop zone, file picker, Drive picker, INBOX list працюють
- [ ] **Зона 2 Налаштування** — 8 перемикачів з правильними дефолтами, розрахунок часу/вартості, кнопка "Розпочати"
- [ ] **Зона 3 Аналіз і результат** — 3 вкладки (Дерево заглушка, Нарізка повна, Потребує уваги з 2 розділами)
- [ ] **Зона 4 Прогрес** — повноекранний прогрес-екран замінює заглушку-модалку DP-3, інтегрований з jobProgressStore
- [ ] **Скасування з вибором** — модалка "зберегти N готових чи видалити все"
- [ ] **Швидкі функції** — кнопки "Розпізнати текст" і "Стиснути файл(и)" у заголовку DP, модалки з повним UI
- [ ] **ECITS Банер у CaseDossier** — показує коли є файли в INBOX
- [ ] **ECITS Індикатор у Реєстрі справ** — `[🔔 N]` біля справи
- [ ] **ECITS Секція у Дашборді** — список справ з новими надходженнями
- [ ] **Custom Splitter toggle** — у налаштуваннях DP або Tenant Settings з дисклеймером
- [ ] **CSS токени** — нуль inline стилів у новому коді
- [ ] **Іконки** — lucide-react, без emoji крім дозволених
- [ ] **Responsive** — працює на десктопі, планшеті горизонтально/вертикально, телефоні мінімально
- [ ] **AddDocumentModal flow без регресій** — single-file сценарій працює як раніше
- [ ] **Юніт-тести** на нові компоненти
- [ ] **Інтеграційні тести** — повний DP flow (вибрати файл → налаштувати → запустити → отримати результат)
- [ ] **`npm test`** — кількість тестів не менша за baseline
- [ ] **`npm run build`** — зелений
- [ ] **Звіт** `docs/reports/report_task_dp4_ui.md`
- [ ] **Зведення показано адвокату; push у main після підтвердження**

## 10. Структура звіту

Файл `docs/reports/report_task_dp4_ui.md` зі структурою:

1. **Baseline зафіксований** (точні числа)
2. **Дослідження** — що читав з мокапів/архітектурних рішень, на чому базував UI
3. **UI-аудит поточного стану** — що знайдено в CaseDossier, Registry, Dashboard, App.jsx
4. **Дизайн-аудит tokens.css** — які класи додано/розширено
5. **Структура файлів** — нові компоненти, їх ієрархія, інтеграція
6. **Активація streaming у App.jsx** — як змонтовано, який Context, як ecitsInboxWatcher підписаний
7. **Зона 1 (Вхідна)** — структура, drop zone, Drive picker, INBOX list
8. **Зона 2 (Налаштування)** — 8 перемикачів, дефолти, розрахунок часу/вартості
9. **Зона 3 (Результат)** — 3 вкладки, обробка decisions/errors
10. **Зона 4 (Прогрес)** — повноекранний екран, інтеграція з jobProgressStore
11. **Швидкі функції** — RecognizeTextModal, CompressFilesModal
12. **ECITS UI** — банер, індикатор реєстру, секція дашборду
13. **Custom Splitter UI** — toggle, дисклеймер
14. **Responsive поведінка** — як виглядає на різних розмірах
15. **Файли створені/видалені/модифіковані** — повний перелік
16. **Тести** — baseline / після, нові тести
17. **Відхилення від handoff** з поясненнями (експертна автономія)
18. **Що свідомо лишено для DP-5/DP-6** — точки розширення
19. **Acceptance criteria** — статус кожного пункту
20. **tracking_debt** — побічні знахідки якщо є
21. **Підтвердження** — нуль inline стилів, нуль emoji-іконок, behavior-preserving AddDocumentModal, диригент незмінний, executeAction незмінний, streaming infrastructure не переробляється

---

**DP-4 — момент коли адвокат вперше бачить новий Document Processor у дії. Усі підготовчі сервіси готові, streaming працює, залишилось дати йому правильний UI з дизайн-дисципліною Legal BMS.**

**Дякую за уважність до дизайн-деталей і архітектурну дисципліну.**
