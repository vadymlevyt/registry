# КОНТЕКСТ — модуль Досьє, передача стану

**Дата:** 14.05.2026
**Призначення:** стартовий файл для нового чату по досьє
**Заміщує:** `context_dossier_session_2026-05-12.md`

---

## Що завершено за дві сесії 12–13.05.2026

### TASK A — Конвертація форматів у PDF у AddDocumentModal ✅
Створено сервісну інфраструктуру в `src/services/`:
- `converter/` — фасад `converterService.js` + модулі для DOCX, HTML, image, HEIC
- `sortation/` — `imageSortingAgent` (семантичне сортування), `orientationCorrector`

AddDocumentModal — лайт-варіант Document Processor для одного документа. DOCX зберігає оригінал + PDF у 01_ОРИГІНАЛИ. HTML і зображення — тільки PDF. Тонка обгортка через фасад — Document Processor v2 потім використає ті самі сервіси без переписування.

### TASK B — Склейка зображень з повним UX ✅
- `multiImageToPdf` склейка кількох зображень у один PDF (як iPhone)
- Multi-select зображень у Drive File Picker
- Дві кнопки на старті AddDocumentModal: "📄 Додати файл" / "🖼 Склеїти зображення"
- Семантичне сортування агентом + дедуплікація (підтверджено на 10 фото з кількох джерел)
- Crop editor у попапі: кнопки ✂️ обрізки і ▣ Рамка, centering через CSS transform, попап 72×80vw/vh
- **Straighten slider** −45°/+45° крок 0,5° з real-time обертанням через `cropper.rotateImage()`
- Re-edit support (повторне відкриття зберігає правки)
- Layout.json у merge сценарії теж створюється (виправили баг — `pageStructure` тепер у return `extractText`)
- Single file UX — пропонує перейти у "Додати файл" замість запуску pipeline
- Кольорові витяги склеюються

### Orientation cascade — фінальна версія ✅
5-крокковий каскад, БЕЗ aspect ratio fallback (50/50 ймовірність зробити гірше):
1. EXIF orientation
2. `page.transforms` (афінні матриці)
3. **`blocks[].orientation`** з Document AI — основний метод (>60% dominant)
4. `page.orientation` fallback
5. NONE → НЕ обертати, показати warning

Семантика: PAGE_UP→0°, PAGE_RIGHT→270° CW, PAGE_DOWN→180°, PAGE_LEFT→90° CW.

### Slider React crash — критичний фікс ✅
Виявили DOM `insertBefore` crash при 50+ updates/sec через React reconciliation. Slider винесено **повністю поза React state** (uncontrolled через ref, label через `textContent`, видимість через CSS class toggle). Класична техніка Apple Photos / Google Photos.

### PR #41 (мерж) — debug toast ізоляція ✅
Debug toast у `ImageMergePanel` ламав робочий pipeline через застарілі поля `analyzeBlockGeometry`. Тепер у try/catch — діагностика ніколи не повинна валити основну функцію. Single JPG у 01_ОРИГІНАЛИ — root cause знайдено через додане логування, виправлено.

**992 тести зелені.** Білд чистий.

---

## Артефакти створені у чаті досьє

- `ui_polish_backlog.md` — UI шліфування на потім (4 пункти про дату/час picker)
- `engineering_lessons.md` — інженерні уроки (React state і високочастотний input, isolated diagnostics)

---

## Інженерні уроки (системні, в `engineering_lessons.md`)

1. **React + високочастотні DOM updates.** Input який оновлюється 50+ разів/сек (slider, drag handles) має бути uncontrolled через ref, не через `useState`. Інакше DOM crash.
2. **Діагностика має бути ізольована.** Debug код у try/catch обовʼязково. Інакше старий моніторинг ламає робочий pipeline.
3. **Aspect ratio для orientation — не використовувати.** 50/50 ймовірність 90° vs 270°, не виявляє 180°. Краще не обертати ніж обернути неправильно.
4. **Stale closure як патерн** (з попередньої сесії) — функціональна форма `setCases(prev => ...)` обовʼязкова коли setter викликається після `await`.

---

## ROADMAP — актуалізовано

### ✅ Завершено повністю

**Фаза 1.5 + Test Infrastructure:**
- TASK 1 (канонічна схема + factory + extended + migration v4→v5)
- TASK 2 (8 ACTIONS для документів і проваджень + PERMISSIONS + role `document_processor_agent`)
- TASK 3 (Tool Use Foundation — 20 tools, `toolUseRunner`, multi-turn, retry, агент досьє на нативному Tool Use)
- TASK 4 (Vitest + 180 тестів, CI блокує deploy при red)

**Фаза 1.6 UI Reform:**
- TASK 5–9 (design tokens, базові UI компоненти, lucide migration, Toast/Banner, responsive)
- TASK 10/10.1 (новий DocumentViewer, колапсування панелей, AddDocumentModal на фірмових компонентах, видалення з 2 опціями, Архів з batch)
- Серія мікро-TASK 1–4.1 (чесний тост, правило #8 Drive API, AddDocumentModal pipeline, stale closure fix, Footer/pipeline фікси)
- Серія мікро-TASK 5.1–5.2.fix5 (iframe Drive для inline-renderable, власні рендери, потім фінальний поворот — Mozilla pdfjs viewer iframe для PDF)
- Мікро-TASK ocrService matrix (providerMatrix.js, layout.json у 02_ОБРОБЛЕНІ)
- Мікро-TASK обробка помилок documentAi (класифікація 4 типів, retry, resumeStore, опційний Claude Vision через діалог)
- **TASK A** (конвертація DOCX/HTML/image у PDF з converter/sortation сервісами)
- **TASK B** (склейка зображень, crop editor, straighten slider, orientation cascade, slider crash fix, PR #41)

**Сумарно витрачено:** ~50–60 годин Claude Code

### 🟡 Наступний пріоритет — Document Processor v2

**Критичний для ЄСІТС модуля.** Tool Use вперше у повному обсязі (TASK 3 заклав інфраструктуру, агент досьє вже на ньому). Document Processor v2 — пакет з 2 незалежних модулів через спільну "планку Пікатіні":
- **Модуль 1 — Document Processor v2** — повна переробка з семантичною нарізкою скану на окремі документи (позов, відзив, договір окремими файлами)
- **Модуль 2 — Context Generator** — `.md` файли з варіантами "system" (case_context.md) і "claude_project" (Custom Instructions)

Переюзовує `src/services/converter/` і `src/services/sortation/` створені в TASK A/B.

### 🟡 Після Document Processor v2

- **AI Очищення тексту** через `src/services/cleanup/` — створює `.md` з `.txt + layout.json` (заголовки, абзаци, таблиці, видалені колонтитули)
- **Tool Use міграція QI agent** (4–6 год) — використовує інфраструктуру з TASK 3
- **Tool Use міграція Dashboard agent** (4–6 год)
- **ActionsRegistry refactor** — винесення ACTIONS/PERMISSIONS в окремий сервіс
- **CLAUDE.md Audit** (повний)

### 🟡 Фаза 3 — Анотації, пошук, експорт

- Анотації у Mozilla pdfjs viewer (паралельно з Canvas, не зараз)
- Повнотекстовий пошук через 02_ОБРОБЛЕНІ
- Експорт контексту (MD / prompt / summary)
- Імпорт висновків з зовнішніх Claude чатів

### 🟡 Великі довгострокові фази

- **Canvas-конструктор документів** — окрема фаза, обʼєднує "Позицію" і "Шаблони"
- **ЄСІТС RPA модуль** — повноцінний модуль після Document Processor v2
- **Telegram інтеграція** — клієнтський + робочий бот на бюро
- **Multi-user активація** + UI керування ролями
- **SaaS трансформація** (бекенд, Stripe, мультитенантність)

### 🟡 Окремі дрібні фікси (Фаза 4)

- Drive токен 401 — людське повідомлення
- Видалити мертві кнопки "Аналіз" з Viewer
- Кнопка "Заповнити картку" в Огляді
- Пошук у Записній книжці
- `npm audit fix`
- `ui_polish_backlog.md` — 4 пункти про дату/час picker
- Safe-area foundation (для Android system gesture)
- Mobile-First CaseDossier рефакторинг (після завершення Фази 1.6)
- Sync from Drive — інтеграція документів доданих поза системою

---

## Зміни пріоритетів проти попереднього плану

1. **Власний PDF рендер відкочений** → Mozilla pdfjs viewer iframe (мікро-TASK 5.2-fix4). Це остаточне рішення, не тимчасове.
2. **DocxRenderer і HtmlRenderer** — після Document Processor v2 (який конвертує все в PDF) стають непотрібними. Поки залишаються.
3. **Анотації у viewer** — паралельно з Canvas, не окремо. Споріднені функції.
4. **Aspect ratio orientation** — викинуто з cascade, не використовуємо.
5. **AddDocumentModal стала повноцінним лайт-Document Processor** — це закладає правильну архітектуру для DP v2 через спільні сервіси.

---

## Архітектурні рішення які діють

- **PDF як єдиний формат для відображення** в системі (DP v2 конвертує все при додаванні; оригінал DOCX залишається поряд)
- **Архіваріус 02_ОБРОБЛЕНІ** — агент завжди йде туди за `.txt/.md`, ніколи в 01_ОРИГІНАЛИ
- **Розділені ролі папок** — 01_ОРИГІНАЛИ для зберігання, 02_ОБРОБЛЕНІ копія для показу через iframe, `.txt/.md` тільки для агента, `.layout.json` для майбутнього HTML overlay і Очищення
- **OCR Provider Pattern з двома матрицями** (замовник + виконавець) у `providerMatrix.js`
- **Сервіси у `src/services/`** — спільні для всіх UI; UI компоненти тільки викликають фасади
- **Параметри замість дублювання** — один сервіс з `mode: 'single' | 'batch' | 'batch-uncleaned'`
- **Provider Pattern для розширення** — як OCR, так і конвертація може мати серверний провайдер (Puppeteer + LibreOffice) як преміум у SaaS
- **Стратегія монетизації** — швидкість як преміум через серверну конвертацію

---

## Відомі обмеження поточного стану

- PDF виділення тексту мозаїчне через Mozilla pdfjs viewer (краще ніж раніше, гірше за Drive напряму — Google має закриті оптимізації)
- Magnifier на Android Chrome зʼявляється, не блокабельний
- Android system gesture area може перекривати кнопки (Safe-area foundation на потім)
- Codespaces ліміт скинеться 1 червня; локальне середовище варто налаштувати

---

## Команда для нового чату

> Привіт. Продовжуємо роботу над Legal BMS. Стартовий контекст у `context_dossier_handoff_2026-05-14.md`. Завершено TASK A+B (AddDocumentModal з конвертацією і склейкою), наступний пріоритет — Document Processor v2. Подивись файл і запропонуй з чого почати.
