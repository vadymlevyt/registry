# TASK DP-2 — Архіви + ЄСІТС + базові стадії detectBoundaries/classify

**Дата постановки:** 17.05.2026
**Тип:** код-зміна (нова стадія розпакування + stageOverrides + ecits-інтеграція)
**Передумова:** DP-1 завершено і у main (commit після push)
**Очікуваний час:** 3-5 годин
**Сесія:** ОКРЕМА свіжа сесія Claude Code (не продовжувати DP-1 сесію)

---

# ⚠️ ПРИНЦИП — НАДБУДОВА НА ГОТОВИЙ ФУНДАМЕНТ

DP-1 заклав диригент з 9 стадіями і 2 хук-слотами. DP-2 — перший TASK який заповнює заглушки реальною логікою через `stageOverrides`. **Сам диригент НЕ змінюється.** Це і є ефективність архітектури з DP-1 — нові можливості підключаються як надбудови.

## Що вже є (НЕ переробляти)

З converterService через AddDocumentModal/pipeline уже працює:
- HTML Windows-1251 декодування
- HTML форматування для viewer
- DOCX витяг тексту і форматування через mammoth
- HEIC/JPEG/PNG конвертація
- multiImageToPdf склейка серій

DP-2 не торкається `converterService`. Стадія `convert` залишається без змін.

## Що DP-2 додає

1. **Розпакування архівів** ZIP/RAR/7z — нова стадія `unpack` ПЕРЕД convert
2. **Фільтрація .p7s/.sig** — частина unpack стадії (підписи КЕП зберігаються як оригінали, не йдуть далі по pipeline)
3. **`detectBoundaries` базова реалізація** через stageOverrides — для одного PDF з кількома документами (повна семантична реконструкція з кількох файлів — DP-3)
4. **`classify` базова реалізація** через stageOverrides — AI класифікація типу/автора/категорії документа
5. **ЄСІТС метадані канал** — реальне читання `metadataSidecar` і використання `ecitsContext` у стадіях
6. **Тригер обробки з 00_INBOX** — два режими: автоматичний (eventBus subscription) і ручний (адвокат бачить індикатор), перемикання через `tenant.settings.ecitsAutoProcess: 'manual' | 'auto'`, дефолт `'manual'`

---

# ЕКСПЕРТНА АВТОНОМІЯ

Ти бачиш код напряму. Якщо при виконанні помічаєш що:
- Запропонована структура стадії розпакування може бути кращою
- Є нюанс інтеграції з documentBoundary (TASK 1 salvage) який handoff не врахував
- Бібліотека для розпакування RAR/7z має edge case який варто обробити
- ecitsContext має поле яке логічно використати у іншій стадії

— роби як вважаєш правильно, але у звіті обов'язково поясни:
- Що змінив проти плану
- Чому твоє рішення краще
- Чи це впливає на DP-3/4/5/6 контракти

**Особливо важливо:**
- DP-2 НЕ змінює диригент `documentPipeline.js` — додає тільки `stageOverrides` через deps
- DP-2 НЕ повинен реалізовувати **повну семантичну реконструкцію** з кількох файлів — це DP-3
- DP-2 базова реалізація `detectBoundaries` працює тільки коли AI бачить **один файл** з кількома документами

Якщо рішення сумнівне або виходить за scope — зупинись і запитай ДО виконання, не після.

---

# HANDOFF-БЛОК

Цей TASK виконується у новій сесії Claude Code. Контекст попередніх сесій (TASK 1-5, DP-1) у тебе відсутній.

## 1. Обов'язкове читання перед стартом

У цьому порядку, до будь-якої зміни:

- `CLAUDE.md` (корінь) — архітектура, критичні правила, канонічний стан схеми v7/v8
- `DEVELOPMENT_PHILOSOPHY.md` (корінь) — філософія розробки
- `docs/audits/audit_before_dp1_v2.md` — цільовий аудит перед DP-1 (для розуміння системи)
- `docs/consultations/discussion_dp_v2_philosophy_response.md` — філософське рішення по архітектурі DP v2
- `docs/reports/report_task_dp1_pipeline.md` — звіт DP-1 (актуальна структура pipeline, точки розширення)
- Звіти підготовчих TASK 1-5 у `docs/reports/` (для розуміння спадщини)

**Особливо важливо:** прочитай розділ 10 звіту DP-1 ("Що свідомо лишено для DP-2..6 з прив'язкою"). Там точки розширення які DP-2 заповнює.

## 2. Зафіксувати baseline першою дією

До будь-якої зміни коду, окремими командами, записати точні числа з виводу:

```
npm install
npm test           → записати Test Files / Tests
npm run build      → підтвердити що зелений
```

Це baseline для §9 acceptance. Будь-яка регресія — блокер.

## 3. Mini-аудит перед будь-якою зміною

Звірити фактичний стан після DP-1:

- **`src/services/documentPipeline.js`** — структура диригента, які стадії заглушки, як працює `stageOverrides`, формат `deps` (factory pattern `createDocumentPipeline(deps)`)
- **`src/services/documentBoundary/`** — salvage з TASK 1, готові функції `detectBoundaries` і `splitByBoundaries`, без executeAction
- **`src/services/eventBusTopics.js`** — наявні топіки, чи є ECITS-related топіки (можливо є з підготовчих TASK)
- **AddDocumentModal flow у CaseDossier/index.jsx** — як зараз інтегрований на pipeline, які deps передає
- **`tenant.settings`** структура — куди додавати `ecitsAutoProcess`
- **Структура папок справи на Drive** — чи реально є `00_INBOX/` папка, як її читати через Drive API

Тільки після цього — план реалізації.

## 4. Що зробити (суть DP-2)

### 4.1 Нова стадія unpack (перед convert)

Створити `src/services/documentPipeline/stages/unpack.js`:
- Перевіряє чи файл — архів (ZIP/RAR/7z) за MIME/extension
- Якщо так — розпаковує (JSZip для ZIP, бібліотеки для RAR/7z)
- Фільтрує `.p7s`/`.sig` — зберігає окремо як `signatures[]` у ctx (НЕ йдуть далі по pipeline, але прив'язані до основних файлів)
- Розпаковані файли підставляє назад у `ctx.files[]`
- Якщо файл не архів — passthrough (це чиста функція без побічних ефектів якщо не треба)

Зареєструвати стадію у `DEFAULT_STAGE_ORDER` диригента **ПЕРЕД** `convert`. Якщо `unpack` не у `DEFAULT_STAGE_ORDER` через те що DP-1 не передбачав — додати через `stageOverrides` як перша стадія, або (якщо архітектурно простіше) тимчасово розширити DEFAULT_STAGE_ORDER з обґрунтуванням у звіті.

### 4.2 detectBoundaries базова реалізація

Створити `src/services/documentPipeline/stages/detectBoundariesV2.js`:
- Використовує готовий `documentBoundary.detectBoundaries` з salvage TASK 1
- Працює на **одному PDF файлі** з кількома документами всередині
- Повертає `proposals[]` — масив запропонованих меж з типами і назвами
- НЕ виконує сам split — це `splitByBoundaries` після `confirm` стадії (зараз confirm заглушка → auto-pass)
- НЕ виконує семантичну реконструкцію з кількох файлів (це DP-3)

Підключається через `stageOverrides.detectBoundaries`.

### 4.3 classify базова реалізація

Створити `src/services/documentPipeline/stages/classifyV2.js`:
- Викликає AI (Sonnet через toolUseRunner) з OCR-текстом документа
- Визначає `type` (позов, ухвала, постанова, договір, експертиза, інше)
- Визначає `author` (заявник, відповідач, суд, експерт, інший)
- Визначає `category` справи якщо ще не визначена (опціонально, з низькою впевненістю)
- Повертає `proposals[]` з полями і `confidence`
- Якщо впевненість висока — записує одразу, якщо низька — додає `decisions[]` для адвоката

Підключається через `stageOverrides.classify`.

### 4.4 ecitsContext використання

У `detectBoundaries` і `classify` стадіях:
- Перевіряти `ctx.metadataSidecar?.source === 'court_sync'`
- Якщо так — використовувати `ecitsContext` як підказку (наприклад тип документа з notification, тип справи з кабінету)
- Зменшує токени AI бо контекст уже є
- Підвищує впевненість класифікації

### 4.5 Тригер обробки з 00_INBOX

Створити `src/services/ecitsInboxWatcher.js`:
- Слухає eventBus подію `ecits.files_synced` (або `DOCUMENT_INGESTED` з відповідним source — звірити який топік реально є)
- Якщо `tenant.settings.ecitsAutoProcess === 'auto'` → запускає pipeline у фоні (background job)
- Якщо `'manual'` → пише у `lastProcessingContext` запис "є нові файли в INBOX, N штук" + публікує подію для UI індикатора

Додати `tenant.settings.ecitsAutoProcess` у схему tenant:
- Дефолт `'manual'`
- Bump schemaVersion якщо потрібно (швидше за все ні — це не зміна структури документів)

UI індикатор у досьє — закласти **точку розширення**, реальний UI у DP-4.

### 4.6 metadataSidecar реальне читання

У стадії `unpack` або окремій новій стадії `readSidecar` (на твій вибір якщо архітектурно зрозуміло):
- Перевірити чи у вхідних файлах є `metadataSidecar.json`
- Якщо так — прочитати, валідувати, покласти у `ctx.metadataSidecar`
- Стадії `detectBoundaries`/`classify` використовують через `ctx.metadataSidecar`

## 5. Інваріанти — не порушувати

- **`documentPipeline.js` диригент НЕ міняється** — додаються тільки нові стадії через файли і реєструються через `stageOverrides` чи мінімальне розширення `DEFAULT_STAGE_ORDER`
- **Контракт стадії незмінний** — `{ok, ctx, decisions, error}`, як DP-1 заклав
- **Тонкий диригент** — нові стадії можуть мати domain-if всередині, але **сам диригент** залишається чистим
- **AddDocumentModal flow без регресій** — якщо файл не архів, не вимагає нарізки, не з ECITS — pipeline працює так як було після DP-1
- **executeAction для всіх змін даних** — нічого не пише напряму у state чи Drive повз шар
- **DOCX/HTML дослівне форматування** — converterService уже працює, НЕ переробляти
- **propose→confirm зберегти** — нарізка пропонує, не виконує без confirm
- **НЕ повна семантична реконструкція** — це DP-3
- **НЕ UI** — це DP-4

## 6. Стан репо на старті

main HEAD містить TASK 1-5 + DP-1. Точний commit після push DP-1.

Готові сервіси:
- `documentPipeline.js` — диригент з 9 стадіями + 2 хук-слотами
- `documentBoundary/` — salvage TASK 1 (готовий для detectBoundaries)
- `converterService` — повний фасад конвертації
- `ocrService` — OCR через Document AI + Claude Vision fallback
- `actionsRegistry.js` — createActions(deps) з TASK 5
- `eventBus.js` + `eventBusTopics.js` — DOCUMENT_INGESTED, DOCUMENT_BATCH_PROCESSED + інші

Що НЕ існує і має створитись у DP-2:
- `src/services/documentPipeline/stages/unpack.js` (або інша структура за твоїм рішенням)
- `src/services/documentPipeline/stages/detectBoundariesV2.js`
- `src/services/documentPipeline/stages/classifyV2.js`
- `src/services/ecitsInboxWatcher.js`
- `tenant.settings.ecitsAutoProcess` поле

## 7. Правило #1 — гілка і push

Розробка і коміти на гілці `claude/*` яку видасть harness. Не примусово, не FF якщо main розійшовся.

Наприкінці — зведення змін у відповіді, отримати коротке підтвердження адвоката ПЕРЕД `git push origin HEAD:main`. Тільки чистий fast-forward, тільки при зелених тестах.

## 8. Чого не робити

- НЕ міняти `documentPipeline.js` диригент (тільки додавати стадії через файли)
- НЕ реалізовувати повну семантичну реконструкцію з кількох файлів (DP-3)
- НЕ робити UI Document Processor v2 (DP-4)
- НЕ переробляти converterService — він уже працює
- НЕ переробляти AddDocumentModal flow — він уже на pipeline
- НЕ обходити executeAction
- НЕ створювати глобальні сінглтони (DI через deps)
- НЕ активувати metadataExtractor канал (це DP-3 чи окремий TASK)
- НЕ змінювати канонічну схему document без bump schemaVersion + ідемпотентної міграції + бекапу
- НЕ створювати нові .md у корені (звіти у `docs/reports/`)
- НЕ пушити в main без явного підтвердження адвоката

## 9. Acceptance criteria

- [ ] Створено стадії `unpack`, `detectBoundariesV2`, `classifyV2` як окремі файли
- [ ] Підключені до диригента через `stageOverrides` або мінімальне розширення `DEFAULT_STAGE_ORDER`
- [ ] Розпакування ZIP працює (RAR/7z — якщо є бібліотека або заглушка з повідомленням)
- [ ] Фільтрація .p7s/.sig — підписи зберігаються окремо, не йдуть далі
- [ ] `detectBoundariesV2` працює на одному PDF з кількома документами
- [ ] `classifyV2` визначає тип/автора через AI
- [ ] `ecitsContext` використовується у стадіях якщо є `metadataSidecar.source === 'court_sync'`
- [ ] `ecitsInboxWatcher.js` створено з обома режимами (auto/manual)
- [ ] `tenant.settings.ecitsAutoProcess` додано з дефолтом `'manual'`
- [ ] Юніт-тести на нові стадії (unpack, detectBoundariesV2, classifyV2, ecitsInboxWatcher)
- [ ] Інтеграційні тести через справжній `createActions` (поверх `_actionsTestSetup`)
- [ ] AddDocumentModal flow без регресій (не-архівний файл проходить як раніше)
- [ ] npm test — кількість тестів не менша за baseline
- [ ] npm run build — зелений
- [ ] Звіт `docs/reports/report_task_dp2_archives_ecits.md`
- [ ] Зведення показано адвокату; push у main після підтвердження

---

# ЗВІТ

Після виконання — створити файл `docs/reports/report_task_dp2_archives_ecits.md` зі структурою:

1. **Baseline зафіксований у §2** (точні числа)
2. **Mini-аудит** — як підключався до існуючих структур, які точки розширення з DP-1 використано
3. **Структура нових стадій** — файли, контракти, де підключені
4. **Розпакування архівів** — які формати підтримуються, які бібліотеки використано, як обробляються .p7s/.sig
5. **detectBoundariesV2** — реалізація, інтеграція з documentBoundary salvage
6. **classifyV2** — реалізація AI класифікації, які поля визначає
7. **ecitsContext використання** — як стадії його споживають
8. **ecitsInboxWatcher** — два режими (auto/manual), як обираються
9. **tenant.settings.ecitsAutoProcess** — додано, дефолт, як змінюється
10. **Файли створені/видалені/модифіковані** — повний перелік
11. **Тести** — baseline / після, нові
12. **Відхилення від handoff** з поясненнями
13. **Acceptance criteria** — статус
14. **Що свідомо лишено для DP-3/4** — точки розширення
15. **tracking_debt** — побічні знахідки якщо є
16. **Підтвердження** — behavior-preserving AddDocumentModal, диригент незмінний, executeAction незмінний

---

**Дякую за уважність. DP-2 — перша надбудова на pipeline-фундамент. Тут перевіряємо чи архітектура DP-1 дійсно дозволяє додавати стадії без переробок.**
