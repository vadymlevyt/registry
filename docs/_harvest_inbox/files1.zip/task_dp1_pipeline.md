# TASK DP-1 — Pipeline архітектура Document Processor v2

**Дата постановки:** 16.05.2026
**Тип:** Великий архітектурний TASK (тонкий диригент-фасад + інтеграція)
**Очікуваний час:** 6-8 годин
**Результат:** `src/services/documentPipeline.js` + інтеграція AddDocumentModal + звіт `docs/reports/report_task_dp1_pipeline.md`
**Сесія:** ОКРЕМА свіжа сесія Claude Code (не продовжувати TASK 1-5)

---

# ⚠️ ВАЖЛИВО — ПРИНЦИП ТОНКОГО ДИРИГЕНТА

DP-1 — це **архітектурний фундамент** для всієї серії DP v2 (DP-1...DP-6). Якщо закласти його неправильно — переробляти доведеться все. Якщо правильно — DP-2/3/4/5/6 ляжуть природно як надбудови.

**Ключова дисципліна цього TASK:**
- documentPipeline — **тонкий диригент**, нічого не вирішує сам
- Стадії — **чисті функції з контрактом**, без знання одна про одну
- НЕ реалізовувати самі стадії, тільки контракти і каркас
- НЕ починати UI Document Processor v2 (це DP-4)
- НЕ обходити жодного існуючого шару (executeAction, createDocument, converterService, activityTracker)

Якщо виникає спокуса додати domain-if у диригент — це **сигнал** що рішення має бути у стадії або політиці, не в диригенті.

---

# ЕКСПЕРТНА АВТОНОМІЯ

Ти бачиш код напряму. Я бачу його через звіти. Якщо при виконанні помічаєш що:
- Запропонована структура може бути кращою (інші імена точок розширення, чистіший контракт стадії, інша організація файлів)
- Є нюанс який handoff не врахував (наприклад точна структура deps яку треба прокинути в pipeline)
- При інтеграції AddDocumentModal виявився патерн який варто зберегти/поліпшити
- Знайшов латентну проблему яку **не зачіпає DP-1** але варто зафіксувати у tracking_debt

— роби як вважаєш правильно, але у звіті обов'язково поясни:
- Що змінив проти handoff
- Чому твоє рішення краще
- Чи це впливає на DP-2/3/4/5/6 контракти

Якщо рішення сумнівне або виходить за scope — зупинись і запитай ДО виконання, не після.

**Особливо важливо:** behavior-preserving для AddDocumentModal — інтеграція на pipeline **не повинна змінити користувацький досвід**. Поведінка для адвоката та сама (вибрав файл → конвертація → додання документа), просто реалізація проходить через pipeline.

---

═══════════ ПОЧАТОК БЛОКУ — ВСТАВИТИ ДОСЛІВНО В TASK DP-1 ═══════════
HANDOFF-БЛОК ДЛЯ TASK DP-1 — Pipeline-архітектура Document Processor v2
Підготовлено сесією, що завершила підготовчий ланцюг TASK 1–5. Усі шляхи й факти нижче звірені з main@985de03 на момент передачі. Числа baseline свідомо НЕ зафіксовані тут — їх знімає нова сесія першою дією (див. §2), не з пам'яті й не з цього блоку.
1. ОБОВ'ЯЗКОВЕ ЧИТАННЯ ПЕРЕД СТАРТОМ (у цьому порядку, до будь-якої зміни)
CLAUDE.md (корінь) — архітектура, критичні правила, канонічний стан схеми v7/v8.
DEVELOPMENT_PHILOSOPHY.md (корінь) — «ембріон з повним ДНК», propose→confirm, тонкі диригенти, planka Picatinny, філософія білінгу. Без цього файлу TASK не починати.
docs/audits/audit_before_dp1_v2.md — цільовий аудит перед DP-1 (актуальна редакція; є також старіший audit_before_dp1.md — читати v2, старий лише як контекст за потреби).
docs/consultations/discussion_dp_v2_philosophy_response.md — філософське рішення по архітектурі DP v2 (пріоритет над технічними деталями за конфлікту).
Звіти підготовчих TASK 1–5 у docs/reports/:
report_task_1_salvage_and_decommission.md (salvage + decommission старого DP)
report_task_2_time_entry_capture_method.md
report_task_3_event_bus_document_topics.md
report_task_4_update_document_source.md
report_task_5_actionsregistry_refactor.md (актуальний createActions(deps) — основа інтеграції)
dp_v2_functionality_reference.md — якщо присутній у проектних файлах/knowledge (повний довідник функціоналу DP v2). У репозиторії на момент передачі його НЕМАЄ — шукати у проектних файлах сесії; якщо немає там — зафіксувати відсутність у власному mini-аудиті, не вигадувати функціонал.
2. ЗАФІКСУВАТИ BASELINE — ПЕРШОЮ ДІЄЮ
До будь-якої зміни коду, окремими командами, записати ТОЧНІ числа з виводу (не з пам'яті, не з цього блоку):
Code
Це baseline для §9 (acceptance). Будь-яка регресія відносно цих чисел — блокер.
3. ВЛАСНИЙ MINI-АУДИТ ПЕРЕД БУДЬ-ЯКОЮ ЗМІНОЮ
Не довіряти цьому блоку як єдиному джерелу — звірити фактичний стан після TASK 1–5:
Що готове в src/services/ (звірено на передачі): actionsRegistry.js (createActions(deps) @ рядок ~82), eventBus.js + eventBusTopics.js (TASK 3: топіки document.ingested, document.batch_processed, document.movement_card_updated, document.alternative_source_added — additive, без publisher'ів — DP-1 стає першим publisher'ом), sourcePolicy.js (TASK 4, SOURCE_PRIORITY/canOverwrite), documentFactory.js (createDocument() — єдина точка), documentsExtended.js (lazy extended-метадані = носій концепту «metadataSidecar»), converter/ (converterService.convertToPdf фасад: docx/html/image/heic + multiImageToPdf, pdfLibHtmlRenderer), ocrService.js + ocr/ (провайдер-патерн), compressionService.js + documentBoundary/ (analyzeViaToolUse.js, splitPdf.js, prompt.js, index.js — salvaged TASK 1 Phase A), metadataExtractor/ (канал Metadata Extractor — hooks, не активувати).
Точки інтеграції AddDocumentModal: src/components/CaseDossier/AddDocumentModal.jsx — UI-збір вводу; фактична логіка створення/конвертації документа живе у src/components/CaseDossier/index.jsx (CLAUDE.md орієнтири: модаль «+ Додати документ» ~CaseDossier:2452-2486; drag-n-drop drop queue ~CaseDossier:1940-2010, тимчасово через update_case_field). Звірити обидва місця у коді — рядки могли зсунутися; шукати по createDocument / convertToPdf / executeAction у CaseDossier/index.jsx.
Як documents створюються сьогодні — пройти ланцюг руками: вибір файлу → converterService.convertToPdf → OCR-гілка/searchable-гілка → createDocument() → executeAction(...) → Drive save. Зафіксувати, які кроки вже є і де саме pipeline їх інкапсулює.
Тільки після цього — план реалізації.
4. ЩО ЗРОБИТИ (СУТЬ DP-1)
Створити src/services/documentPipeline.js — тонкий диригент ingest-конвеєра документа:
Патерни: Pipes-and-Filters (стадії як незалежні фільтри) + Mediator (pipeline координує, стадії одна про одну не знають) + DI (усі сайд-ефекти й залежності ін'єктуються, як createActions(deps) у TASK 5 — pipeline отримує executeAction, конвертери, OCR, eventBus, factory через deps; жодних прямих імпортів стану/Drive у самому диригенті).
Закласти контракти стадій (інтерфейс стадії: вхід → вихід → помилка), не реалізуючи доменну логіку самих стадій. Орієнтовний кістяк стадій (фінальний поділ — за discussion_dp_v2_philosophy_response.md / functionality reference): intake → convert (converterService) → classify/boundary (documentBoundary, точка DP-2) → OCR/extract (ocrService, точка DP-3) → propose-метадані → confirm → persist (через createDocument + executeAction) → emit events (eventBus топіки TASK 3).
Точки розширення для DP-2/3/4/5/6: явні, іменовані hook-точки/слоти стадій так, щоб наступні TASK додавали реалізацію стадії без зміни диригента (OCP). Документувати кожну точку коротко в коді (одне речення сенсу — правило #11 CLAUDE.md).
Hooks для metadataSidecar і Metadata Extractor: точка запису розширених метаданих через documentsExtended.js (.metadata/documents_extended.json) і точка входу для каналу metadataExtractor/ — тільки інтерфейс/слот, канал лишається DISABLED, не активувати.
Інтегрувати AddDocumentModal на pipeline: потік створення документа з модалі/drop-queue у CaseDossier/index.jsx переводиться на виклик documentPipeline, замість інлайн-ланцюга. Поведінка для користувача без регресій (помилка конвертації → toast, модаль відкрита, документ не створюється — як у TASK A контракті).
5. ІНВАРІАНТИ — НЕ ПОРУШУВАТИ
Не реалізовувати самі стадії повністю — boundary/classify (DP-2), OCR/extract семантика (DP-3) лишаються заглушками/passthrough зі стабільним контрактом. DP-1 — лише каркас + проводка.
Не починати UI — окремий UI Document Processor v2 це DP-4. DP-1 чіпає тільки існуючий AddDocumentModal-флоу.
Тонкий диригент — НУЛЬ domain-if у самому documentPipeline.js (жодних розгалужень «якщо суд / якщо DOCX / якщо ECITS» всередині диригента; рішення делегуються стадіям/політикам як sourcePolicy.js).
Усе через executeAction — будь-яка модифікація даних тільки через актуальний actionsRegistry (createActions(deps), TASK 5). НЕ обходити executeAction, НЕ обходити createDocument() / converterService.convertToPdf / activityTracker.report. НЕ глобальний сінглтон — deps передаються, як зроблено в TASK 5.
propose→confirm зберегти як принцип — pipeline пропонує метадані/класифікацію, фіксація лише після підтвердження; не автозапис без confirm-кроку.
Дотримати правила CLAUDE.md: #7 (executeAction async — усі callers що читають результат await), #9 (ембріон з ДНК — SaaS/multi-tenant/billing на місці народження стадій), #11 (однозначність кожного нового поля/прапора — одне речення сенсу), tenantId не дублювати у вкладених сутностях.
6. СТАН РЕПО НА СТАРТІ
main HEAD = 985de03 «TASK 5: extract ACTIONS/PERMISSIONS/executeAction to actionsRegistry.js». Містить підготовчий ланцюг TASK 1–5 (+ TASK 0.x foundation, SaaS/Billing v1–v2, schema v7/v8).
Якір «перед видаленням старого DP» = коміт b3b847f «TASK 1 Phase A: salvage compressionService + documentBoundary/» (старий DP знесено наступним bd9e3bd TASK 1 Phase B/C). Очікувана назва тега pre-dp-v2-old-dp-removal — у репо тег може бути ВІДСУТНІЙ; звірятись по SHA b3b847f, не покладатись на тег. За потреби rollback-якоря — створити тег самостійно на b3b847f.
src/services/documentPipeline.js ще НЕ існує (його створює DP-1).
7. ПРАВИЛО #1 — ГІЛКА І PUSH
Remote-execution (web/планшет/телефон): harness видає робочу гілку claude/*. Уся розробка й коміти — на ній. DP-1 = зміни коду → НЕ автоматичний FF у main. Наприкінці: показати адвокату зведення змін у відповіді й отримати коротке (одне речення) підтвердження ПЕРЕД git push origin HEAD:main. Тільки чистий fast-forward, тільки при зелених тестах. Не FF / main розійшовся → не примусово, розібрати розбіжність. git push -u origin <branch>; мережеві збої — ретрай з backoff 2/4/8/16s.
8. ЧОГО НЕ РОБИТИ (повний перелік)
НЕ реалізовувати доменну логіку стадій boundary/classify/OCR-семантики (це DP-2/DP-3).
НЕ створювати UI Document Processor v2 (DP-4) — жодних нових екранів/вкладок/модалей крім інтеграції наявного AddDocumentModal-флоу.
НЕ вставляти domain-if у documentPipeline.js (тонкий диригент — рішення в стадіях/політиках).
НЕ обходити executeAction / createDocument() / converterService.convertToPdf / activityTracker.report.
НЕ робити pipeline глобальним сінглтоном — лише DI через deps (патерн TASK 5).
НЕ активувати metadata_extractor_agent / канал metadataExtractor/ — лише hook-слот.
НЕ викликати Document AI на PDF, конвертованому з DOCX/HTML (searchable-гілка пише .txt, без OCR — контракт TASK A); НЕ продовжувати pipeline якщо convertToPdf кинув.
НЕ публікувати нові eventBus-топіки поза TASK 3 набором без bump/узгодження; використовувати наявні document.ingested / document.batch_processed.
НЕ додавати поля в канонічну схему документа без bump schemaVersion + ідемпотентної міграції + бекапу; НЕ розширювати addedBy/source enum (сигнал порушення #11); НЕ плутати addedBy (хто додав) із source (звідки файл).
НЕ прибирати/змінювати propose→confirm на автозапис.
НЕ замінювати заглушки підготовчих TASK реальною логікою без узгодження; НЕ міняти CONVERT_DOCX_TO_PDF через UI; НЕ повертати TASK B (склейка зображень) у скоуп.
НЕ дублювати спільний стан у компоненти (єдине джерело — App.jsx; зміни через props-функції); НЕ кирилиця в q= Drive API (#8).
НЕ створювати нові .md у корені (тільки 6 канонічних); звіти/аудити — у відповідні docs/<підпапка>/.
НЕ пушити в main без явного підтвердження адвоката (§7); НЕ створювати PR без явного прохання.
9. ACCEPTANCE (DP-1 завершено коли ВСЕ виконано)
[ ] Створено src/services/documentPipeline.js — тонкий диригент (Pipes-and-Filters + Mediator + DI), без domain-if, з іменованими точками розширення для DP-2/3/4/5/6 і hook-слотами metadataSidecar + Metadata Extractor (слот, не активований).
[ ] Контракти стадій визначені; самі стадії — стабільні passthrough/заглушки (доменна логіка НЕ реалізована).
[ ] AddDocumentModal-флоу (CaseDossier/index.jsx + AddDocumentModal.jsx) інтегрований на pipeline; ручна перевірка ingest-сценарію без регресій (PDF / DOCX-searchable / image-OCR / помилка convert → toast, документ не створюється).
[ ] Юніт-тести на нові контракти/диригент у tests/unit/; інтеграційні — у tests/integration/ якщо торкається ACTIONS/PERMISSIONS (поверх справжнього createActions через _actionsTestSetup.js, БЕЗ дублювання логіки).
[ ] npm test — кількість тестів не менша за baseline §2, усі зелені.
[ ] npm run build — зелений, без нових попереджень-блокерів.
[ ] Звіт docs/reports/report_task_dp1_pipeline.md: baseline-числа (до/після), mini-аудит, перелік точок розширення, рішення/компроміси, що свідомо лишено для DP-2..6, оновлення tracking_debt.md за потреби.
[ ] Зведення змін показано адвокату; push у main лише після підтвердження (§7).
═══════════ КІНЕЦЬ БЛОКУ ═══════════

---

# ДОДАТКОВИЙ КОНТЕКСТ — ОБРОБКА ПОМИЛОК ЯК ПРИНЦИП

Окрім handoff блоку, врахуй принцип обробки помилок який ми пророблювали в обговореннях (детально у `dp_v2_functionality_reference.md` розділ 9, або відтворити з принципів):

**Pipeline робить все що може автономно. Помилки і питання накопичуються для розгляду після завершення. Зупинка тільки при критичних збоях.**

Контракт стадії повинен підтримувати такі поля результату:
- `ok: true/false`
- `value: {...}` — результат якщо ok
- `decisions: [...]` — питання адвокату де робота зроблена (вкладка Підтвердження у DP-4)
- `error: { code, message, file_skipped, fatal, retriable, ... }` — помилки (вкладка Помилки у DP-4)

Категорії результатів:
1. **`ok: true`** → стадія успішна, продовжуємо
2. **`ok: true, decisions: [...]`** → є питання адвокату (накопичуються, не зупиняють pipeline)
3. **`ok: false, file_skipped: true`** → конкретний файл провалився, решта продовжує
4. **`ok: false, fatal: true`** → pipeline зупиняється, job state зберігається для resume

Це **наскрізна архітектурна вимога**, не окрема стадія. Закладається у контракт стадії і політику диригента у DP-1.

UI вкладки Підтвердження/Помилки реалізуються у DP-4 — pipeline просто повинен правильно класифікувати результати.

---

# ЗВІТ

Після виконання — створити файл `docs/reports/report_task_dp1_pipeline.md` зі структурою:

1. **Baseline зафіксований у §2** (точні числа тестів і файлів)
2. **Mini-аудит** — що знайшов у системі, які точки інтеграції AddDocumentModal, ланцюг створення документа сьогодні
3. **Структура documentPipeline.js** — кістяк стадій, точки розширення з іменами
4. **Контракт стадії** — повний інтерфейс (вхід, вихід, помилка, decisions)
5. **Hooks для metadataSidecar і Metadata Extractor** — як спроектовано
6. **Інтеграція AddDocumentModal** — який ланцюг було, який став
7. **Файли створені, видалені, модифіковані** — повний перелік
8. **Тести** — baseline / після, нові тести
9. **Відхилення від handoff** з поясненнями (експертна автономія)
10. **Що свідомо лишено для DP-2/3/4/5/6** — перелік точок розширення з прив'язкою до фази
11. **Acceptance criteria** — статус кожного пункту
12. **tracking_debt** — побічні знахідки якщо є (не виправляти у DP-1)
13. **Підтвердження** — behavior-preserving для AddDocumentModal, executeAction контракт незмінний, тонкий диригент без domain-if

---

**Дякую за уважність і архітектурну дисципліну. DP-1 — це фундамент який визначить всю серію DP v2.**
