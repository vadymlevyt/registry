# TASK: Фікс нарізки великих PDF через pdf-lib

**Дата створення:** 2026-04-28
**Гілка:** main
**Пріоритет:** ВИСОКИЙ — блокер для кримінальних справ і справ з великими сканами
**Залежності:** OCR-спринт завершений (фази 1-4), pdf-lib встановлений в package.json
**Виконавець:** Claude Code Opus у Codespaces після 1 травня 2026

---

## ПРОБЛЕМА

Документ AI має **жорсткий ліміт 20 МБ** на файл. PDF більші за цей розмір повертають `422 Unprocessable Entity: file too large`.

В OCR-спринті в TASK був закладений алгоритм нарізки великих PDF через `pdf-lib` на чанки по 25 сторінок. **Перевірка показала що нарізка не працює** — файли 38-42 МБ (справа Сипка) йдуть в Document AI цілком і отримують 422.

### Симптом

1. Адвокат відкриває досьє великої справи (наприклад, Сипко з 6 PDF файлами 18-42 МБ кожен)
2. Натискає "Створити контекст"
3. Бачить "Знайдено 6 файлів. Запускаю обробку..."
4. Через хвилину — або біла сторінка ("От халепа!"), або файл `case_context.md` з помилкою обробки замість контексту

### Тимчасовий обхід (поточний стан)

Адвокат стискає файли локально через iLovePDF/Adobe online до <20 МБ перед завантаженням на Drive. Якість тексту після стиснення з 38 МБ до 9.7 МБ — **прийнятна** для Document AI (сам пост стиснення тестовано на справі Сипка, успішно).

**Це не вирішення.** Стиснення вручну — затратно по часу, інтерактивно, можливі помилки.

---

## ЦІЛЬ TASK

Реалізувати **автоматичну нарізку** великих PDF в `documentAi.js` (або відповідному сервісі) так щоб:

1. Адвокат завантажує великий PDF (40+ МБ) в `01_ОРИГІНАЛИ` через досьє
2. Натискає "Створити контекст"
3. Система **автоматично** розрізає файл на чанки <20 МБ
4. Кожен чанк іде в Document AI окремо
5. Результати склеюються в один текст
6. Текст потрапляє в кеш `02_ОБРОБЛЕНІ` з прив'язкою до Drive ID оригіналу
7. Далі pipeline обробляється стандартно

Адвокат **нічого не робить вручну**. Великі файли працюють так само як малі, просто довше.

---

## КОРІНЬ ПРОБЛЕМИ — ДІАГНОСТИКА

Тестування показало:
- **Файл 38 МБ цілком** → Document AI 422
- **Файл 9.7 МБ** (стиснений з того ж 38 МБ) → Document AI працює нормально
- Це означає **запит дійсно доходить** до API, **API дійсно відмовляє** через розмір
- Логіка нарізки в `documentAi.js` **не виконується** перед відправкою

### Можливі причини що нарізка не спрацьовує

1. **pdf-lib не встановлений** в `package.json` — імпорт мовчки фейлиться, відправляється файл цілком
2. **Логіка нарізки є але не викликається** — є умова на розмір яка некоректна
3. **Логіка нарізки викликається але крашиться** — браузер вилітає по out-of-memory при роботі з 40 МБ ArrayBuffer
4. **pdf-lib працює але результат не передається в Document AI** — нарізані чанки відправляються неправильно

### Перший крок діагностики

```bash
grep -rn "pdf-lib\|PDFDocument\|splitPdf\|chunkPdf" src/services/ocr/
cat package.json | grep pdf
```

Зрозуміти **поточний стан** перш ніж писати код. Перевірити чи pdf-lib взагалі є.

---

## ЩО РОБИТИ — АЛГОРИТМ

### Етап 1 — Встановлення залежності

Якщо pdf-lib немає:

```bash
npm install pdf-lib
```

Перевірити що додано в package.json.

### Етап 2 — Функція нарізки

Створити функцію `splitPdfByPages` в окремому модулі або в `documentAi.js`:

```javascript
import { PDFDocument } from 'pdf-lib';

async function splitPdfByPages(arrayBuffer, pagesPerChunk = 15) {
  const sourcePdf = await PDFDocument.load(arrayBuffer);
  const totalPages = sourcePdf.getPageCount();
  const chunks = [];
  
  for (let startPage = 0; startPage < totalPages; startPage += pagesPerChunk) {
    const endPage = Math.min(startPage + pagesPerChunk, totalPages);
    const chunkPdf = await PDFDocument.create();
    
    const pageIndices = [];
    for (let i = startPage; i < endPage; i++) {
      pageIndices.push(i);
    }
    
    const copiedPages = await chunkPdf.copyPages(sourcePdf, pageIndices);
    copiedPages.forEach(page => chunkPdf.addPage(page));
    
    const chunkBytes = await chunkPdf.save();
    chunks.push({
      bytes: chunkBytes,
      startPage: startPage + 1,
      endPage: endPage,
      sizeBytes: chunkBytes.length
    });
    
    // Звільнення пам'яті
    await new Promise(resolve => setTimeout(resolve, 0));
  }
  
  return chunks;
}
```

**Параметри:**
- `pagesPerChunk = 15` — за замовчуванням, відповідає ліміту Document AI на сторінки
- Можна налаштовувати якщо потрібно

### Етап 3 — Інтеграція з Document AI

В `src/services/ocr/documentAi.js` додати логіку перед відправкою файлу:

```javascript
const SIZE_LIMIT_BYTES = 20 * 1024 * 1024; // 20 MB
const PAGES_LIMIT = 15;

async function extractText(file, fileMeta) {
  const arrayBuffer = await fileToArrayBuffer(file);
  const sizeMB = arrayBuffer.byteLength / (1024 * 1024);
  
  // Швидка перевірка — якщо точно мале, не нарізаємо
  if (arrayBuffer.byteLength < SIZE_LIMIT_BYTES * 0.9) {
    // Відправка цілком
    return await callDocumentAI(arrayBuffer, fileMeta);
  }
  
  // Можливо потребує нарізки. Перевіряємо кількість сторінок
  const pdfDoc = await PDFDocument.load(arrayBuffer);
  const pageCount = pdfDoc.getPageCount();
  
  // Якщо файл великий АБО багато сторінок — нарізаємо
  if (arrayBuffer.byteLength >= SIZE_LIMIT_BYTES * 0.9 || pageCount > PAGES_LIMIT) {
    console.log(`[Document AI] Файл ${fileMeta.name}: ${sizeMB.toFixed(1)} МБ, ${pageCount} сторінок. Нарізаю.`);
    
    const chunks = await splitPdfByPages(arrayBuffer, PAGES_LIMIT);
    const results = [];
    
    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      console.log(`[Document AI] Обробляю чанк ${i + 1}/${chunks.length} (стор. ${chunk.startPage}-${chunk.endPage}, ${(chunk.sizeBytes / 1024 / 1024).toFixed(1)} МБ)`);
      
      try {
        const chunkText = await callDocumentAI(chunk.bytes, {
          ...fileMeta,
          name: `${fileMeta.name} [chunk ${i + 1}/${chunks.length}]`
        });
        results.push({
          startPage: chunk.startPage,
          endPage: chunk.endPage,
          text: chunkText
        });
      } catch (error) {
        console.error(`[Document AI] Помилка на чанку ${i + 1}/${chunks.length}:`, error);
        results.push({
          startPage: chunk.startPage,
          endPage: chunk.endPage,
          text: `[ПОМИЛКА ОБРОБКИ ЧАНКУ ${i + 1}/${chunks.length} (стор. ${chunk.startPage}-${chunk.endPage}): ${error.message}]`
        });
      }
      
      // Memory release between chunks
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    // Склеювання результатів
    return results.map(r => r.text).join('\n\n');
  }
  
  // Якщо чомусь дійшли сюди — відправка цілком
  return await callDocumentAI(arrayBuffer, fileMeta);
}
```

### Етап 4 — Memory management

Великі файли в браузері планшета — ризик out-of-memory. Стратегія:

1. **`setTimeout(0)` між операціями** — дає браузеру шанс на GC
2. **Не тримати всі чанки в пам'яті одночасно** — обробляти послідовно, один за одним
3. **`URL.revokeObjectURL`** для будь-яких створених ObjectURL
4. **Звільняти ArrayBuffer** після використання (set до null, дай GC робити свою справу)

### Етап 5 — Прогрес-репортинг

Поточний UI показує тільки "Обробка...". Для великих файлів це може тривати **хвилини** — адвокат не повинен думати що зависло.

Передавати прогрес через callback або state:

```javascript
async function extractTextBatch(files, onProgress) {
  const results = [];
  
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    onProgress?.({
      stage: 'file_start',
      currentFile: file.name,
      currentIndex: i + 1,
      totalFiles: files.length
    });
    
    try {
      // Якщо файл великий — нарізка з власним прогресом
      const result = await extractText(file, {
        onChunkProgress: (chunkInfo) => {
          onProgress?.({
            stage: 'chunk_processing',
            currentFile: file.name,
            currentIndex: i + 1,
            totalFiles: files.length,
            chunkIndex: chunkInfo.index,
            totalChunks: chunkInfo.total,
            chunkPages: `${chunkInfo.startPage}-${chunkInfo.endPage}`
          });
        }
      });
      results.push({ file: file.name, text: result, success: true });
    } catch (error) {
      results.push({ file: file.name, error: error.message, success: false });
    }
  }
  
  return results;
}
```

В UI Досьє відображати на кожному event:
- "Обробляю файл 3 з 6: Сипко 1392_4.pdf"
- "Чанк 5 з 8 (сторінки 61-75)"
- Час що минув + орієнтовна оцінка часу що залишився

---

## ВКЛЮЧАЄМО CONTINUE-ON-ERROR

Якщо нарізка одного файлу впала або один чанк не обробився — **не валимо весь батч**. Логуємо помилку, продовжуємо з іншими.

В кінці звіт:
```
Створення контексту завершено.
- Оброблено: 5 з 6 файлів
- Помилки:
  - Сипко 1392_2.pdf: чанк 3/8 не оброблено (timeout)
  
case_context.md створено на основі 5 файлів які пройшли успішно.
```

Адвокат бачить що пройшло, що ні. Може повторити спробу для проблемного файлу окремо.

---

## КРИТЕРІЇ ПРИЙМАННЯ

### Тест 1 — справа Сипка з оригінальними файлами

Завантажити оригінали 6 файлів (18-42 МБ кожен, ~200 МБ загалом) в `01_ОРИГІНАЛИ` справи Сипка. Натиснути "Створити контекст" **без жодного попереднього стиснення**.

Очікування:
- Жодного 422 від Document AI
- Жодного крашу браузера
- Прогрес-репортинг показує що відбувається на кожному етапі
- В кінці — повноцінний `case_context.md`
- В `02_ОБРОБЛЕНІ` — 6 кеш-файлів з прив'язкою до Drive ID

### Тест 2 — повторне натискання

Натиснути "Створити контекст" **повторно** на тій же справі.

Очікування:
- Кеш спрацьовує — Document AI не викликається
- Файл `case_context.md` оновлюється з тих самих кеш-даних
- Час: секунди замість хвилин

### Тест 3 — проміжна помилка

Імітувати помилку на одному з чанків (наприклад, через мережеву нестабільність).

Очікування:
- Помилка логується
- Інші файли і чанки обробляються
- В звіті чітко видно що не вийшло

### Тест 4 — пам'ять планшета

Перевірити що при обробці 200+ МБ файлів **на планшеті Lenovo Yoga Tab 13** браузер не вилітає по OOM. Можливо доведеться:
- Зменшити `pagesPerChunk` до 10 для дуже великих файлів
- Додати агресивну паузу між чанками (1-2 секунди setTimeout)
- Контролювати загальну пам'ять (якщо вже >500 МБ зайнято — зачекати)

---

## ЩО НЕ РОБИМО В ЦЬОМУ TASK

- НЕ чіпаємо інші OCR-провайдери (`claudeVision.js`, `pdfjsLocal.js`)
- НЕ чіпаємо системний промпт для генерації `case_context.md` (це окремий TASK)
- НЕ чіпаємо логіку Drive (як файли зберігаються, кешуються)
- НЕ переробляємо UI Досьє крім додавання прогрес-репортингу

---

## ДЕПЛОЙ

Звичайний flow:

```bash
npm run build
git add -A
git commit -m "fix: PDF chunking for large files (>20MB) via pdf-lib"
git push origin main
```

Після GitHub Actions деплою (2-3 хв) — тестувати на справі Сипка.

---

## МАЙБУТНЄ — ПОДАЛЬШІ ОПТИМІЗАЦІЇ

Після того як базовий фікс працює, можна додати:

1. **Паралельна обробка чанків** — якщо обмеження на rate limit Document AI дозволяє
2. **Progressive context creation** — показувати в UI part of `case_context.md` як тільки готові перші чанки
3. **Resume після збою** — якщо обробка перервалась, повторити можна тільки невдалі чанки
4. **Адаптивний chunk size** — зменшувати pages per chunk якщо чанк виходить >20 МБ через щільність вмісту

Не для першої ітерації. Робочий MVP — без цього.

---

## ВАЖЛИВО

**Це блокер для кримінальних справ.** В кримінальних справах матеріали часто 100+ сторінок з обвинувальним актом, експертизами, протоколами. Без цього фіксу адвокат не може користуватись агентом досьє в кримінальних справах через стиснення кожного файлу вручну.

Тому пріоритет високий, після відновлення Codespaces — один з перших спринтів.
