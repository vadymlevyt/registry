# TASK.md — Мікрофікси: галочка save_note + колір кнопки прикріплення
# Legal BMS | АБ Левицького
# Дата: 03.05.2026

---

## КРОК 0 — ПРОЧИТАТИ LESSONS.md

```bash
cat LESSONS.md
```

---

## ФІКС 1 — Галочка ✅ у відповіді save_note

Знайти chat-handler save_note в sendChat:

```bash
grep -n "Нотатку збережено\|save_note" src/App.jsx | head -10
```

Знайти рядок де addMessage з текстом "Нотатку збережено..."
Додати ✅ на початок:

```javascript
// Було:
addMessage('assistant',
  'Нотатку збережено' +
  (actionResult.case_name ? ' до справи "' + actionResult.case_name + '"' : '') +
  (actionResult.date ? ' на ' + actionResult.date : '') + '.'
);

// Треба:
addMessage('assistant',
  '✅ Нотатку збережено' +
  (actionResult.case_name ? ' до справи "' + actionResult.case_name + '"' : '') +
  (actionResult.date ? ' на ' + actionResult.date : '') + '.'
);
```

---

## ФІКС 2 — Колір кнопки прикріплення нотатки

Зараз логіка кольору навпаки:
- Прикріплена (іконка вертикально) → приглушений колір ❌
- Відкріплена (іконка під 45°) → яскравий колір ❌

Має бути:
- Прикріплена (іконка вертикально) → яскравий колір (#f59e0b або подібний) ✅
- Відкріплена (іконка під 45°) → приглушений колір (#6b7280 або подібний) ✅

Знайти кнопку прикріплення в Notebook або App.jsx:

```bash
grep -n "isPinned\|pin.*color\|pinned.*color\|rotate\|📌\|pin-btn" src/App.jsx src/components/Notebook/index.jsx 2>/dev/null | head -20
```

Знайти умову що визначає колір кнопки.
Поміняти умову місцями:

```javascript
// Було (неправильно):
color: isPinned ? '#6b7280' : '#f59e0b'

// Треба:
color: isPinned ? '#f59e0b' : '#6b7280'
```

Також перевірити transform/rotate — вертикальна іконка = прикріплена,
під кутом 45° = відкріплена. Якщо і це навпаки — виправити.

---

## ПЕРЕВІРКА

```bash
grep -n "Нотатку збережено" src/App.jsx | head -5
grep -n "isPinned.*color\|color.*isPinned" src/App.jsx src/components/Notebook/index.jsx 2>/dev/null | head -10
```

---

## ТЕСТОВА МАТРИЦЯ

1. "Додай нотатку по Конаху: тест"
   → відповідь починається з ✅ ✅

2. Кнопка прикріплення в Книжці:
   - Прикріплена нотатка → іконка вертикально + яскравий колір ✅
   - Відкріплена нотатка → іконка 45° + приглушений колір ✅

---

## ДЕПЛОЙ

```bash
git add -A && git commit -m "fix: галочка save_note + колір кнопки прикріплення" && git push origin main
```

---

## ДОПИСАТИ В LESSONS.md

```
### [2026-05-03] мікрофікси
- save_note відповідь починається з ✅
- Кнопка прикріплення: isPinned = яскравий колір, відкріплена = приглушений
```
