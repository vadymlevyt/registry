# КОНТЕКСТ — Архітектура обробників (важелів агентів)
# Адміністративний чат | Legal BMS
# Дата: 11.04.2026
# Версія: 2.0 — оновлено після сесії QI фіксів

---

## ЩО ТАКЕ ОБРОБНИКИ

Обробники — це важелі керування для агентів.
Агент = водій. Обробник = педаль або кермо.
Агент може написати "виконую" — але якщо обробника немає в коді, нічого не відбувається.

---

## ПОТОЧНИЙ СТАН (після діагностики + 8 фіксів 11.04.2026)

Всі обробники зараз живуть всередині `sendChat()` в `App.jsx` — розкидані, без структури.

### Що є зараз в sendChat QI:

| Дія | Рядок | Статус |
|---|---|---|
| update_case_date | 1536 | ✅ є |
| update_deadline | 1557 | ✅ є (пофіксовано — тепер очищає null) |
| update_case_field | 1577 | ✅ є |
| update_case_status | 1577 alias | ✅ є |
| delete_case | 1623 | ✅ є |
| create_case | 1493 | ✅ є |
| save_note | — | ❌ немає |
| update_hearing | — | ❌ немає |
| add_hearing | — | ❌ немає |
| cancel_hearing | — | ❌ немає |
| batch_update | — | ❌ немає |
| transfer_to_dossier | — | ❌ немає |

**Важливо:** navigate_calendar / navigate_week прибрані з промпту QI — це зона дашборду.

---

## АРХІТЕКТУРНЕ РІШЕННЯ — ЄДИНИЙ РЕЄСТР ACTIONS

### Проблема поточного підходу

Обробники розкидані по різних місцях коду:
- частина в `sendChat()` QI
- частина в дашборді
- частина в досьє

Якщо додати нові обробники зараз в QI — потім їх треба викидати і переносити.
Подвійна робота + ризик зламати при переносі.

### Правильне рішення — Single Source of Truth для дій

Те саме що `registry_data.json` для даних — але для дій системи.

```javascript
// App.jsx — один реєстр ВСІХ дій системи:
const ACTIONS = {
  // Засідання
  add_hearing:         (params) => { ... },
  update_hearing:      (params) => { ... },
  cancel_hearing:      (params) => { ... },

  // Справи
  update_case_date:    (params) => { ... },
  update_case_field:   (params) => { ... },
  update_case_status:  (params) => { ... },
  update_deadline:     (params) => { ... },
  create_case:         (params) => { ... },
  delete_case:         (params) => { ... },

  // Нотатки
  save_note:           (params) => { ... },

  // Пакетні і складні
  batch_update:        (params) => { ... },
  transfer_to_dossier: (params) => { ... },
}

// Матриця повноважень:
const PERMISSIONS = {
  qi_agent:        ['add_hearing', 'update_hearing', 'update_deadline',
                    'update_case_field', 'update_case_status', 'create_case',
                    'save_note', 'batch_update'],

  dashboard_agent: ['update_hearing', 'cancel_hearing', 'update_deadline',
                    'navigate_calendar', 'navigate_week'],

  dossier_agent:   ['add_hearing', 'update_hearing', 'cancel_hearing',
                    'update_case_field', 'update_case_status', 'update_deadline',
                    'save_note', 'transfer_to_dossier'],

  main_agent:      [...все...],
}

// Єдина функція виконання для всіх агентів:
const executeAction = (agentId, action, params) => {
  if (!PERMISSIONS[agentId].includes(action)) {
    return { error: 'Немає повноважень' }
  }
  return ACTIONS[action](params);
}
```

### Що це дає

- Новий обробник → один раз в `ACTIONS`
- Новий доступ агенту → один рядок в `PERMISSIONS`
- Жодного розкиданого коду
- Легко перевіряти хто що може

---

## ЩО ПОТРІБНО ЗРОБИТИ В АДМІН ЧАТІ

### Крок 1 — Спроектувати повний список ACTIONS
Зібрати всі існуючі обробники з усіх місць коду.
Додати відсутні.
Уніфікувати назви і параметри.

### Крок 2 — Спроектувати матрицю PERMISSIONS
Для кожного агента — точний список що він може.
Базується на архітектурі повноважень з TASK_архітектура_даних v3.

### Крок 3 — TASK для Claude Code
Перенести існуючі обробники в єдиний ACTIONS.
Додати відсутні.
Замінити розкидані виклики на `executeAction(agentId, action, params)`.

---

## ЩО НЕ РОБИТИ ДО ЦИХ ЗМІН

❌ Не додавати нові обробники в sendChat QI
❌ Не додавати обробники в компоненти дашборду чи досьє
❌ Не латати — зробити одразу правильно

---

## ЗВ'ЯЗОК З РОЗВИТКОМ QI

Після реалізації ACTIONS + PERMISSIONS:

```
QI (Haiku + Sonnet в одному потоці):
Haiku читає файл → JSON
      ↓
Sonnet отримує контекст Haiku автоматично
      ↓
Sonnet каже "що зробити?"
      ↓
Ти командуєш
      ↓
Sonnet викликає executeAction('qi_agent', action, params)
      ↓
Система перевіряє повноваження → виконує
```

QI не тримає обробники в собі — він звертається до єдиного реєстру.

---

## КОНТЕКСТ QI → ГОЛОВНИЙ АГЕНТ

Окрема вкладка головного агента (Opus).
При переході — автоматично перевіряє чи є активний контекст з QI:

```
Питання стосується теми з QI → Opus отримує контекст QI діалогу
Питання про інше → контекст QI не передається, очищається
```

Реалізація — після ACTIONS + PERMISSIONS.

---

## СТАТУС

- Діагностика QI: ✅ завершена (11.04.2026)
- 8 точкових фіксів: ✅ задеплоєно
- Архітектура ACTIONS: 📋 спроектувати в адмін чаті
- Реалізація: ⏳ після адмін чату
