# TASK: Головний агент і інституційна пам'ять
## Статус: НЕ ВИКОНУВАТИ — чекає своєї черги
## Виконувати після: завершення Фази 3 (генератор документів)
## Пріоритет: високий (але не зараз)

---

## Контекст

Система накопичила достатньо модулів і даних.
Час додати координаційний шар — головного агента
який знає про всі модулі і інституційну пам'ять
яка накопичує досвід роботи бюро.

Детальна архітектура: ARCHITECTURE_AGENTS.md

---

## Що робиш

### Крок 1 — Інфраструктура логування рішень

В App.jsx додати функцію логування:

```javascript
const logDecision = (entry) => {
  const decision = {
    id: Date.now().toString(),
    timestamp: new Date().toISOString(),
    module: entry.module,
    action: entry.action,
    context: entry.context,
    result: entry.result
  };

  const decisions = JSON.parse(
    localStorage.getItem('levytskyi_decisions') || '[]'
  );
  decisions.push(decision);
  // зберігати тільки останні 500 рішень
  if (decisions.length > 500) decisions.shift();
  localStorage.setItem('levytskyi_decisions', JSON.stringify(decisions));
};
```

Додати виклик logDecision в кожному місці де адвокат
приймає рішення: схвалення контенту, вибір платформ,
відхилення матеріалів, зміна дат, оновлення полів справ.

---

### Крок 2 — Структура інституційної пам'яті

В App.jsx додати до спільного стану:

```javascript
const [institutionalMemory, setInstitutionalMemory] = useState({
  proceduralPatterns: [],
  tacticalDecisions: [],
  profilePreferences: {
    content: {},
    communication: {},
    workflow: {}
  },
  lastUpdated: null
});
```

Завантажувати при старті з Google Drive:
файл `institutional_memory.json` в папці системи.

---

### Крок 3 — Головний агент як компонент

Створити: `src/components/MainAgent/index.jsx`

Компонент не має UI — тільки логіку.
Отримує через props: всі спільні стани + logDecision.

Три функції:

**analyzeWeek()** — запускається вручну або через тригер:
- Читає decisions[] за останні 7 днів
- Передає Opus для аналізу
- Отримує висновки у форматі JSON
- Оновлює institutionalMemory через App.jsx

**routeQuery(query, fromModule)** — маршрутизація:
- Визначає який модуль може відповісти
- Якщо cross-module — формує відповідь сам з контекстом
- Повертає { answer, navigateTo, context }

**getMemoryForModule(module, category)** — вибірка пам'яті:
- Повертає релевантну частину інституційної пам'яті
- Використовується агентами модулів при ініціалізації

---

### Крок 4 — System prompt головного агента

```javascript
const MAIN_AGENT_PROMPT = `
Ти — головний агент Legal BMS адвокатського бюро Левицького.

ТВОЯ РОЛЬ: координація і накопичення досвіду.
НЕ виконуєш оперативні задачі — тільки аналізуєш і координуєш.

ДОСТУП:
- Всі справи: ${JSON.stringify(cases)}
- Інституційна пам'ять: ${JSON.stringify(institutionalMemory)}
- Рішення за тиждень: ${JSON.stringify(recentDecisions)}

ПРИ ТИЖНЕВОМУ АНАЛІЗІ повертай JSON:
{
  "new_patterns": [...],
  "updated_preferences": {...},
  "weekly_insights": "...",
  "recommendations": [...]
}

ПРИ МАРШРУТИЗАЦІЇ повертай JSON:
{
  "answer": "...",
  "navigate_to": "module_name або null",
  "context": {...}
}
`;
```

---

### Крок 5 — Інтеграція з n8n (опціонально)

Якщо n8n вже налаштований:
- Webhook тригер для запуску analyzeWeek() щонеділі о 23:00
- Після аналізу — надсилати звіт в Telegram адвокату

Формат звіту в Telegram:
```
📊 ТИЖНЕВИЙ ЗВІТ СИСТЕМИ

Справи: X активних, Y засідань на тижні
Контент: Z матеріалів опубліковано

💡 Головні висновки:
— [висновок 1]
— [висновок 2]

🎯 Рекомендації:
— [рекомендація 1]

Система оновила пам'ять ✓
```

---

### Крок 6 — Оновити CLAUDE.md

Додати розділ:

```markdown
## ГОЛОВНИЙ АГЕНТ І ІНСТИТУЦІЙНА ПАМ'ЯТЬ

Компонент: src/components/MainAgent/index.jsx
Пам'ять: institutional_memory.json на Google Drive
Рішення: localStorage 'levytskyi_decisions' (останні 500)

Правила:
- Головний агент НЕ має UI
- Отримує всі дані через props з App.jsx
- Не змінює дані напряму — тільки через функції App.jsx
- При падінні — не впливає на інші модулі (ErrorBoundary)
- logDecision() викликається в КОЖНОМУ місці
  де адвокат приймає рішення
```

---

## Перевірка після виконання

- [ ] logDecision() інтегрована у всі модулі
- [ ] institutionalMemory є в спільному стані App.jsx
- [ ] Файл institutional_memory.json читається з Drive
- [ ] MainAgent компонент підключений в App.jsx
- [ ] analyzeWeek() повертає коректний JSON
- [ ] routeQuery() правильно маршрутизує між модулями
- [ ] При падінні MainAgent система продовжує працювати
- [ ] Тижневий звіт приходить в Telegram

---

## Важливо

НЕ починати поки не реалізовані:
- Case Dossier
- Notebook
- Content Hub Ітерація 1

Перший крок коли прийде час — тільки logDecision().
Спочатку система збирає дані (2-4 тижні).
Потім запускається analyzeWeek().
Потім з'являється routeQuery().
Поступово — не все одразу.

git add -A && git commit -m "Main agent + institutional memory" && git push origin main
