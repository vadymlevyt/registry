# TASK: Підготовка спільного стану — перед новими модулями

## Контекст
Перед реалізацією Notebook і CaseDossier треба привести App.jsx до єдиної
архітектури даних. Всі модулі читають з одного місця і пишуть через одні функції.
Жоден модуль не тримає спільні дані всередині себе.

## Що робиш

### Крок 1 — Аудит updateCase

Знайди всі місця в App.jsx де відбувається пряма зміна `cases` через `setCases`.
Переконайся що всі вони йдуть через єдину функцію `updateCase(caseId, field, value)`.

Функція має виглядати так:
```js
const updateCase = (caseId, field, value) => {
  setCases(prev => prev.map(c =>
    c.id === caseId ? { ...c, [field]: value } : c
  ));
  // після оновлення стану — зберегти в Drive (викликати існуючу функцію sync)
};
```

Якщо є розкидані `setCases(...)` напряму в UI-обробниках — замінити на `updateCase`.
Логіку агента (`update_case_field`, `update_case_date` тощо) не чіпати — вона вже правильна.

---

### Крок 2 — Підняти calendarEvents з Dashboard в App.jsx

#### 2а. В App.jsx додати стан:
```js
const [calendarEvents, setCalendarEvents] = useState([]);
```

#### 2б. Додати функції управління подіями:
```js
const addCalendarEvent = (event) => {
  setCalendarEvents(prev => [...prev, { ...event, id: Date.now().toString() }]);
  // зберегти в Drive або localStorage під ключем 'levytskyi_calendar_events'
};

const updateCalendarEvent = (eventId, updates) => {
  setCalendarEvents(prev => prev.map(e =>
    e.id === eventId ? { ...e, ...updates } : e
  ));
};

const deleteCalendarEvent = (eventId) => {
  setCalendarEvents(prev => prev.filter(e => e.id !== eventId));
};
```

#### 2в. Завантажувати події при старті:
В існуючій функції завантаження даних (поряд з loadCases) — додати завантаження
calendarEvents з localStorage або Drive.

#### 2г. Передати в Dashboard через props:
```jsx
<Dashboard
  cases={cases}
  calendarEvents={calendarEvents}
  onAddEvent={addCalendarEvent}
  onUpdateEvent={updateCalendarEvent}
  onDeleteEvent={deleteCalendarEvent}
/>
```

#### 2д. В Dashboard/index.jsx:
- Прибрати локальний `useState` для calendarEvents
- Отримувати їх через props: `function Dashboard({ cases, calendarEvents, onAddEvent, onUpdateEvent, onDeleteEvent })`
- Замінити всі `setCalendarEvents(...)` на виклики `onAddEvent(...)`, `onUpdateEvent(...)`, `onDeleteEvent(...)`
- Вся інша логіка Dashboard залишається без змін

---

### Крок 3 — Додати notes[] як спільний стан

#### 3а. В App.jsx додати стан:
```js
const [notes, setNotes] = useState([]);
```

#### 3б. Додати функції:
```js
const addNote = (note) => {
  const newNote = {
    id: Date.now().toString(),
    text: note.text,
    category: note.category || 'general', // case | content | system | general
    caseId: note.caseId || null,
    createdAt: new Date().toISOString(),
  };
  setNotes(prev => [...prev, newNote]);
  // зберегти в Drive або localStorage під ключем 'levytskyi_notes'
};

const deleteNote = (noteId) => {
  setNotes(prev => prev.filter(n => n.id !== noteId));
  // оновити в Drive або localStorage
};
```

#### 3в. Завантажувати нотатки при старті:
Поряд з завантаженням cases — завантажити notes з localStorage('levytskyi_notes').
Якщо ключ порожній — порожній масив, не помилка.

#### 3г. Існуючі нотатки в localStorage:
Перевір чи є вже збережені нотатки під старим ключем (якщо є — мігрувати в новий формат).

---

### Крок 4 — Оновити CLAUDE.md

Додати в кінець файлу CLAUDE.md такий блок:

```markdown
## АРХІТЕКТУРНЕ ПРАВИЛО — СПІЛЬНИЙ СТАН

Єдине джерело правди для всіх модулів — App.jsx.

НЕ можна:
- Тримати cases[], notes[], calendarEvents[] всередині компонента
- Викликати setCases() напряму з компонента
- Дублювати дані між модулями

МОЖНА і ТРЕБА:
- Отримувати дані через props
- Змінювати дані через функції що прийшли через props (onAddNote, updateCase тощо)
- Тримати всередині компонента тільки UI-стан (відкрита вкладка, текст в полі вводу)

Функції зміни спільних даних живуть ТІЛЬКИ в App.jsx:
- updateCase(caseId, field, value)
- addNote(note) / deleteNote(noteId)
- addCalendarEvent(event) / updateCalendarEvent(id, updates) / deleteCalendarEvent(id)
```

---

## Перевірка після виконання

- [ ] Dashboard працює як раніше — Activity Feed, календар, Day Panel, drag слоти
- [ ] Нові події в Day Panel зберігаються (перевірити що після перезавантаження вони є)
- [ ] В App.jsx є `notes` стан і функції `addNote` / `deleteNote`
- [ ] В App.jsx є `calendarEvents` стан і три функції управління
- [ ] В CLAUDE.md з'явився блок про архітектурне правило
- [ ] Немає помилок в консолі браузера
- [ ] Сайт не показує білу сторінку після деплою

## Важливо
Не чіпати логіку агента (sendChat, ACTION_JSON парсинг) — тільки стан і props.
Не перейменовувати існуючі функції — тільки додавати нові або уніфіковувати.
Після виконання: git add -A && git commit -m "Shared state: lift calendarEvents, add notes[], unify updateCase" && git push origin main
