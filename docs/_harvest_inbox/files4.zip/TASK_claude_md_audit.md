# TASK: CLAUDE.md Audit + DEVELOPMENT_PHILOSOPHY.md Integration

**Дата створення:** 2026-05-06
**Виконавець:** Claude Code Opus
**Орієнтовна тривалість:** 30-60 хвилин
**Гілка:** main
**Пріоритет:** ВИСОКИЙ — оновлює документацію до v5.0 перед початком наступних модулів

---

## КОНТЕКСТ

Адвокат-архітектор провів три великих TASK:
1. ✅ SaaS Foundation v1 (commit 4f719fc)
2. ✅ SaaS Foundation v1.1 Patch and Extension (commit 94faf6c)
3. ✅ Billing Foundation v2 (commit 5a18320 + bug fixes commit 9b1ec40)

В адмін-чаті за 06.05.2026 проведено розширене обговорення архітектури і філософії розробки. Результати зведено в **два нових файли** які треба інтегрувати в репозиторій:

1. **CLAUDE.md v5.0** — повна нова версія, замінює старий CLAUDE.md
2. **DEVELOPMENT_PHILOSOPHY.md** — новий файл з принципами розробки

Обидва файли передаються через `/mnt/user-data/uploads/` (адвокат завантажить їх перед запуском цього TASK).

---

## ЦІЛЬ TASK

**Інтегрувати** нові CLAUDE.md і DEVELOPMENT_PHILOSOPHY.md у репозиторій з **обов'язковою звіркою з реальним станом коду**.

Не просто скопіювати — **перевірити** що описане в нових файлах відповідає реальності. Якщо знайдено невідповідності — задокументувати у новому файлі `bugs_found_during_claude_md_audit.md`.

---

## ФАЗА 0 — ПРИЙОМКА І ПЕРВИННА ПЕРЕВІРКА

### Крок 0.1 — Прочитати нові файли

```bash
ls -la /mnt/user-data/uploads/CLAUDE.md
ls -la /mnt/user-data/uploads/DEVELOPMENT_PHILOSOPHY.md
cat /mnt/user-data/uploads/CLAUDE.md | head -100
cat /mnt/user-data/uploads/DEVELOPMENT_PHILOSOPHY.md | head -100
```

Підтвердити:
- Файли наявні
- Розмір розумний (CLAUDE.md ~500-700 рядків, DEVELOPMENT_PHILOSOPHY.md ~400-500)
- Структура файлів відповідає markdown

### Крок 0.2 — Зберегти бекап старого CLAUDE.md

```bash
cp CLAUDE.md CLAUDE.md.backup-pre-v5
git add CLAUDE.md.backup-pre-v5
```

(Бекап залишається в репо для безпеки. Видалити можна окремим TASK через тиждень якщо все добре.)

### Крок 0.3 — Запустити поверхневу діагностику

Створити файл `diagnostic_claude_md_audit.md` з:

```markdown
# Діагностика CLAUDE.md Audit

## Поточний стан репо
- git log: останні 5 коммітів
- schemaVersion в migrationService.js: ?
- Перелік сервісів у src/services/: ?
- Кількість рядків у App.jsx: ?
- Перелік компонентів у src/components/: ?

## Перевірка нового CLAUDE.md проти реального коду

### Розділ "Структура файлів"
[пройтись по описаній структурі і перевірити що все існує]

### Розділ "Сервіси SaaS Foundation"
[перевірити що всі описані сервіси реально існують і мають описані функції]

### Розділ "Сервіси Billing Foundation"
[те саме для Billing]

### Розділ "Інструментація — 25 точок"
[перевірити що 25 точок activityTracker.report реально присутні]

### Розділ "Точки виклику Anthropic API — 10 шт"
[перевірити]

## Знайдені невідповідності
[якщо є — списком]

## Готовність
- Чи можна інтегрувати CLAUDE.md як є?
- Які пункти потребують уточнень/виправлень?
```

**Зупинитись і чекати рішення** якщо знайдено критичні невідповідності.

Якщо тільки дрібні (наприклад "сервіс називається trochi іначе") — виправити у фінальному CLAUDE.md і продовжити.

---

## ФАЗА 1 — ІНТЕГРАЦІЯ ФАЙЛІВ

### Крок 1.1 — Інтегрувати DEVELOPMENT_PHILOSOPHY.md

```bash
cp /mnt/user-data/uploads/DEVELOPMENT_PHILOSOPHY.md ./DEVELOPMENT_PHILOSOPHY.md
git add DEVELOPMENT_PHILOSOPHY.md
```

Це новий файл — його ще немає в репо, просто додаємо.

### Крок 1.2 — Інтегрувати CLAUDE.md v5.0

```bash
cp /mnt/user-data/uploads/CLAUDE.md ./CLAUDE.md
```

Це **замінює** старий CLAUDE.md. Бекап вже зроблено в кроці 0.2.

### Крок 1.3 — Перевірити що файли коректно прочитуються

```bash
head -50 CLAUDE.md
head -50 DEVELOPMENT_PHILOSOPHY.md
wc -l CLAUDE.md DEVELOPMENT_PHILOSOPHY.md
```

Розміри мають бути приблизно як у вихідних файлах.

---

## ФАЗА 2 — ЗВІРКА З РЕАЛЬНИМ КОДОМ

### Крок 2.1 — Перевірити структуру файлів

CLAUDE.md описує структуру `src/services/`:

```
tenantService.js, permissionService.js — SaaS Foundation
auditLogService.js, migrationService.js
aiUsageService.js, modelResolver.js, subscriptionService.js
activityTracker.js, masterTimer.js, timeStandards.js
smartReturnHandler.js, timeEntriesArchiver.js, timeEntriesQuery.js
moduleNames.js
```

```bash
ls -la src/services/
ls -la src/services/ocr/
```

Звірити:
- ✅ Всі описані сервіси існують
- ⚠️ Якщо сервіс згадується в CLAUDE.md але не існує — записати в bugs_found
- ⚠️ Якщо сервіс існує але не згаданий в CLAUDE.md — записати

### Крок 2.2 — Перевірити schemaVersion

```bash
grep -n "schemaVersion" src/services/migrationService.js | head -10
grep -n "MIGRATION_VERSION" src/services/migrationService.js | head -10
```

CLAUDE.md очікує:
- `CURRENT_SCHEMA_VERSION = 4`
- `MIGRATION_VERSION = '4.0_billing_foundation'`

Якщо реальність інша — фіксити CLAUDE.md, не код.

### Крок 2.3 — Перевірити структуру ACTIONS і PERMISSIONS

```bash
grep -n "const ACTIONS = {" src/App.jsx
grep -n "const PERMISSIONS = {" src/App.jsx
```

Підрахувати скільки реально дій. CLAUDE.md каже "19+ дій".

### Крок 2.4 — Перевірити 25 точок інструментації

```bash
grep -rn "activityTracker.report" src/components/ src/App.jsx | wc -l
```

Має бути приблизно 25 точок (може більше якщо Claude Code додав фікси).

### Крок 2.5 — Перевірити 10 точок виклику Anthropic API

```bash
grep -rn "api.anthropic.com" src/ | wc -l
```

Має бути 10 (або трохи більше якщо нові точки додано).

### Крок 2.6 — Перевірити moduleNames.js

```bash
cat src/services/moduleNames.js | head -50
```

CLAUDE.md описує MODULES enum + categoryForCase().

---

## ФАЗА 3 — ДОПОВНЕННЯ І УТОЧНЕННЯ

### Крок 3.1 — Додати дрібниці які могли пропустити

Якщо під час Фази 2 знайдено реальні елементи коду які не описані в CLAUDE.md:

**Приклади що могло бути пропущено:**

1. **Bug fixes commit 9b1ec40** — створено `moduleNames.js` з `MODULES` enum і `categoryForCase()` хелпер. CLAUDE.md це згадує, але треба перевірити що деталі точні.

2. **Імена констант** — переконатись що написані як в реальному коді (camelCase, snake_case, etc).

3. **Параметри функцій** — звірити сигнатури функцій з реальним кодом.

### Крок 3.2 — Не змінювати філософські розділи

Розділи про філософію, ДНК, варіабельність, агентну архітектуру **не міняти** — це результат довгих обговорень з адвокатом. Якщо щось здається неточним — фіксувати в `bugs_found_during_claude_md_audit.md`, але **не змінювати у CLAUDE.md**.

### Крок 3.3 — Перевірити перехресні посилання

CLAUDE.md посилається на:
- `LESSONS.md` — перевірити що існує
- `DEVELOPMENT_PHILOSOPHY.md` — щойно додали
- `recommended_task_claude_md_audit.md` — існує?
- `bugs_found_during_billing_foundation.md` — існує?

```bash
ls -la LESSONS.md DEVELOPMENT_PHILOSOPHY.md *recommended* *bugs_found* 2>/dev/null
```

Якщо файли не існують — згадати в `bugs_found_during_claude_md_audit.md`. Не створювати порожні файли.

---

## ФАЗА 4 — VITE BUILD ПЕРЕВІРКА

```bash
cd /workspaces/registry
npm run build 2>&1 | tail -20
```

CLAUDE.md/DEVELOPMENT_PHILOSOPHY.md — це markdown, build їх не торкається. Але перевірити що ніщо не зламалось:

- ✅ Build проходить
- ✅ Жодних попереджень про відсутні файли
- ✅ dist/ генерується нормально

Якщо build падає — це НЕ через цей TASK, але треба зафіксувати і повідомити.

---

## ФАЗА 5 — ДОКУМЕНТАЦІЯ І COMMIT

### Крок 5.1 — Створити звіт

`report_claude_md_audit.md`:

```markdown
# Звіт CLAUDE.md Audit

## Виконано
- ✅ Бекап старого CLAUDE.md → CLAUDE.md.backup-pre-v5
- ✅ Інтегровано CLAUDE.md v5.0
- ✅ Додано DEVELOPMENT_PHILOSOPHY.md
- ✅ Звірено з реальним кодом (Фаза 2)
- ✅ Vite build успішний

## Знахідки
[якщо є — короткий перелік з посиланням на bugs_found]

## Метрики
- Розмір нового CLAUDE.md: X рядків
- Розмір DEVELOPMENT_PHILOSOPHY.md: Y рядків
- Точок інструментації знайдено: Z
- Точок виклику Anthropic API: W

## Часові витрати
- Загалом: X хвилин

## Що далі
- Документація актуальна для v4.0 системи
- Готова основа для наступного TASK Document Processor v2 + Context Generator
```

### Крок 5.2 — Один атомарний commit

```bash
git add CLAUDE.md DEVELOPMENT_PHILOSOPHY.md CLAUDE.md.backup-pre-v5
git add diagnostic_claude_md_audit.md report_claude_md_audit.md
git add bugs_found_during_claude_md_audit.md  # якщо є
git status  # перевірити що нічого зайвого

git commit -m "docs: CLAUDE.md v5.0 + DEVELOPMENT_PHILOSOPHY.md

- Replace CLAUDE.md with v5.0 (post Billing Foundation)
- Add DEVELOPMENT_PHILOSOPHY.md (DNA principles for new modules)
- Integrate SaaS v2.0, v3.0, Billing v4.0 sections
- Add 10 critical rules (was 5, added schemaVersion, executeAction async, Drive cyrillic, embryo DNA, IMPLICATIONS sections)
- Document Tool Use strategy (no separate prep TASK)
- Document AI Provider Abstraction roadmap (deferred 6-12 months)
- Reference architecture: planka Picatinny, executeAction archivist, cellular module isolation
- Document Processor v2 + Context Generator as upcoming joint TASK

Closes: recommended_task_claude_md_audit.md (TASK from SaaS Foundation v1)"
```

### Крок 5.3 — Push

```bash
git push origin main
```

GitHub Actions deploy не залежить від цих файлів — спрацює, але нічого функціонально не зміниться (це чисто документація).

---

## ФАЗА 6 — ВЕРИФІКАЦІЯ ПІСЛЯ DEPLOY

```bash
# Перевірити що файли на main
git log -1 --stat

# Перевірити що commit в origin
git log origin/main..HEAD --oneline
# (має бути порожньо — все запушено)

# Останній перевірочний підрахунок
echo "---"
echo "CLAUDE.md: $(wc -l < CLAUDE.md) рядків"
echo "DEVELOPMENT_PHILOSOPHY.md: $(wc -l < DEVELOPMENT_PHILOSOPHY.md) рядків"
echo "Backup: $(ls -la CLAUDE.md.backup-pre-v5 | awk '{print $5}') bytes"
```

---

## ВАЖЛИВІ ОБМЕЖЕННЯ

### Що НЕ робити в цьому TASK

1. **НЕ міняти код** — це чистий documentation TASK
2. **НЕ створювати нові сервіси** на основі описаних в CLAUDE.md
3. **НЕ виправляти баги які знайшов** — тільки фіксувати в `bugs_found_during_claude_md_audit.md`
4. **НЕ змінювати філософські розділи** в CLAUDE.md і DEVELOPMENT_PHILOSOPHY.md
5. **НЕ видаляти старі контекстні файли** з проекту (вони ще можуть знадобитись)

### Якщо щось дуже неправильне

Якщо під час звірки знайдено **критичну невідповідність** (наприклад CLAUDE.md описує сервіс якого не існує і це не дрібниця):

1. Зупинитись
2. Записати в diagnostic_claude_md_audit.md
3. Чекати рішення адвоката

---

## КРИТЕРІЇ ЗАВЕРШЕННЯ TASK

- [ ] CLAUDE.md замінено на v5.0
- [ ] DEVELOPMENT_PHILOSOPHY.md додано
- [ ] CLAUDE.md.backup-pre-v5 збережено
- [ ] diagnostic_claude_md_audit.md створено з результатами звірки
- [ ] report_claude_md_audit.md створено
- [ ] bugs_found_during_claude_md_audit.md створено (якщо є знахідки)
- [ ] Vite build проходить
- [ ] Один commit з усім вище
- [ ] Push в origin/main
- [ ] Deploy успішний

---

## ОЧІКУВАНА ТРИВАЛІСТЬ

- Фаза 0 (прийомка + діагностика): 10 хв
- Фаза 1 (інтеграція файлів): 5 хв
- Фаза 2 (звірка з кодом): 15 хв
- Фаза 3 (доповнення): 10 хв
- Фаза 4 (build): 2 хв
- Фаза 5 (commit + push): 3 хв
- Фаза 6 (верифікація): 2 хв

**Загалом:** ~45 хв

Може бути швидше — багато з цього вже відомо Claude Code з попередніх TASK.

---

**Кінець TASK CLAUDE.md Audit.**
