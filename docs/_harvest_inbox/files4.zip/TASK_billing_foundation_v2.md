# TASK: Billing Foundation v2 — Internal Time Tracking Infrastructure

**Версія:** 2.0 (адаптовано під SaaS v3.0)
**Дата створення:** 05.05.2026
**Очікувана тривалість:** 6-8 днів роботи Claude Code
**Пріоритет:** ВИСОКИЙ — третій інфраструктурний фундамент після SaaS Foundation v1.1
**Залежності:**
- ✅ TASK SaaS Foundation v1 (commit 4f719fc)
- ✅ TASK SaaS Foundation v1.1 Patch and Extension (commit 94faf6c)
**Гілка:** main

---

## 🎯 КОНТЕКСТ І ЗВ'ЯЗОК З ПОПЕРЕДНІМИ TASK

SaaS Foundation v1.1 вже заклав:
- `ai_usage[]` — телеметрія для оператора (хто скільки токенів спалив)
- `tenant.subscription.{limits, current, alerts}` — структури обліку лімітів
- `resolveModel()` helper з ієрархією user → tenant → system
- Активна `checkTenantAccess` і `checkCaseAccess` ізоляція

Цей TASK закладає **окрему паралельну інфраструктуру для адвоката**:
- `time_entries[]` — облік часу адвоката для CRM/білінгу клієнту (НЕ те саме що `ai_usage[]`)
- `master_timer_state` — внутрішній час системи
- Стандарти часу за судами/категоріями
- Місячна ротація з архівами на Drive
- API запитів `getTimeEntries` для майбутньої агентської аналітики

**Дві паралельні структури — дві різні задачі:**

```
ai_usage[] (з v1.1)              time_entries[] (новий)
──────────────────────           ──────────────────────
Для тебе як SaaS-оператора:      Для адвоката як практика:
- хто скільки токенів спалив     - скільки часу витратив на справу
- скільки коштує користувач      - що в акт виконаних робіт
- ліміти пакетів                 - доказова база ст.141 ЦПК
- LIFO 50000, в registry         - місячна ротація + архіви
──────────────────────           ──────────────────────
```

---

## 🧬 ФІЛОСОФІЯ — 13 ТЕЗ БІЛІНГУ

(Зведено з адмін-чату «CRM і Білінг». Формує всю архітектуру TASK.)

1. **Метафізика робочого дня.** Система бачить день як цілісний відрізок, кожна хвилина куди-небудь приписується.

2. **Внутрішнє ≠ зовнішнє.** Внутрішній облік повний до хвилини. Зовнішнє (клієнту) — фільтроване.

3. **CRM не модуль, а зріз.** Той самий time_entries[], переглянутий через призму клієнта.

4. **Інструментація зараз, UI потім.** Дані накопичуються з самого початку. Через рік увімкнули UI — є рік історії.

5. **Голос як основа, не фіча.** Скрізь мікрофон. Адвокат не повинен бути секретарем у себе самого.

6. **Семантичне розуміння переходів.** Система не фіксує клік — розуміє що клік означає.

7. **Категоризовані таймери.** Кожна категорія знає тривалість, чи billable, чи прив'язується до справи.

8. **Master timer + субтаймери.** Майстер тікає весь день. Субтаймери розкладають час по конкретних діях.

9. **Idle Detection — бонус.** На Chrome додатковий контроль. На Safari/iPad — стандарти і голос.

10. **Облік працює навіть коли адвокат поза системою.** Засідання у календарі — система знає що це година + дорога.

11. **Білінг як орган.** Завжди є архітектурно. Адвокат вирішує наскільки бачити: full / simplified / classic.

12. **Звіти як живі зрізи.** Не зберігаються готовими, формуються з потоку логів. 4 рівні: резюме, акт, AI-narrative, сирі логи.

13. **Розмовна аналітика.** Сторінка аналітики не з фільтрами, а порожнє полотно + чат з агентом.

---

## ⚠️ ФАЗА 0 — ОБОВ'ЯЗКОВА ДІАГНОСТИКА ПЕРЕД ВПРОВАДЖЕННЯМ

Як і в попередніх двох TASK, починаємо з обов'язкової діагностики. Claude Code створює `diagnostic_billing_foundation.md` і чекає згоди.

### Що перевірити в діагностиці

#### 1. Стан системи після SaaS v1.1

```bash
grep -n "schemaVersion" src/services/migrationService.js
cat src/services/migrationService.js | head -50
ls -la src/services/
```

Підтвердити:
- `schemaVersion: 3`, `settingsVersion: "3.0_patch_and_extension"`
- Існують: `aiUsageService.js`, `modelResolver.js`, `subscriptionService.js`
- `ai_usage[]`, `caseAccess[]`, `tenant.storage`, `tenant.modelPreferences`, `tenant.subscription` структури присутні
- `case.id` всі string (case_<n>)
- Виправлений архітектурний борг (writeCases видалено, action_log видалено, agentHistory slice 50)

Якщо щось з цього **не виконано** — Claude Code зупиняється з повідомленням: «Спочатку завершити SaaS Foundation v1.1».

#### 2. Існуючий `levytskyi_timelog` в localStorage

В пам'яті проекту згадувався `timeLog` як старий механізм обліку часу. Перевірити:
- Чи існує такий ключ в localStorage
- Які поля містить
- Скільки записів
- Чи можна імпортувати в новий `time_entries[]` як стартові дані

#### 3. Існуючий `case.timeLog` (вкладений масив у справах)

З мiграції в SaaS Foundation v1 ми бачили що `case.timeLog[i]` отримав `createdBy`. Перевірити:
- Чи є записи в `timeLog` хоча б у одній справі
- Структура кожного запису
- План міграції в новий `time_entries[]` (на верхньому рівні registry_data.json)

#### 4. Структура hearings — точки інтеграції автоматичного обліку (Теза 10)

Перевірити для кожної справи:
- Поля `travelToMinutes`, `travelFromMinutes` (з пам'яті проекту: TASK Travel Time Fix)
- Поля `duration` (тривалість засідання)
- Status (`scheduled`, `completed`, `postponed`, `cancelled`)
- Категорії причин відкладення (якщо є)

#### 5. Інвентаризація точок інструментації

Для кожного модуля знайти ключові точки де відбуваються дії адвоката:

```bash
grep -rn "useState\|useEffect" src/components/Dashboard/index.jsx | head -30
grep -rn "useState\|useEffect" src/components/CaseDossier/index.jsx | head -30
grep -rn "executeAction" src/App.jsx | head -30
```

Для кожної точки зафіксувати:
- Файл і рядок
- Назва події (event_type)
- Які дані доступні (caseId, hearingId, content)
- Чи доцільно фіксувати (значущість > шум)

#### 6. Розмір даних — реалістична оцінка

Розрахувати:
- При 50-100 подій/день очікуємо 1500-3000 записів time_entries за місяць
- Розмір одного запису ~300-500 байт
- За місяць: 0.7-1.5 MB
- Реальна оцінка: чи витримує парсинг при поточному стані registry_data.json (~82 KB зараз)

#### 7. Перевірка чи `ai_usage[]` працює правильно

З поточного стану системи (з аналізу registry_data.json):
- 5 записів від агента досьє (правильно)
- Поля: agentType, model, tokens, cost, context
- `caseId: "case_4"` (правильно після id migration)

Підтвердити що `time_entries[]` буде логічним розширенням існуючої логіки логування.

#### 8. Backup-стратегія

Перевірити:
- Існують `backupRegistryData` (з SaaS v1) та `backupRegistryDataPreV3` (з SaaS v1.1)
- Поточний backup retention
- Куди писати `registry_data_backup_pre_billing_<ts>.json`

### Артефакт фази 0

`diagnostic_billing_foundation.md` з:
1. Підтвердженням `schemaVersion: 3` і всіх нових структур з v1.1
2. Стан `levytskyi_timelog` і `case.timeLog`
3. Картою всіх точок інструментації по модулях
4. Структурою hearings (для автоматичного обліку Теза 10)
5. Розрахунком розміру даних
6. Питаннями до адвоката (Q1, Q2, ...) — якщо щось неоднозначне
7. Адаптованим планом виконання з конкретними файлами і рядками

**Зупинка для отримання згоди.** Не починати впровадження без явної команди «продовжуй».

---

## АРХІТЕКТУРНА КАРТИНА — ШАРИ СИСТЕМИ ПІСЛЯ TASK

```
ПІСЛЯ TASK BILLING FOUNDATION v2
═══════════════════════════════════════════════════════════════

ШАР 1 — ВНУТРІШНЯ ЛОГІКА (завжди ввімкнена, незмінна)
────────────────────────────────────────────────────
Існуючий (з SaaS v1.1):
├─ ai_usage[] — оператор-телеметрія
├─ aiUsageService.js — облік токенів
├─ modelResolver.js — ієрархія моделей
└─ subscriptionService.js — recalculateCurrent

НОВЕ (Billing Foundation):
├─ activityTracker.js — фіксація подій адвоката
├─ time_entries[] — облік часу адвоката
├─ master_timer_state — стан таймера
├─ masterTimer.js — state machine
├─ timeStandards.js — резолюція стандартів
├─ timeEntriesArchiver.js — місячна ротація
├─ timeEntriesQuery.js — getTimeEntries API
└─ subscriptionService.js — інтеграція time_entries

         │
         ▼

ШАР 2 — НАЛАШТУВАННЯ UI РЕЖИМУ (вибір адвоката)
─────────────────────────────────────────────────
└─ user.preferences.billing_ui_mode:
   "off" (default) | "classic" | "simplified" | "full"

         │
         ▼

ШАР 3 — ВІЗУАЛЬНИЙ ШАР (закладається мінімально)
────────────────────────────────────────────────
└─ Поки нічого видимого
   Повний UI — окремий TASK Billing UI через 6+ міс.

═══════════════════════════════════════════════════════════════
```

---

## СТРУКТУРА ДАНИХ — ЩО ДОДАЄТЬСЯ

### Розширення `registry_data.json` v3 → v4

```json
{
  "schemaVersion": 4,
  "settingsVersion": "4.0_billing_foundation",
  
  // Існуючі структури (з v1, v1.1):
  "tenants": [...],
  "users": [...],
  "auditLog": [...],
  "structuralUnits": [...],
  "ai_usage": [...],
  "caseAccess": [...],
  "cases": [...],
  
  // НОВЕ — структури білінгу:
  "time_entries": [...],
  "master_timer_state": {...},
  "billing_meta": {...}
}
```

### Структура `time_entries[]`

```json
{
  "id": "te_1714814400_abc",
  "tenantId": "ab_levytskyi",
  "userId": "vadym",
  "createdAt": "2026-05-04T15:00:00Z",
  
  "type": "session" | "action" | "hearing" | "travel" | "external",
  "module": "case_dossier" | "dashboard" | "qi" | "notebook" | "document_processor" | "system",
  "action": "tab_switched" | "document_viewed" | "agent_message" | "...",
  
  "caseId": "case_4" | null,
  "hearingId": "hearing_xyz" | null,
  "documentId": "doc_abc" | null,
  
  "duration": 88,
  "startTime": "2026-05-04T15:00:00Z",
  "endTime": "2026-05-04T15:01:28Z",
  
  "category": "case_work" | "hearing_attendance" | "hearing_preparation" | "travel" | "client_communication" | "admin" | "system" | "break",
  "subCategory": "document_review" | "agent_chat" | "drafting" | "...",
  "billable": true,
  "visibleToClient": true,
  "billFactor": 1.0,
  
  "status": "draft" | "confirmed" | "archived",
  
  "metadata": {
    "tabFrom": "overview",
    "tabTo": "materials",
    "viaAgent": false
  }
}
```

**Ключове відрізняння від `ai_usage[]`:**
- `time_entries[]` має `duration` (тривалість роботи адвоката)
- `time_entries[]` має `category` і `billable` (для актів клієнту)
- `ai_usage[]` має `inputTokens/outputTokens` (для оператора SaaS)

При виклику AI з агента досьє пишемо в **обидві** структури:
- `ai_usage[]` — токени, модель, вартість для тебе
- `time_entries[]` — час сесії з агентом для адвоката

### Структура `master_timer_state`

```json
{
  "isActive": true,
  "isPaused": false,
  "state": "active" | "paused" | "idle" | "stopped",
  "startedAt": "2026-05-04T08:30:00Z",
  "pausedAt": null,
  "totalSecondsToday": 8640,
  "lastActivityAt": "2026-05-04T15:00:00Z",
  "activeCaseId": "case_4",
  "activeCategory": "case_work",
  "lastIdleCheck": "2026-05-04T14:55:00Z"
}
```

### Структура `billing_meta`

```json
{
  "currentMonthStart": "2026-05-01T00:00:00Z",
  "lastArchiveCreated": "2026-04-30T23:59:00Z",
  "totalEntriesAllTime": 4523,
  "currentMonthEntries": 1840,
  "archiveFiles": [
    "_archives/time_entries_2026-04.json",
    "_archives/time_entries_2026-03.json"
  ]
}
```

### Розширення `tenant.settings.timeStandards`

```json
{
  "timeStandards": {
    "by_court": {
      "Дарницький районний суд м. Києва": { "travel": { "to": 60, "from": 60 } },
      "Шевченківський районний суд м. Києва": { "travel": { "to": 30, "from": 30 } },
      "Печерський районний суд м. Києва": { "travel": { "to": 45, "from": 45 } }
    },
    "by_city": {
      "Київ": { "travel": { "to": 60, "from": 60 } },
      "Львів": { "travel": { "to": 90, "from": 90 } }
    },
    "by_activity": {
      "hearing_simple": 60,
      "hearing_complex": 120,
      "advocate_request": 30,
      "client_meeting": 60,
      "phone_call": 15,
      "document_drafting": 60,
      "case_research": 90
    },
    "default_travel": { "to": 60, "from": 60 }
  }
}
```

### Розширення `user.preferences`

```json
{
  "user.preferences": {
    "billing_ui_mode": "off",
    "timeStandards": {},
    "masterTimerVisible": false,
    "autoStartMasterTimer": false,
    "modelPreferences": {}
  }
}
```

**Дефолт `billing_ui_mode: "off"`** — поточний UI не змінюється. Білінг тихо працює всередині.

---

## АРХІТЕКТУРА `activityTracker.js`

### API

```javascript
// Базове сповіщення про подію
activityTracker.report(eventType, context = {})

// Сесія роботи
activityTracker.startSession(caseId, module, options = {})
activityTracker.endSession()

// Зовнішні таймери (Word, Claude, пошта)
activityTracker.startExternalTimer(category, caseId, options = {})
activityTracker.endExternalTimer()

// Master timer
activityTracker.startMasterTimer()
activityTracker.pauseMasterTimer(reason = 'manual')
activityTracker.stopMasterTimer()
activityTracker.resumeMasterTimer()

// Запит даних
activityTracker.getEntries(query) // делегує в timeEntriesQuery
```

### Внутрішні механізми

- Master timer тікає кожну секунду в фоні
- Auto-pause через 5 хв бездіяльності (Idle Detection або відсутність взаємодії)
- Persistence в `master_timer_state` кожні 60 секунд
- Recovery при reload з останнього стану
- Cross-tab synchronization через BroadcastChannel або localStorage events
- Try/catch навколо кожного `report()` — падіння не блокує основний flow

### Структура файлів

```
src/services/activityTracker.js          (центральна логіка)
src/services/masterTimer.js              (state machine)
src/services/timeEntriesArchiver.js      (місячна ротація)
src/services/timeEntriesQuery.js         (getTimeEntries API)
src/services/timeStandards.js            (резолюція стандартів)
```

---

## ПОДІЛ НА ФАЗИ ВПРОВАДЖЕННЯ

### Фаза 0 — Діагностика (1-2 год)

Виконано вище. Створює `diagnostic_billing_foundation.md` і чекає згоди.

### Фаза 1 — Базова інфраструктура `activityTracker` (1 день)

**Створюється:**
- `src/services/activityTracker.js` — центральна служба
- `src/services/timeEntriesArchiver.js` — заглушка ротації
- `src/services/masterTimer.js` — state machine
- `src/services/timeStandards.js` — резолюція стандартів

**Розширення:**
- `registry_data.json` — додати `time_entries[]`, `master_timer_state`, `billing_meta`
- `migrationService.js` — додати `migrateV3toV4`
- `tenantService.js` — `DEFAULT_TENANT.settings.timeStandards`
- Імпорт даних з `levytskyi_timelog` (якщо є) і `case.timeLog[]` в новий `time_entries[]`

**Хук в існуючий код:**
- `executeAction` — після виконання звітує в activityTracker (значущі події)
- `writeRegistry` — періодичний save включає time_entries

**API працює:**
- `report()` пише в `time_entries[]`
- `startSession() / endSession()` працюють
- `startMasterTimer() / stopMasterTimer()` працюють (без UI)

**Тестування:**
- Виклик `activityTracker.report()` з різних місць → записи в registry
- Drive sync працює

### Фаза 2 — Інструментація існуючих модулів (2 дні)

В кожному модулі додаємо точкові виклики `activityTracker.report()`. Один-два рядки на місце, без зміни логіки.

#### Dashboard (`src/components/Dashboard/index.jsx`)

```javascript
// При відкритті дашборду
useEffect(() => {
  activityTracker.startSession(null, 'dashboard');
  return () => activityTracker.endSession();
}, []);

// При перегляді засідання
const handleHearingView = (hearing) => {
  activityTracker.report('hearing_viewed', { 
    hearingId: hearing.id, 
    caseId: hearing.caseId 
  });
};

// Drag-create
const handleSlotDragCreate = (caseId, slotInfo) => {
  activityTracker.report('event_drag_create', { caseId });
};

// Оновлення статусу засідання
const handleHearingStatusUpdate = (hearing, newStatus) => {
  activityTracker.report('hearing_status_changed', {
    hearingId: hearing.id,
    caseId: hearing.caseId,
    from: hearing.status,
    to: newStatus
  });
};

// Повідомлення агенту
const handleAgentMessage = async (message) => {
  activityTracker.report('agent_message_dashboard', { messageLen: message.length });
};
```

#### CaseDossier (`src/components/CaseDossier/index.jsx`)

```javascript
// Відкриття досьє
useEffect(() => {
  activityTracker.startSession(caseData.id, 'case_dossier');
  return () => activityTracker.endSession();
}, [caseData.id]);

// Перемикання вкладок
const handleTabChange = (tab) => {
  activityTracker.report('dossier_tab_switched', {
    caseId: caseData.id,
    tabFrom: activeTab,
    tabTo: tab
  });
};

// Перегляд документа
const handleDocumentView = (doc) => {
  activityTracker.report('document_viewed', {
    caseId: caseData.id,
    documentId: doc.id
  });
};

// Чат з агентом
const handleAgentMessage = async (message) => {
  activityTracker.report('agent_message_dossier', {
    caseId: caseData.id,
    messageLen: message.length
  });
};

// Регенерація контексту
const handleContextRegenerate = async () => {
  activityTracker.report('context_regenerated', {
    caseId: caseData.id
  });
};

// Глибокий аналіз (Opus)
const handleDeepAnalysis = async () => {
  activityTracker.report('agent_deep_analysis', {
    caseId: caseData.id
  });
};
```

#### QuickInput (`src/components/QuickInput/...`)

```javascript
const handleDocumentUpload = async (file) => {
  activityTracker.report('qi_document_uploaded', {
    fileType: file.type,
    fileSize: file.size
  });
};

const handleVoiceInput = async (audioBlob) => {
  activityTracker.report('qi_voice_input', { duration: audioBlob.duration });
};

const handleActionExecute = async (action) => {
  activityTracker.report('qi_action_executed', {
    action: action.type,
    caseId: action.caseId
  });
};
```

#### Notebook (`src/components/Notebook/...`)

```javascript
const handleNoteCreate = async (note) => {
  activityTracker.report('note_created', {
    caseId: note.caseId,
    category: note.category,
    contentLen: note.content.length
  });
};

const handleNoteEdit = async (note) => {
  activityTracker.report('note_edited', {
    caseId: note.caseId,
    noteId: note.id
  });
};
```

#### DocumentProcessor (`src/components/DocumentProcessor/...`)

```javascript
const handleBatchStart = (files) => {
  activityTracker.report('docproc_batch_started', {
    caseId,
    fileCount: files.length,
    totalSize: files.reduce((s, f) => s + f.size, 0)
  });
};

const handleOcrProcessed = (file, result) => {
  activityTracker.report('docproc_ocr_processed', {
    caseId,
    fileName: file.name,
    pages: result.pages.length
  });
};

const handleSplitProposed = (proposal) => {
  activityTracker.report('docproc_split_proposed', {
    caseId,
    documentsCount: proposal.documents.length
  });
};

const handleSplitConfirmed = (proposal) => {
  activityTracker.report('docproc_split_confirmed', {
    caseId,
    documentsCount: proposal.documents.length
  });
};

const handleBatchComplete = (result) => {
  activityTracker.report('docproc_batch_completed', {
    caseId,
    documentsAdded: result.documentsAdded
  });
};
```

#### App.jsx — глобальні події

```javascript
// При запуску
useEffect(() => {
  activityTracker.report('app_launched');
}, []);

// Навігація між модулями
const handleNavigate = (newModule) => {
  activityTracker.report('module_navigation', {
    from: currentModule,
    to: newModule
  });
};

// CRUD справ — додаємо хуки
async function addCase(...) {
  // existing logic
  activityTracker.report('case_created', { caseId: newCase.id });
}

async function closeCase(...) {
  // existing logic
  activityTracker.report('case_closed', { caseId });
}

// hearing CRUD operations через executeAction — автоматично 
// через хук в executeAction (з фази 1)
```

**Принципи інструментації:**
- Try/catch навколо кожного `activityTracker.report()`
- Якщо звіт впав → лог помилки, **не зупиняємо** основну дію
- Один-два рядки на місце, без зміни існуючої логіки

### Фаза 3 — Master Timer (1 день)

**Повноцінний state machine:**

```
States:
─────────────────
"stopped" → не активний
"active"  → тікає
"paused"  → на паузі (вручну)
"idle"    → на паузі через бездіяльність
─────────────────

Transitions:
─────────────────
stopped → active    (startMasterTimer)
active → paused     (pauseMasterTimer)
active → idle       (auto через Idle Detection)
paused → active     (resumeMasterTimer)
idle → active       (resume after activity)
* → stopped         (stopMasterTimer)
─────────────────
```

**Інтеграції:**
- **Page Visibility API** — переключення вкладки → state change
- **Idle Detection API (Chrome)** — детект бездіяльності (5 хв)
- **Persistence** — стан зберігається в `master_timer_state` кожні 60 сек
- **Recovery** — при reload відновлюється з останнього стану
- **Cross-tab sync** — якщо адвокат відкрив систему в кількох вкладках, master timer один (BroadcastChannel)

**API:**
- `startMasterTimer()`, `pauseMasterTimer()`, `resumeMasterTimer()`, `stopMasterTimer()`
- `getMasterTimerState()` — повертає поточний стан і час

**UI поки немає** — налаштування тільки в `user.preferences`. У майбутньому Billing UI TASK додамо плаваючу панель/стрічку/іконку залежно від `billing_ui_mode`.

### Фаза 4 — Стандарти часу + автоматичний облік hearing (1 день)

#### `src/services/timeStandards.js`

```javascript
import { getCurrentTenant, getCurrentUser } from './tenantService.js';

const SYSTEM_DEFAULTS = {
  hearing_simple: 60,
  hearing_complex: 120,
  advocate_request: 30,
  client_meeting: 60,
  phone_call: 15,
  document_drafting: 60,
  case_research: 90,
  travel_to_court: 60,
  travel_from_court: 60,
  default_travel: { to: 60, from: 60 }
};

export function getTimeStandard(activity, context = {}) {
  // Ієрархія: user → tenant → system
  
  const user = getCurrentUser();
  const userStd = lookupInUserPrefs(user, activity, context);
  if (userStd) return userStd;
  
  const tenant = getCurrentTenant();
  const tenantStd = lookupInTenantSettings(tenant, activity, context);
  if (tenantStd) return tenantStd;
  
  return SYSTEM_DEFAULTS[activity];
}
```

#### Автоматичний облік hearing (Теза 10)

```javascript
// Хук на створення hearing
async function onHearingCreated(hearing) {
  // 1. Підготовка
  const prepStandard = getTimeStandard('hearing_complex', { hearing });
  
  activityTracker.report('hearing_preparation_planned', {
    hearingId: hearing.id,
    caseId: hearing.caseId,
    plannedDuration: prepStandard,
    plannedDate: hearing.date
  });
  
  // 2. Дорога туди
  const travelStd = getTimeStandard('travel_to_court', { 
    court: hearing.court 
  });
  
  activityTracker.report('hearing_travel_planned', {
    hearingId: hearing.id,
    caseId: hearing.caseId,
    direction: 'to',
    plannedDuration: travelStd,
    plannedDate: hearing.date
  });
  
  // 3. Дорога назад (аналогічно)
  // 4. Самé засідання (тривалість hearing.duration або стандарт)
}

// Хук на завершення hearing
async function onHearingCompleted(hearing) {
  // Створюємо реальні time_entries з фактом
}

// Хук на відкладення/скасування
async function onHearingPostponed(hearing, reason) {
  activityTracker.report('hearing_postponed', {
    hearingId: hearing.id,
    caseId: hearing.caseId,
    reason
  });
}
```

#### Категорії дій

```javascript
const ACTIVITY_CATEGORIES = {
  case_work: {
    billable: true,
    visibleToClient: true,
    billFactor: 1.0
  },
  hearing_attendance: {
    billable: true,
    visibleToClient: true,
    billFactor: 1.0
  },
  hearing_preparation: {
    billable: true,
    visibleToClient: true,
    billFactor: 1.0
  },
  travel: {
    billable: true,
    visibleToClient: true,
    billFactor: 1.0
  },
  client_communication: {
    billable: true,
    visibleToClient: false,
    billFactor: 0.5
  },
  admin: {
    billable: false,
    visibleToClient: false,
    billFactor: 0.0
  },
  system: {
    billable: false,
    visibleToClient: false,
    billFactor: 0.0
  },
  break: {
    billable: false,
    visibleToClient: false,
    billFactor: 0.0
  }
};
```

### Фаза 5 — Місячна ротація і архіви (1 день)

#### `src/services/timeEntriesArchiver.js`

```javascript
function shouldArchive() {
  const now = new Date();
  const lastArchive = billing_meta.lastArchiveCreated 
    ? new Date(billing_meta.lastArchiveCreated) 
    : null;
  
  if (!lastArchive) return true;
  
  return now.getMonth() !== lastArchive.getMonth() 
      || now.getFullYear() !== lastArchive.getFullYear();
}

async function archivePreviousMonth() {
  const now = new Date();
  const previousMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const previousMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59);
  
  // 1. Беремо записи попереднього місяця
  const entriesToArchive = time_entries.filter(entry => {
    const entryDate = new Date(entry.startTime);
    return entryDate >= previousMonth && entryDate <= previousMonthEnd;
  });
  
  if (entriesToArchive.length === 0) return;
  
  // 2. Створюємо архівний файл
  const yyyymm = formatYYYYMM(previousMonth);
  const archivePath = `_archives/time_entries_${yyyymm}.json`;
  
  await uploadToDrive(archivePath, JSON.stringify(entriesToArchive));
  
  // 3. Видаляємо архівовані з registry
  time_entries = time_entries.filter(entry => {
    const entryDate = new Date(entry.startTime);
    return !(entryDate >= previousMonth && entryDate <= previousMonthEnd);
  });
  
  // 4. Оновлюємо billing_meta
  billing_meta.lastArchiveCreated = new Date().toISOString();
  billing_meta.archiveFiles.push(archivePath);
  
  await writeRegistry();
  
  // 5. Audit log
  await writeAuditLog({
    action: 'time_entries_archived',
    details: { yyyymm, entriesCount: entriesToArchive.length, archivePath }
  });
}

async function checkAndArchiveOnStartup() {
  if (shouldArchive()) {
    try {
      await archivePreviousMonth();
    } catch (error) {
      console.error('[Archiver] Failed to archive:', error);
    }
  }
}
```

#### Завантаження архіву на запит

```javascript
const archiveCache = {};

async function loadArchive(yyyymm) {
  const cacheKey = `archive_${yyyymm}`;
  
  if (archiveCache[cacheKey]) {
    return archiveCache[cacheKey];
  }
  
  const archivePath = `_archives/time_entries_${yyyymm}.json`;
  
  try {
    const content = await downloadFromDrive(archivePath);
    const entries = JSON.parse(content);
    archiveCache[cacheKey] = entries;
    return entries;
  } catch (error) {
    console.error(`[Archiver] Failed to load archive ${yyyymm}:`, error);
    return [];
  }
}
```

### Фаза 6 — Query API для майбутніх звітів (1 день)

#### `src/services/timeEntriesQuery.js`

```javascript
export async function getTimeEntries(query = {}) {
  const {
    dateFrom,
    dateTo,
    caseId,
    userId,
    tenantId,
    category,
    billable,
    groupBy
  } = query;
  
  // 1. Визначити які джерела треба завантажити
  const sources = determineSources(dateFrom, dateTo);
  
  // 2. Завантажити паралельно
  const dataSources = await Promise.all(
    sources.map(src => loadSource(src))
  );
  
  // 3. Об'єднати
  let entries = dataSources.flat();
  
  // 4. Фільтрація
  if (dateFrom) entries = entries.filter(e => new Date(e.startTime) >= new Date(dateFrom));
  if (dateTo) entries = entries.filter(e => new Date(e.startTime) <= new Date(dateTo));
  if (caseId) entries = entries.filter(e => e.caseId === caseId);
  if (userId) entries = entries.filter(e => e.userId === userId);
  if (tenantId) entries = entries.filter(e => e.tenantId === tenantId);
  if (category) entries = entries.filter(e => e.category === category);
  if (billable !== undefined) entries = entries.filter(e => e.billable === billable);
  
  // 5. Групування (якщо потрібно)
  if (groupBy) return groupEntries(entries, groupBy);
  
  return entries;
}

export async function getSummary(query) {
  const entries = await getTimeEntries(query);
  
  return {
    totalEntries: entries.length,
    totalDuration: entries.reduce((s, e) => s + (e.duration || 0), 0),
    billableDuration: entries.filter(e => e.billable).reduce((s, e) => s + (e.duration || 0), 0),
    byCategory: groupBy(entries, 'category'),
    byCase: groupBy(entries, 'caseId'),
    dateRange: {
      from: entries[0]?.startTime,
      to: entries[entries.length - 1]?.startTime
    }
  };
}
```

### Фаза 7 — Інтеграція з SaaS і ai_usage (півдня)

#### Зв'язок з ai_usage[]

При кожному виклику API одночасно фіксуємо в обох структурах:

```javascript
// Перед AI-викликом
const sessionStartTime = Date.now();

// Виклик AI
const response = await fetch('https://api.anthropic.com/v1/messages', {...});
const data = await response.json();

// Логування в ai_usage (вже існує з v1.1)
if (data.usage) {
  logAiUsage({
    agentType: 'dossier_agent',
    model: resolveModel('dossierAgent'),
    inputTokens: data.usage.input_tokens,
    outputTokens: data.usage.output_tokens,
    context: { caseId, module: 'Dossier', operation: 'chat' }
  }, setAiUsage);
}

// НОВЕ: Логування в time_entries (для CRM-зрізу)
const sessionDuration = Math.round((Date.now() - sessionStartTime) / 1000);
activityTracker.report('agent_call', {
  caseId,
  module: 'Dossier',
  agentType: 'dossier_agent',
  duration: sessionDuration,
  category: 'case_work',
  billable: true
});
```

#### Permissions для time_entries

В `permissionService.js` додаємо нові дії:

```javascript
const TIME_ENTRY_ACTIONS = [
  'view_own_time_entries',
  'view_all_time_entries',
  'edit_time_entries',
  'delete_time_entries',
  'export_time_entries'
];

export function canViewTimeEntries(userId, targetUserId, tenantId) {
  const user = getUserById(userId);
  if (!user) return false;
  if (user.tenantId !== tenantId) return false;
  if (user.globalRole === 'bureau_owner') return true;
  return userId === targetUserId; // тільки свої
}
```

#### Розширення auditLog

```javascript
const AUDIT_ACTIONS = [
  // Існуючі...
  'time_entries_archived',
  'time_entry_edited',
  'time_entry_deleted',
  'time_standards_changed'
];
```

#### subscription.current — інтеграція з ai_usage[]

В `subscriptionService.js` `recalculateCurrent` вже існує (з v1.1). Розширити:

```javascript
export function recalculateCurrent(tenant, aiUsage, cases, timeEntries) {
  // Існуюча логіка з v1.1: tokensUsed, costUsedUSD з ai_usage
  
  // НОВЕ: hours billed з time_entries
  const periodEntries = timeEntries.filter(...);
  const hoursBilled = periodEntries
    .filter(e => e.billable)
    .reduce((s, e) => s + (e.duration / 3600), 0);
  
  return {
    ...tenant.subscription.current,
    tokensUsed: ...,
    costUsedUSD: ...,
    hoursBilled,
    // ...
  };
}
```

### Фаза 8 — Документація і звіт (півдня)

#### `bugs_found_during_billing_foundation.md`

Накопичуються знахідки під час розробки. Якщо щось знайдено — фіксується, не виправляється.

#### `recommended_task_claude_md_audit.md` (доповнюємо)

Додаємо нові розділи:
- "activityTracker і time_entries"
- "Master timer state machine"
- "Стандарти часу — ієрархія"
- "Місячна ротація time_entries"
- "API запитів getTimeEntries"

#### `report_billing_foundation.md`

ASCII візуалізації ДО/ПІСЛЯ:

```
СТРУКТУРА registry_data.json — ДО (v3):
─────────────────────────────────────
schemaVersion: 3
settingsVersion: "3.0_patch_and_extension"
tenants[], users[], auditLog[], structuralUnits[]
ai_usage[], caseAccess[], cases[]
─────────────────────────────────────

СТРУКТУРА registry_data.json — ПІСЛЯ (v4):
─────────────────────────────────────
schemaVersion: 4
settingsVersion: "4.0_billing_foundation"
tenants[] (з timeStandards в settings)
users[], auditLog[], structuralUnits[]
ai_usage[], caseAccess[], cases[]

НОВЕ:
time_entries[]
master_timer_state{}
billing_meta{}
─────────────────────────────────────

КАРТА ІНСТРУМЕНТАЦІЇ:
─────────────────────────────────────
Dashboard         → 5 точок
CaseDossier       → 6 точок
QuickInput        → 3 точки
Notebook          → 2 точки
DocumentProcessor → 5 точок
App.jsx           → 4 глобальних

Загалом: 25 точок інструментації
─────────────────────────────────────

ШАРИ АРХІТЕКТУРИ:
─────────────────────────────────────
ШАР 1: Внутрішня логіка (завжди ввімкнена)
  ✅ activityTracker.js
  ✅ master_timer state machine
  ✅ time_entries[] з ротацією
  ✅ Стандарти часу (system→tenant→user)
  ✅ getTimeEntries API
  ✅ Інтеграція з ai_usage[] (з v1.1)

ШАР 2: Налаштування UI (вибір адвоката)
  ✅ user.preferences.billing_ui_mode = "off" дефолт

ШАР 3: Візуальний шар
  ⏸ Поки нічого видимого
  ⏸ Окремий TASK Billing UI v1
─────────────────────────────────────
```

#### Один commit з усіма змінами

```
feat: Billing Foundation v2 — internal time tracking

- time_entries[] на верхньому рівні (місячна ротація)
- activityTracker.js + 25 точок інструментації
- masterTimer.js — state machine
- timeStandards.js — ієрархія user → tenant → system
- timeEntriesArchiver.js — місячна ротація + архіви на Drive
- timeEntriesQuery.js — getTimeEntries API
- Автоматичний облік hearings (Теза 10)
- Інтеграція з ai_usage[] (паралельне логування)
- migrationService: v3 → v4 ідемпотентна
- Backup pre_billing
- CLAUDE.md: розділ Billing Foundation v4.0
```

---

## SAAS IMPLICATIONS

### Поля time_entry

Всі записи мають:
- `tenantId` (з SaaS Foundation)
- `userId` (хто згенерував)
- `createdAt`, `startTime`, `endTime`

### Permissions

- `view_own_time_entries` — будь-який роль
- `view_all_time_entries` — bureau_owner, head, admin
- `edit_time_entries` — owner / автор запису
- `delete_time_entries` — bureau_owner / admin

### Tenant isolation

`time_entries` фільтруються по `tenantId`. Аналітика — тільки в межах tenant.

### Audit

Не пишемо в auditLog кожну активність (шум). Пишемо:
- Архівацію time_entries
- Редагування існуючих
- Видалення
- Зміну стандартів tenant/user

---

## BILLING IMPLICATIONS

Цей TASK — закладає фундамент для всіх майбутніх BILLING IMPLICATIONS секцій інших TASK.

З моменту завершення кожен новий TASK має секцію:

```markdown
## BILLING IMPLICATIONS

### Точки інструментації
[перелік подій модуля які йдуть в activityTracker]

### Категорії часу
[billable/non-billable, billFactor, visibleToClient]

### Інтеграція з master timer
[як модуль взаємодіє з master timer state]

### Тули з білінговими побічними ефектами
[нові тули і їх вплив на time_entries]

### CRM-зріз
[які з цих подій з'являться в хронології досьє і як виглядають для клієнта]
```

---

## FUTURE WORK — ВІДКЛАДЕНІ ПИТАННЯ

Зафіксовано для майбутніх TASK Billing UI v1, v2, v3:

### Master Timer UI
- Як виглядає на iPad / iPhone
- Гібрид залежно від billing_ui_mode:
  - "full" → плаваюча панель + субтаймери
  - "simplified" → стрічка в шапці
  - "classic" → іконка-кнопка в кутку

### UI стандартів часу
- Адмін-секція бюро для tenant standards
- Налаштування адвоката для user preferences
- Adaptive learning UI (пропозиція оновити стандарт після N однакових ручних правок)

### Категоризовані таймери UI
- Кнопки "Іду в Word", "Зустріч з клієнтом"
- Голосові команди "Старт/Стоп категорія"

### Звіти UI (4 рівні деталізації)
- Декартовий вибір вікно × фільтр
- Експорт у .docx акти

### TASK Analytics Agent (далеке майбутнє)
- Сторінка аналітики з чатом і полотном
- Тули для агента: render_chart, render_table, generate_narrative, export_to_docx

### Чекпоїнти переоцінки місячної ротації
- Через 2 тижні після запуску — огляд розміру файлу
- Через місяць — перший архів, аналіз чи місячна ротація оптимальна
- Можлива зміна на тижневу/квартальну

---

## КРИТЕРІЇ УСПІХУ

1. ✅ Структура `time_entries[]` створена в registry_data.json
2. ✅ Файли `activityTracker.js`, `masterTimer.js`, `timeStandards.js`, `timeEntriesArchiver.js`, `timeEntriesQuery.js` створені
3. ✅ Master timer працює (старт/пауза/стоп/idle/recovery)
4. ✅ Інструментовано всі 25 точок в існуючих модулях
5. ✅ time_entries з'являються при роботі адвоката
6. ✅ Page Visibility API і Idle Detection працюють
7. ✅ Стандарти часу резолвяться через ієрархію
8. ✅ Hearing автоматично генерує time_entries
9. ✅ Місячна ротація налаштована (запуск 1 червня)
10. ✅ getTimeEntries API повертає дані з різних періодів
11. ✅ Інтеграція з ai_usage[] — паралельне логування
12. ✅ Permissions перевіряються
13. ✅ Audit log пише архівацію
14. ✅ schemaVersion: 4, settingsVersion: "4.0_billing_foundation"
15. ✅ Міграція v3 → v4 ідемпотентна
16. ✅ Backup pre_billing створено
17. ✅ Vite build проходить без помилок
18. ✅ Smoke tests проходять
19. ✅ Жодний існуючий модуль не зламався
20. ✅ Звіт `report_billing_foundation.md` написано

---

## ПЕРЕВІРКА ПІСЛЯ ВПРОВАДЖЕННЯ

> ✅ TASK Billing Foundation v2 — завершено
> 
> Commit: [hash]
> 
> **Перевірка адвокатом:**
> 
> 1. Hard reload системи (Cmd+Shift+R / iPad очистити кеш)
> 2. Звичайна робота — створити справу, переглянути hearing, відкрити досьє
> 3. Перевірити в Drive: registry_data.json має зрости (time_entries додались)
> 4. Перевірити в Drive: створено `registry_data_backup_pre_billing_<ts>.json` в _backups/
> 5. На вибір — відкрити registry_data.json як текст і знайти ключ "time_entries" — там має бути масив з твоїми сьогоднішніми діями
> 
> **Через 2 тижні:**
> Перший огляд — як зросла time_entries[], чи треба корегувати ротацію.

---

## АРТЕФАКТИ СТВОРЕНІ ЦИМ TASK

```
src/services/activityTracker.js
src/services/timeEntriesArchiver.js
src/services/timeEntriesQuery.js
src/services/masterTimer.js
src/services/timeStandards.js

Модифіковано:
src/App.jsx                          (інтеграція activityTracker + хуки в executeAction)
src/components/Dashboard/index.jsx    (інструментація)
src/components/CaseDossier/index.jsx  (інструментація + інтеграція з ai_usage)
src/components/QuickInput/...         (інструментація)
src/components/Notebook/...           (інструментація)
src/components/DocumentProcessor/...  (інструментація)
src/services/migrationService.js     (міграція 3 → 4)
src/services/permissionService.js    (нові permissions)
src/services/auditLogService.js      (нові AUDIT_ACTIONS)
src/services/tenantService.js        (timeStandards в DEFAULT_TENANT.settings)
src/services/subscriptionService.js  (інтеграція з time_entries)

Документація:
diagnostic_billing_foundation.md     (фаза 0)
progress_billing_foundation.md       (статус, опційно)
report_billing_foundation.md         (звіт)
bugs_found_during_billing_foundation.md (накопичені знахідки)
recommended_task_claude_md_audit.md  (доповнено)

Backup:
_archives/registry_data_backup_pre_billing_<ts>.json
```

---

## ПОСЛІДОВНІСТЬ ПІСЛЯ ЦЬОГО TASK

```
1. ✅ TASK SaaS Foundation v1
2. ✅ TASK SaaS Foundation v1.1 Patch and Extension
3. 🔄 TASK Billing Foundation v2 (цей)
4.    TASK Tool Use Preparation
       (з урахуванням готового activityTracker і ai_usage)
5.    TASK CLAUDE.md Audit
       (одним проходом для всього каркасу: v2.0 SaaS, v3.0 Patch, v4.0 Billing, v5.0 Tool Use)
6.    TASK Travel Time Fix
       (перший модульний на повністю готовій архітектурі)
7.    TASK Multi-user Activation (окремий чат)
8.    Інші модульні TASK...
N.    TASK Billing UI v1 (через 6+ міс)
N+1.  TASK Analytics Agent (через 6+ міс)
```

---

## ОЦІНКА ТРИВАЛОСТІ

```
Фаза 0 — Діагностика                    1-2 год
Фаза 1 — activityTracker базова         1 день
Фаза 2 — Інструментація модулів          2 дні
Фаза 3 — Master Timer                   1 день
Фаза 4 — Стандарти + автоматичний облік 1 день
Фаза 5 — Архівація                      1 день
Фаза 6 — Query API                      1 день
Фаза 7 — SaaS інтеграція + ai_usage     півдня
Фаза 8 — Документація + звіт            півдня

ЗАГАЛОМ:                                6-8 робочих днів Claude Code
```

Може бути швидше — Claude Code вже знає кодову базу після SaaS Foundation v1 і v1.1.

---

**Кінець TASK Billing Foundation v2**

Версія 2.0 (адаптовано під SaaS v3.0). Готово до запуску в Claude Code.
