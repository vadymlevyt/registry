# TASK: Dashboard Travel Time + Billing Instrumentation v1
## Фікс візуалізації дороги через tool use, з одразу закладанням білінгу

**Версія:** 1.0
**Дата створення:** 04.05.2026
**Очікувана тривалість:** 1-2 дні роботи Claude Code
**Пріоритет:** ВИСОКИЙ — фікс реального бага + закладка інфраструктури білінгу
**Залежності:**
- TASK SaaS Foundation v1 — має бути виконаний
- TASK CLAUDE.md Audit — рекомендовано виконати
- TASK Tool Use Preparation — ОБОВ'ЯЗКОВИЙ перед цим TASK
**Гілка:** main

---

## 🧬 ФІЛОСОФІЯ — ЕМБРІОН З ПОВНИМ ДНК

Цей TASK — приклад того як будь-яка зміна в системі **одразу враховує**:
- SaaS-готовність (множина користувачів і команд)
- Tool use (агенти можуть викликати функцію)
- Білінг (час фіксується автоматично як активність)
- Audit log (критичні дії пишуться)

**Не виправляємо ізольований баг.** Виправляємо баг + закладаємо інфраструктуру для майбутнього.

---

## КОНТЕКСТ — ЯКИЙ БАГ ВИПРАВЛЯЄМО

### Поточний стан (вирізка з тестування адвоката)

В інтерфейсі Дашборду:
- Адвокат відкриває попап редагування засідання (наприклад, 12 травня, справа Конах)
- Бачить поля: початок 11:30, кінець 13:30
- Натискає «Прибрати/Додати час на дорогу»
- Обирає 2 години (1 год туди, 1 год назад)
- Поп-ап показує: «Туди: 10:30-11:30 (60 хв)», «Назад: 13:30-14:30 (60 хв)»
- Зберігає

**Очікувана поведінка:**

```
ЧАСОВІ СЛОТИ ДНЯ (правий стовпчик дашборду):

10:00
10:30 ┃ 🚗 Дорога туди — Конах   ← мало бути
11:00 ┃    10:30-11:30
11:30 ┃ ⚖️ Засідання — Конах
12:00 ┃    Дарницький районний суд
12:30 ┃    11:30-13:30
13:00 ┃
13:30 ┃ 🚗 Дорога назад — Конах   ← мало бути
14:00 ┃    13:30-14:30
14:30
```

**Реальна поведінка:**

```
ЧАСОВІ СЛОТИ ДНЯ:

10:00
10:30                              ← ПУСТО (баг!)
11:00                              ← ПУСТО (баг!)
11:30 ┃ ⚖️ Засідання — Конах      ← тільки засідання
12:00 ┃    Дарницький районний суд
12:30 ┃    11:30-13:30
13:00 ┃
13:30                              ← ПУСТО (баг!)
14:00                              ← ПУСТО (баг!)
14:30
```

Час дороги **зберігається в даних**, але **не відображається у візуалізації дня**. Це баг.

---

## АРХІТЕКТУРНА РЕАЛІЗАЦІЯ

### Принцип: один тул — багато точок виклику

```
┌──────────────────────────────────────────────────────────┐
│  ТУЛ: update_hearing_travel                                │
│                                                              │
│  Параметри:                                                  │
│  - hearingId (string)                                       │
│  - travelToMinutes (int, опційно)                           │
│  - travelFromMinutes (int, опційно)                         │
│                                                              │
│  Дії:                                                        │
│  1. Оновити hearing у даних                                 │
│  2. Оновити візуалізацію дня (створити travel-блоки)       │
│  3. Зафіксувати в білінгу як активність                     │
│  4. Записати в auditLog (якщо суттєва зміна)                │
│  5. Зберегти на Drive                                        │
└──────────────────────────────────────────────────────────┘
              ▲           ▲           ▲           ▲
              │           │           │           │
   ┌──────────┘    ┌──────┘     ┌─────┘     ┌─────┘
   │               │             │           │
┌──┴─────┐    ┌────┴────┐   ┌────┴────┐  ┌──┴──────┐
│ Поп-ап │    │Dashboard│   │   QI    │  │ Досьє   │
│   UI   │    │  agent  │   │  agent  │  │  agent  │
└────────┘    └─────────┘   └─────────┘  └─────────┘
   ↑               ↑             ↑           ↑
   │               │             │           │
адвокат        адвокат         адвокат    адвокат
натиснув       сказав          сказав     сказав
"Зберегти"     голосом         текстом    в чаті
```

### Місця виклику тулу

**1. Поп-ап редагування засідання (UI):**
- Адвокат натискає «Зберегти» → виклик `executeAction('update_hearing_travel', {...})`
- Це **не tool use** — звичайний JS виклик з UI
- Але йде через ту саму функцію `executeAction`

**2. Dashboard agent (через tool use):**
- Адвокат: «Додай годину дороги до Конах»
- Агент дашборду повертає tool_use блок
- toolUseAdapter перетворює на виклик executeAction
- Та сама функція виконується

**3. Quick Input agent (через tool use):**
- Адвокат: «До завтрашнього засідання Брановського додай 30 хвилин дороги»
- QI agent викликає тул

**4. Dossier agent (через tool use):**
- Адвокат у досьє: «По всіх засіданнях у Києві став 30 хвилин дороги»
- Dossier agent викликає тул для кожного hearing

**5. Майбутнє — GPS-трекер:**
- Системний виклик коли мобільний застосунок визначив реальний час дороги
- Той самий тул, інший виклик

### Принципова річ — Dashboard НЕ переробляється на tool use повністю

Ми **не чіпаємо** існуючий розмовний агент Dashboard. Він далі працює на ACTION_JSON.

**Що додаємо:**
- Новий тул `update_hearing_travel` в реєстр tools.js (для агентів які вже на tool use)
- UI поп-ап викликає той самий executeAction
- Існуючий ACTION_JSON-агент Dashboard теж **отримує доступ до цієї дії** через звичайний механізм ACTION_JSON

Тобто **обидва шляхи** ведуть до однієї `performUpdateHearingTravel()` функції.

---

## ⚠️ ФАЗА 0 — ОБОВ'ЯЗКОВА ДІАГНОСТИКА

Як і у SaaS Foundation, перед впровадженням Claude Code:

1. Завантажує `registry_data.json` з Drive
2. Аналізує структуру `hearings[]` — які поля вже є для дороги
3. Знаходить компонент який рендерить часові слоти дня (правий стовпчик дашборду)
4. Знаходить функцію збереження попап-вікна
5. Перевіряє як зараз зберігається `travelToMinutes` / `travelFromMinutes` в hearing
6. Знаходить де відбувається перерахунок візуалізації дня
7. Аналізує де саме баг — на рівні даних (не зберігається) чи рендеру (не показується)

Створює `diagnostic_dashboard_travel.md` з:
- Поточна структура hearing з полями дороги (фактична)
- Карта компонентів (попап + слоти дня)
- Знайдена причина бага
- План фіксу з адаптацією до реального стану коду

**Зупиняється і чекає згоди.**

---

## СПЕЦИФІКАЦІЯ ТУЛУ

### Опис у tools.js

```javascript
{
  name: "update_hearing_travel",
  description: "Додати або змінити час на дорогу до/від засідання. Створює або оновлює відповідні travel-блоки у візуалізації дня. Автоматично фіксує час в білінгу як активність. Викликається з UI попап-вікна, Dashboard agent, QI agent, Dossier agent.",
  input_schema: {
    type: "object",
    properties: {
      hearingId: {
        type: "string",
        description: "ID засідання"
      },
      travelToMinutes: {
        type: "integer",
        description: "Хвилин дороги до суду. 0 або відсутнє = прибрати дорогу туди.",
        minimum: 0,
        maximum: 480
      },
      travelFromMinutes: {
        type: "integer",
        description: "Хвилин дороги назад. 0 або відсутнє = прибрати дорогу назад.",
        minimum: 0,
        maximum: 480
      }
    },
    required: ["hearingId"]
  }
}
```

### Реалізація `performUpdateHearingTravel`

```javascript
async function performUpdateHearingTravel(params, context) {
  const { hearingId, travelToMinutes, travelFromMinutes } = params;
  const { userId, tenantId } = context;

  // 1. Знайти hearing
  const { caseData, hearing } = findHearingById(hearingId);
  if (!hearing) {
    throw new Error(`Hearing not found: ${hearingId}`);
  }

  // 2. Перевірка прав (поки що заглушка з SaaS Foundation)
  if (!checkCaseAccess(userId, caseData.caseId)) {
    throw new Error(`No access to case: ${caseData.caseId}`);
  }

  // 3. Оновити hearing
  const oldTravelTo = hearing.travelToMinutes || 0;
  const oldTravelFrom = hearing.travelFromMinutes || 0;
  const newTravelTo = travelToMinutes ?? oldTravelTo;
  const newTravelFrom = travelFromMinutes ?? oldTravelFrom;

  hearing.travelToMinutes = newTravelTo;
  hearing.travelFromMinutes = newTravelFrom;
  hearing.updatedAt = new Date().toISOString();
  hearing.updatedBy = userId;

  // 4. Інструментація для білінгу — фіксація як активність
  await activityTracker.report({
    type: 'hearing_travel_updated',
    caseId: caseData.caseId,
    hearingId: hearing.id,
    tenantId,
    userId,
    details: {
      oldTravelTo,
      oldTravelFrom,
      newTravelTo,
      newTravelFrom,
      delta: (newTravelTo - oldTravelTo) + (newTravelFrom - oldTravelFrom)
    }
  });

  // 5. Audit log (якщо суттєва зміна)
  if (Math.abs((newTravelTo + newTravelFrom) - (oldTravelTo + oldTravelFrom)) > 30) {
    await auditLog.write({
      action: 'update_hearing_travel',
      targetType: 'hearing',
      targetId: hearing.id,
      details: { caseId: caseData.caseId, oldTravelTo, oldTravelFrom, newTravelTo, newTravelFrom }
    });
  }

  // 6. Перерахувати візуалізацію дня
  rebuildDayView(hearing.date);

  // 7. Зберегти на Drive
  await saveCases();

  return {
    success: true,
    hearing,
    travelBlocks: computeTravelBlocks(hearing)
  };
}
```

### Функція `computeTravelBlocks`

Створює дві віртуальні події для візуалізації:

```javascript
function computeTravelBlocks(hearing) {
  const blocks = [];

  if (hearing.travelToMinutes > 0) {
    const startTime = subtractMinutes(hearing.time, hearing.travelToMinutes);
    blocks.push({
      type: 'travel_to',
      icon: '🚗',
      title: `Дорога туди — ${hearing.caseName}`,
      date: hearing.date,
      startTime,
      endTime: hearing.time,
      durationMinutes: hearing.travelToMinutes,
      relatedHearingId: hearing.id,
      caseId: hearing.caseId,
      // Білінгові поля
      billable: true,
      visibleToClient: true,
      category: 'travel_to_court',
      // Не зберігається окремо — обчислюється з hearing
      virtual: true
    });
  }

  if (hearing.travelFromMinutes > 0) {
    const endHearingTime = addMinutes(hearing.time, hearing.duration);
    const endTravelTime = addMinutes(endHearingTime, hearing.travelFromMinutes);
    blocks.push({
      type: 'travel_from',
      icon: '🚗',
      title: `Дорога назад — ${hearing.caseName}`,
      date: hearing.date,
      startTime: endHearingTime,
      endTime: endTravelTime,
      durationMinutes: hearing.travelFromMinutes,
      relatedHearingId: hearing.id,
      caseId: hearing.caseId,
      billable: true,
      visibleToClient: true,
      category: 'travel_from_court',
      virtual: true
    });
  }

  return blocks;
}
```

### Інтеграція в рендер дня

Компонент який рендерить часові слоти отримує hearing + travelBlocks і відображає всі три блоки:

```
┌──────────────────────────────────────────┐
│  ВІЗУАЛІЗАЦІЯ ДНЯ ПІСЛЯ ФІКСУ             │
├──────────────────────────────────────────┤
│                                            │
│  10:30 ┃ 🚗 Дорога туди — Конах           │
│  11:00 ┃    Дарницький районний суд       │
│        ┃    10:30-11:30 (60 хв)           │
│  11:30 ┃ ⚖️ Засідання — Конах             │
│  12:00 ┃    Дарницький районний суд       │
│  12:30 ┃    11:30-13:30 (120 хв)          │
│  13:00 ┃                                   │
│  13:30 ┃ 🚗 Дорога назад — Конах          │
│  14:00 ┃    13:30-14:30 (60 хв)           │
│        ┃                                   │
│                                            │
└──────────────────────────────────────────┘
```

---

## БІЛІНГОВА ІНТЕГРАЦІЯ

### Дані які збираються при кожному виклику тулу

Подія `hearing_travel_updated` записується в `time_entries[]` (структура з SaaS Foundation):

```json
{
  "id": "te_1714814400_abc",
  "type": "hearing_travel_planned",
  "caseId": "case_konah",
  "hearingId": "hrg_12_05_2026",
  "tenantId": "ab_levytskyi",
  "userId": "vadym",
  "createdAt": "2026-05-04T15:00:00Z",

  "duration": 120,
  "category": "court_travel",
  "subCategories": ["travel_to_court", "travel_from_court"],

  "billable": true,
  "visibleToClient": true,
  "billFactor": 1.0,

  "metadata": {
    "travelToMinutes": 60,
    "travelFromMinutes": 60,
    "scheduledDate": "2026-05-12",
    "scheduledStartTime": "10:30",
    "scheduledEndTime": "14:30"
  }
}
```

### Стандартні норми часу для дороги

При створенні засідання система **автоматично пропонує** стандарт:

```
┌────────────────────────────────────────────┐
│  Створення засідання — Конах                 │
├────────────────────────────────────────────┤
│                                              │
│  Суд: Дарницький районний суд м. Києва      │
│                                              │
│  💡 Стандарт для цього суду:                 │
│     Дорога туди: 60 хв                       │
│     Дорога назад: 60 хв                      │
│                                              │
│  [Прийняти стандарт] [Налаштувати]           │
│                                              │
└────────────────────────────────────────────┘
```

Стандарти зберігаються в `tenant.settings.travelStandards`:

```json
{
  "travelStandards": {
    "by_court": {
      "Дарницький районний суд м. Києва": { "to": 60, "from": 60 },
      "Шевченківський районний суд м. Києва": { "to": 30, "from": 30 },
      "Печерський районний суд м. Києва": { "to": 45, "from": 45 }
    },
    "by_city": {
      "Київ": { "to": 60, "from": 60 },
      "Львів": { "to": 90, "from": 90 }
    },
    "default": { "to": 60, "from": 60 }
  }
}
```

Коли адвокат `N` разів підряд налаштовує **інший** час для одного суду — система пропонує оновити стандарт:

> «Ти 3 рази підряд ставив 30 хвилин для Шевченківського суду замість стандартних 45. Оновити стандарт?»

### Зайнятий час — для майбутніх перевірок конфліктів

Завдяки тому що travel-блоки рахуються в білінгу — система **знає** що з 10:30 до 14:30 у адвоката **зайнято**. Якщо хтось спробує створити іншу подію в цей час → попередження «Конфлікт з засіданням Конах + дорога».

---

## SAAS IMPLICATIONS

### Поля у hearing (вже мають бути після SaaS Foundation)

- `tenantId` — успадковується з parent case (не дублюємо)
- `createdBy` — хто створив
- `updatedBy` — хто оновив (новий)

### Поля які додаємо в цьому TASK

- `travelToMinutes` (вже може бути, перевірити)
- `travelFromMinutes` (вже може бути, перевірити)

### Permissions

- `update_hearing_travel` — дозволено всім (lawyer, paralegal, intern теж — це не критична дія)
- В permissions матриці прав ролей: `update_hearing_travel: ['*']`

### Аудит

- Запис в auditLog **тільки** якщо delta > 30 хвилин (суттєва зміна)
- Дрібні правки (з 60 до 70 хв) не пишуться

### Tenant isolation

- Тул перевіряє що hearing належить tenant'у користувача
- Травел-стандарти — per tenant в settings

---

## ПЛАН ВИКОНАННЯ

### Фаза 0 — Діагностика (1-2 год)

Створити `diagnostic_dashboard_travel.md` з аналізом реального стану коду.
Зупинка для отримання згоди.

### Фаза 1 — Тул в реєстрі (30 хв)

Додати опис `update_hearing_travel` в `tools.js`.

### Фаза 2 — Імплементація `performUpdateHearingTravel` (2-3 год)

Створити функцію в окремому модулі `src/services/hearingTravelService.js`.
Інтегрувати з:
- `tenantService` (для userId/tenantId)
- `auditLog` (для запису)
- `activityTracker` (для білінгу — заглушка якщо ще не створено)
- Drive save

### Фаза 3 — Інтеграція в executeAction (30 хв)

Додати маршрутизацію `update_hearing_travel` → `performUpdateHearingTravel`.

### Фаза 4 — UI поп-ап (1-2 год)

Знайти компонент поп-ап редагування засідання.
Замінити пряме оновлення hearing на виклик `executeAction('update_hearing_travel', {...})`.

### Фаза 5 — Візуалізація дня (2-3 год)

Знайти компонент рендеру часових слотів.
Інтегрувати функцію `computeTravelBlocks()`.
Travel-блоки рендеряться поряд з hearing.

### Фаза 6 — Стандарти часу (1 год)

Створити структуру `tenant.settings.travelStandards`.
При створенні нового засідання — підставляти стандарт.
Авто-оновлення стандарту після N однакових ручних правок.

### Фаза 7 — Білінгова інструментація (1 год)

Підключити `activityTracker.report()` в `performUpdateHearingTravel`.
Якщо `activityTracker` ще не створено — створити заглушку яка просто пише в `time_entries[]`.

### Фаза 8 — Тестування (1 год)

- Створити засідання Конах 12 травня з дорогою 60+60
- Перевірити що travel-блоки відображаються в часових слотах
- Перевірити що подія записана в `time_entries[]`
- Перевірити що auditLog оновлено (якщо delta > 30)
- Викликати тул через QI/Dashboard agent → перевірити що працює

### Фаза 9 — Звіт (30 хв)

Створити `report_dashboard_travel.md` з візуалізаціями ДО/ПІСЛЯ.

---

## ЗВІТ ПІСЛЯ ВИКОНАННЯ

Файл `report_dashboard_travel.md` обов'язково містить:

### ВІЗУАЛІЗАЦІЯ ЧАСОВИХ СЛОТІВ — ДО І ПІСЛЯ

```
ДО ФІКСУ:                          ПІСЛЯ ФІКСУ:

10:30  (пусто) ❌                  10:30 ┃ 🚗 Дорога туди ✅
11:00  (пусто) ❌                  11:00 ┃    10:30-11:30
11:30 ┃ ⚖️ Засідання               11:30 ┃ ⚖️ Засідання
12:00 ┃    Дарницький              12:00 ┃    Дарницький
12:30 ┃    11:30-13:30              12:30 ┃    11:30-13:30
13:00 ┃                             13:00 ┃
13:30  (пусто) ❌                  13:30 ┃ 🚗 Дорога назад ✅
14:00  (пусто) ❌                  14:00 ┃    13:30-14:30
```

### АРХІТЕКТУРА ВИКЛИКУ — ПІСЛЯ

```
              update_hearing_travel
                       │
     ┌─────────────────┼─────────────────┐
     │                 │                 │
   UI               Dashboard            QI
 (поп-ап)            agent              agent
     │                 │                 │
     └─────────────────┼─────────────────┘
                       │
              executeAction()
                       │
         performUpdateHearingTravel()
                       │
     ┌─────────────────┼─────────────────┐
     │                 │                 │
  Update           Activity           Audit
  hearing          tracker             log
                  (білінг)
```

### ДАНІ ЯКІ ТЕПЕР ЗБИРАЮТЬСЯ

- `time_entries[]` — кожна зміна дороги фіксується
- `auditLog[]` — суттєві зміни (delta > 30 хв)
- Стандарти оновлюються при повторюваних змінах

---

## SAAS IMPLICATIONS — ВЖЕ ЗАКЛАДЕНО

✅ tenantId перевіряється
✅ userId фіксується в кожній дії
✅ permissions перевіряються
✅ auditLog для критичних змін
✅ Tenant-specific стандарти часу
✅ Готовність до multi-user (інший адвокат бачить чужі правки в auditLog)

---

**Кінець TASK**
