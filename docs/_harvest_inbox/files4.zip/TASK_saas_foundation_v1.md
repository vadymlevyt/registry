# TASK: SaaS Foundation v1
## Закладання фундаментальної архітектури для майбутньої мультикористувацької версії

**Версія:** 1.0
**Дата створення:** 04.05.2026
**Очікувана тривалість:** 1 день роботи Claude Code
**Пріоритет:** ВИСОКИЙ — виконується перед усіма наступними TASK
**Залежності:** Жодних — це фундаментальний TASK
**Гілка:** main

---

## КОНТЕКСТ

Legal BMS зараз працює як соло-практика для одного адвоката (Вадим Левицький). У майбутньому система розгортається як SaaS для **чотирьох типів організацій**:

1. **Соло-практика** — один адвокат + помічник
2. **Адвокатське бюро** — керівник + наймані адвокати + помічники
3. **Адвокатське об'єднання** — партнери (рівні в правах) + наймані + помічники, з кластерами по партнерах
4. **Юридична фірма** — багаторівнева ієрархія: managing partner → partners → counsel → senior associates → associates → junior associates → paralegals → interns; з практиками і департаментами

Цей TASK закладає **архітектурний фундамент** який підтримує всі чотири типи організацій без подальшого переписування коду. Зараз система продовжує працювати як соло — всі нові структури мають єдиний tenant і єдиного користувача (Вадим). Коли почнеться SaaS-розгортання — додаються нові tenants, користувачі, ролі без зміни архітектури.

**Принцип:** структура закладається повна, логіка пишеться мінімально (заглушки що повертають true для поточного користувача). Коли треба буде підтримувати багатьох користувачів — заглушки замінюємо на реальну логіку перевірок без перебудови.

---

## МЕТА TASK

Розширити структуру даних і додати шар перевірок прав доступу так, щоб:

1. Усі існуючі дані прив'язалися до tenant'у і користувача (міграція з default-значеннями)
2. З'явилися структури для майбутніх користувачів, ролей, команд по справах, аудиту
3. Кожна дія через `executeAction` пройшла через перевірку прав (зараз — заглушка, в майбутньому — реальна логіка)
4. Поточна функціональність системи **не зламалася** — все працює як раніше
5. Кожен наступний TASK мав готову основу для SaaS і не вимагав архітектурних змін

---

## ОБМЕЖЕННЯ І ПРИНЦИПИ

### Що робимо

- Розширюємо структуру `registry_data.json` новими розділами
- Мігруємо існуючі дані з default-значеннями (`tenantId: 'ab_levytskyi'`, `ownerId: 'vadym'`)
- Додаємо нові утилітні функції перевірок (`checkTenantAccess`, `checkRolePermission`, `checkCaseAccess`)
- Інтегруємо ці функції в `executeAction`
- Додаємо запис в `auditLog` для критичних дій
- Документуємо нову архітектуру в `CLAUDE.md`

### Що НЕ робимо

- НЕ змінюємо UI поточних модулів
- НЕ додаємо інтерфейс керування користувачами/ролями (це окремий TASK у майбутньому)
- НЕ реалізуємо логіку перевірок (заглушки що повертають true для поточного користувача)
- НЕ міняємо роботу агентів (вони продовжують працювати як раніше)
- НЕ робимо міграцію Document Processor чи інших старих модулів — це окремі TASK

### Принцип «закладено але не активно»

Структури є, поля заповнені, перевірки викликаються — але **поведінка системи для поточного користувача (Вадим) ідентична попередній**. Коли додасться другий користувач — заглушки оновлюються, без зміни виклику.

---

## ЗМІНИ В СТРУКТУРІ ДАНИХ

### Нова структура `tenants[]`

Додати в корінь `registry_data.json`:

```json
{
  "tenants": [
    {
      "tenantId": "ab_levytskyi",
      "type": "bureau",
      "name": "Адвокатське бюро «Вадима Левицького»",
      "edrpou": "40434074",
      "registrationDate": "2016-06-15",
      "ownerUserId": "vadym",
      "addresses": {
        "kyiv": "вул. Володимирська, 4, 01025, Київ",
        "kostopil": "вул. Дорошенка, 33, 35001, Костопіль"
      },
      "contacts": {
        "email": "info@levytskyi.com",
        "phone": "+380674621428",
        "website": null
      },
      "bankDetails": {
        "iban": "UA643052990000026001046211855",
        "bank": "ПриватБанк"
      },
      "subscription": {
        "plan": "self_hosted",
        "validUntil": null,
        "features": ["all"]
      },
      "settings": {
        "language": "uk",
        "documentStandard": {
          "font": "Times New Roman",
          "fontSize": "12-14pt",
          "margins": { "left": 30, "top": 20, "right": 20, "bottom": 20 },
          "lineHeight": 1.5,
          "pageSize": "A4"
        }
      },
      "createdAt": "2016-06-15T00:00:00Z",
      "updatedAt": "...автоматично при першому збереженні"
    }
  ]
}
```

**Поле `type`** — фіксований enum:
- `solo` — соло-практика
- `bureau` — адвокатське бюро (наш випадок)
- `association` — адвокатське об'єднання
- `firm` — юридична фірма

**Зараз створюється єдиний tenant** з `type: 'bureau'` і всіма реквізитами АБ Левицького.

### Нова структура `users[]`

Додати в корінь `registry_data.json`:

```json
{
  "users": [
    {
      "userId": "vadym",
      "tenantId": "ab_levytskyi",
      "globalRole": "bureau_owner",
      "name": "Левицький Вадим Андрійович",
      "rnokpp": "2958638797",
      "advokatLicense": {
        "number": "502",
        "issuedDate": "2006-04-27",
        "issuedBy": "Київська обласна КДКА"
      },
      "email": "vadim.levytskyi@gmail.com",
      "secondaryEmail": "info@levytskyi.com",
      "phone": "+380674621428",
      "active": true,
      "structuralUnit": null,
      "supervisorId": null,
      "billingRate": null,
      "createdAt": "2016-06-15T00:00:00Z",
      "lastLoginAt": null
    }
  ]
}
```

**Поле `globalRole`** — фіксований enum за типом організації:

Для `solo`:
- `solo_advocate`
- `solo_assistant`

Для `bureau`:
- `bureau_owner` (керівник, унікальна роль)
- `bureau_lawyer`
- `bureau_assistant`

Для `association`:
- `association_partner`
- `association_lawyer`
- `association_assistant`

Для `firm`:
- `firm_managing_partner` (унікальна роль)
- `firm_partner`
- `firm_counsel`
- `firm_senior_associate`
- `firm_associate`
- `firm_junior_associate`
- `firm_paralegal`
- `firm_intern`

Спільні (для всіх типів):
- `external_collaborator` — зовнішній адвокат з тимчасовим доступом

**Поле `structuralUnit`** — для об'єднань (id кластера партнера) і фірм (id практики/департаменту). Зараз `null`.

**Поле `supervisorId`** — для ієрархій (хто керівник цього користувача). Зараз `null`.

**Поле `billingRate`** — для фірм з різними ставками за грейдом. Зараз `null`.

### Розширення `cases[*]`

Додати поля до кожного запису у `cases[]`:

```json
{
  "caseId": "...",
  "name": "...",
  "...існуючі поля": "...",

  "tenantId": "ab_levytskyi",
  "ownerId": "vadym",
  "team": [
    {
      "userId": "vadym",
      "caseRole": "lead",
      "addedAt": "...",
      "addedBy": "vadym"
    }
  ],
  "shareType": "internal",
  "externalAccess": []
}
```

**Поле `caseRole`** — роль користувача саме в цій справі:
- `lead` — провідний адвокат справи
- `team_member` — член команди
- `consulted` — консультант з обмеженим доступом
- `oversight` — наглядач (для партнерів фірми)

**Поле `shareType`**:
- `private` — тільки `ownerId`
- `internal` — `ownerId` + `team[]` з того самого tenant'у
- `external` — є тимчасовий доступ ззовні

**Поле `externalAccess`** — структура для майбутнього (зовнішні адвокати з об'єднання):
```json
{
  "userId": "external_petro",
  "externalLawyerInfo": { "name": "...", "license": "...", "tenant": "..." },
  "caseRole": "consulted",
  "validUntil": "2026-08-01",
  "allowedActions": ["read", "comment", "add_document"]
}
```

### Розширення `hearings[*]`, `deadlines[*]`, `notes[*]`

Додати до кожного:
```json
{
  "tenantId": "ab_levytskyi",
  "createdBy": "vadym"
}
```

Поле `createdBy` дублює існуюче `userId` де воно вже є — щоб уніфікувати.

### Розширення `time_entries[*]` (коли з'являться)

Готуємо структуру наперед:
```json
{
  "tenantId": "ab_levytskyi",
  "userId": "vadym",
  "userRoleAtTime": "bureau_owner",
  "billingRate": null
}
```

### Нова структура `auditLog[]`

Додати в корінь:

```json
{
  "auditLog": [
    {
      "id": "log_1730900000000_abc",
      "tenantId": "ab_levytskyi",
      "userId": "vadym",
      "userRoleAtTime": "bureau_owner",
      "action": "destroy_case",
      "targetType": "case",
      "targetId": "case_brn",
      "timestamp": "2026-05-04T14:23:00Z",
      "details": {
        "caseName": "Брановський Ю.В.",
        "reason": "user_initiated"
      },
      "context": {
        "module": "dashboard",
        "agent": null,
        "userAgent": "...",
        "ipAddress": null
      }
    }
  ]
}
```

**Які дії пишуться в audit log (на цей TASK):**
- `destroy_case`, `close_case`, `restore_case`, `create_case`
- `delete_hearing`
- `delete_deadline`
- Зміна `team[]` або `ownerId` справи (коли з'явиться)
- Зміна налаштувань tenant'у

Інші дії (update_field, add_note тощо) **в audit log не пишемо** в цьому TASK — занадто багатослівно. Розширюватимемо аудит в наступних TASK у міру потреби.

### Структура `structuralUnits[]` (заготовка на майбутнє)

Додати в корінь з порожнім масивом:

```json
{
  "structuralUnits": []
}
```

В майбутньому сюди додаватимуться кластери об'єднань і практики фірм. Зараз — заготовка щоб не міняти структуру коли додамо.

---

## МІГРАЦІЯ ІСНУЮЧИХ ДАНИХ

### Логіка міграції

При першому завантаженні розширеної версії системи:

1. Перевірити чи є в `registry_data.json` поле `tenants[]`
2. Якщо немає — виконати міграцію:
   - Створити tenant `ab_levytskyi` з типом `bureau` і реквізитами АБ Левицького
   - Створити user `vadym` з роллю `bureau_owner`
   - Для кожного запису в `cases[]`:
     - Додати `tenantId: 'ab_levytskyi'`
     - Додати `ownerId: 'vadym'`
     - Додати `team: [{ userId: 'vadym', caseRole: 'lead' }]`
     - Додати `shareType: 'internal'`
     - Додати `externalAccess: []`
   - Для кожного `hearings[*]`, `deadlines[*]`, `notes[*]` — додати `tenantId` і `createdBy: 'vadym'`
   - Створити порожній `auditLog: []`
   - Створити порожній `structuralUnits: []`
3. Зберегти оновлений JSON у Drive
4. Поставити `migrationVersion: '2.0_saas_foundation'` в корені даних

### Безпека міграції

- Перед міграцією — створити **резервну копію** `registry_data_backup_pre_saas.json` у тій самій папці Drive
- Якщо щось пішло не так — система має автоматично відкотитися на резервну копію і показати повідомлення «Помилка міграції, дані відновлено»
- Логувати кожен крок міграції в консоль для діагностики

---

## НОВІ УТИЛІТНІ ФУНКЦІЇ

Створити файл `src/services/permissions.js`:

```javascript
/**
 * Permissions service — перевірки прав доступу
 *
 * Поточна логіка: всі перевірки повертають true для активного користувача
 * (зараз це Вадим як bureau_owner). Це заглушки які будуть замінені на
 * повноцінну логіку при переході в SaaS.
 *
 * Принцип: інтерфейс функцій фінальний, реалізація мінімальна.
 */

/**
 * Перевірити чи має користувач доступ до tenant'у
 * @param {string} userId
 * @param {string} tenantId
 * @returns {boolean}
 */
export function checkTenantAccess(userId, tenantId) {
  // ЗАГЛУШКА: завжди true для поточного користувача
  // В майбутньому: перевіряти що user.tenantId === tenantId
  return true;
}

/**
 * Перевірити чи дозволена дія для глобальної ролі
 * @param {string} globalRole — наприклад 'bureau_owner'
 * @param {string} action — наприклад 'destroy_case'
 * @returns {boolean}
 */
export function checkRolePermission(globalRole, action) {
  // ЗАГЛУШКА: завжди true для bureau_owner
  // В майбутньому: матриця ролей × дії з конкретними правилами
  return true;
}

/**
 * Перевірити чи має користувач доступ до конкретної справи
 * @param {string} userId
 * @param {object} caseObj — об'єкт справи з полями ownerId, team, shareType, externalAccess
 * @returns {boolean}
 */
export function checkCaseAccess(userId, caseObj) {
  // ЗАГЛУШКА: завжди true якщо userId === caseObj.ownerId
  // В майбутньому: перевіряти team[] і externalAccess[]
  if (!caseObj) return false;
  if (caseObj.ownerId === userId) return true;
  if (caseObj.team?.some(member => member.userId === userId)) return true;
  if (caseObj.externalAccess?.some(ext => ext.userId === userId && new Date(ext.validUntil) > new Date())) return true;
  return false;
}

/**
 * Записати дію в auditLog
 * @param {object} params { tenantId, userId, action, targetType, targetId, details, context }
 */
export function writeAuditLog(params) {
  const entry = {
    id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
    tenantId: params.tenantId,
    userId: params.userId,
    userRoleAtTime: getCurrentUserRole(params.userId),
    action: params.action,
    targetType: params.targetType,
    targetId: params.targetId,
    timestamp: new Date().toISOString(),
    details: params.details || {},
    context: params.context || {}
  };

  // Додати до auditLog в state
  // Конкретна реалізація залежить від того як state працює в App.jsx
  // Має бути викликано через executeAction або окремий хук

  return entry;
}

/**
 * Отримати поточну роль користувача
 * @param {string} userId
 * @returns {string} globalRole
 */
function getCurrentUserRole(userId) {
  // Тимчасово хардкод для Вадима
  if (userId === 'vadym') return 'bureau_owner';
  return 'unknown';
}

/**
 * Список дій які пишуться в audit log
 */
export const AUDIT_ACTIONS = [
  'create_case',
  'close_case',
  'restore_case',
  'destroy_case',
  'delete_hearing',
  'delete_deadline',
  'change_case_team',
  'change_case_owner',
  'update_tenant_settings'
];

export function shouldAudit(action) {
  return AUDIT_ACTIONS.includes(action);
}
```

---

## ІНТЕГРАЦІЯ В executeAction

Розширити поточну функцію `executeAction` (в `App.jsx` або де вона зараз):

```javascript
import { checkTenantAccess, checkRolePermission, checkCaseAccess, writeAuditLog, shouldAudit } from './services/permissions';

async function executeAction(actionType, params, context = {}) {
  // 1. Отримати поточного користувача (зараз — Вадим завжди)
  const currentUser = getCurrentUser(); // повертає { userId: 'vadym', tenantId: 'ab_levytskyi', globalRole: 'bureau_owner' }

  // 2. Перевірка tenant
  if (!checkTenantAccess(currentUser.userId, currentUser.tenantId)) {
    throw new Error('Tenant access denied');
  }

  // 3. Перевірка глобальної ролі для цієї дії
  if (!checkRolePermission(currentUser.globalRole, actionType)) {
    throw new Error(`Action ${actionType} not allowed for role ${currentUser.globalRole}`);
  }

  // 4. Перевірка доступу до конкретної справи (якщо action стосується справи)
  if (params.caseId) {
    const caseObj = findCaseById(params.caseId);
    if (!checkCaseAccess(currentUser.userId, caseObj)) {
      throw new Error(`No access to case ${params.caseId}`);
    }
  }

  // 5. Виконати дію (стара логіка)
  const result = await performAction(actionType, params, context);

  // 6. Записати в audit log якщо треба
  if (shouldAudit(actionType)) {
    writeAuditLog({
      tenantId: currentUser.tenantId,
      userId: currentUser.userId,
      action: actionType,
      targetType: getTargetType(actionType),
      targetId: params.caseId || params.targetId,
      details: { params },
      context: {
        module: context.module || 'unknown',
        agent: context.agent || null
      }
    });
  }

  return result;
}
```

**Важливо:** функція `getCurrentUser()` зараз повертає хардкод про Вадима. У майбутньому — отримує з контексту авторизації. Інтерфейс не змінюється.

---

## ДОКУМЕНТАЦІЯ В CLAUDE.md

Додати в `CLAUDE.md` (або створити окремий розділ) чіткий опис:

```markdown
## SaaS Foundation v2.0

Legal BMS архітектурно готовий до мультикористувацької версії. Зараз працює як соло (Вадим), але всі структури підтримують майбутнє розгортання.

### Типи організацій (tenants)
- solo — адвокат-фізособа
- bureau — адвокатське бюро (наш випадок)
- association — адвокатське об'єднання
- firm — юридична фірма

### Ролі користувачів (за типом організації)
[повний список]

### Архітектура перевірок
Кожна дія в системі проходить через executeAction → checkTenantAccess → checkRolePermission → checkCaseAccess. Зараз перевірки — заглушки що повертають true для Вадима. У SaaS — повноцінна логіка.

### Чому це закладено зараз
Структура без логіки коштує 1 день роботи. Переробка готової системи під SaaS без структури — місяці. Закладаємо зараз поки бідно.

### Що НЕ робити
- НЕ додавати UI для керування користувачами/ролями (окремий TASK)
- НЕ міняти заглушки на реальну логіку без згоди архітектора
- НЕ дублювати поля tenantId/userId в нових даних — використовувати існуючі утиліти
```

---

## РОЗДІЛ "SAAS IMPLICATIONS"

Цей TASK і є SaaS-foundation. Тому розділ короткий:

### Поля які додаємо
- `tenantId` всюди — для tenant isolation
- `userId`/`ownerId`/`createdBy` — для авторства
- `team[]` в cases — для команди справи
- `auditLog[]` в корені — для відстеження критичних дій

### Permissions
- Усі існуючі дії продовжують працювати для bureau_owner (заглушки повертають true)
- Перевірки викликаються — готові до реальної логіки в майбутньому

### Аудит
- Логуються: create/close/restore/destroy_case, delete_hearing, delete_deadline, зміни team/owner, зміни settings
- Інші дії — не логуються в цьому TASK

### Tenant isolation
- Усі дані прив'язані до `tenantId`
- Зараз єдиний tenant — `ab_levytskyi`
- Майбутній SaaS — кожен новий tenant ізольований природно

### Що НЕ робимо зараз але треба пам'ятати
- UI керування користувачами і ролями
- Реальна логіка `checkRolePermission` (матриця)
- Білінгові ставки за грейдом
- Конфлікти інтересів (для фірм)
- Структурні підрозділи (кластери, практики)

---

## ПЛАН ВИКОНАННЯ ПО КРОКАХ

Claude Code виконує TASK у такому порядку:

### Крок 1 — Резервна копія (5 хв)
- Створити копію `registry_data.json` як `registry_data_backup_pre_saas.json` у тій самій папці Drive
- Логувати «Резервна копія створена»

### Крок 2 — Структури в registry_data.json (1-2 год)
- Додати `tenants[]` з єдиним записом
- Додати `users[]` з єдиним записом
- Додати `auditLog[]` (порожній)
- Додати `structuralUnits[]` (порожній)
- Додати `migrationVersion: '2.0_saas_foundation'`

### Крок 3 — Міграція існуючих даних (2-3 год)
- Для кожного `cases[*]` — додати tenantId, ownerId, team, shareType, externalAccess
- Для кожного `hearings[*]` — додати tenantId, createdBy
- Для кожного `deadlines[*]` — додати tenantId, createdBy
- Для кожного `notes[*]` — додати tenantId, createdBy
- Зберегти оновлений JSON у Drive

### Крок 4 — Створення permissions.js (1 год)
- Створити `src/services/permissions.js` з функціями і константами
- Реалізувати заглушки які повертають правильні значення для Вадима

### Крок 5 — Інтеграція в executeAction (1-2 год)
- Знайти поточну реалізацію executeAction
- Додати виклики checkTenantAccess, checkRolePermission, checkCaseAccess
- Додати запис в auditLog для критичних дій
- Перевірити що нічого не зламалося

### Крок 6 — getCurrentUser helper (30 хв)
- Створити `src/services/currentUser.js` з функцією `getCurrentUser()` яка повертає Вадима
- Інтегрувати в executeAction
- Інтегрувати в інші місця де треба знати userId

### Крок 7 — Документація (30 хв)
- Оновити `CLAUDE.md` з новою архітектурою
- Додати коментарі в код де треба

### Крок 8 — Тестування (1-2 год)
- Перевірити що всі існуючі модулі працюють як раніше
- Створити нову справу — переконатися що всі поля заповнюються правильно
- Видалити справу — переконатися що audit log пише запис
- Перезавантажити сторінку — переконатися що дані з Drive завантажуються коректно
- Перевірити що нічого не виглядає інакше для Вадима

### Крок 9 — Commit (15 хв)
- Один commit з описом «SaaS Foundation v2.0 — tenant, users, team, audit log, permissions service»
- Push у main

---

## КРИТЕРІЇ УСПІХУ

TASK вважається виконаним якщо:

1. ✅ `registry_data.json` має структури `tenants[]`, `users[]`, `auditLog[]`, `structuralUnits[]`
2. ✅ Усі існуючі дані мігровані з default-значеннями (всі мають `tenantId: 'ab_levytskyi'`)
3. ✅ Cases мають `team[]`, `ownerId`, `shareType`, `externalAccess`
4. ✅ Файл `src/services/permissions.js` існує з усіма функціями
5. ✅ `executeAction` викликає перевірки і пише в audit log для критичних дій
6. ✅ Резервна копія `registry_data_backup_pre_saas.json` створена в Drive
7. ✅ Поточна функціональність системи **не зламалася** — всі модулі працюють як раніше
8. ✅ При створенні нової справи нові поля заповнюються автоматично з default-значеннями
9. ✅ При видаленні справи з'являється запис в `auditLog`
10. ✅ `CLAUDE.md` оновлений з описом SaaS Foundation
11. ✅ Один чистий commit у main з зрозумілим повідомленням

---

## РИЗИКИ І ПОПЕРЕДЖЕННЯ

### Ризик 1 — поломка існуючих даних

**Якщо щось піде не так** під час міграції — резервна копія дозволить відкотитися. Але **обов'язково** перед commit перевірити що:
- Всі справи відкриваються
- Всі засідання видно у дашборді
- Всі нотатки доступні
- QI працює
- Агенти відповідають

Якщо хоч щось зламалося — **не комітити**, відкотитися на резервну копію, повідомити архітектора.

### Ризик 2 — бажання «оптимізувати» зайве

Не **виправляти баги які знайшов по ходу** в інших модулях. Записати в окремий файл `BUGS_FOUND_DURING_SAAS_FOUNDATION.md` і сказати архітектору. Скоуп цього TASK — тільки SaaS Foundation.

### Ризик 3 — переборщити з логікою

Заглушки `checkTenantAccess`, `checkRolePermission`, `checkCaseAccess` повертають true для Вадима. **НЕ писати справжню логіку** з матрицями ролей. Це **окремий майбутній TASK**. Якщо є спокуса «доробити заодно» — стримати.

### Ризик 4 — Drive API нестабільність

OAuth токен Drive живе ~1 годину. Якщо міграція зайде у фазу збереження великого JSON — токен може закінчитися. Передбачити:
- Якщо отримуємо 401 при збереженні — зберегти стан міграції локально
- Показати користувачу «Перепідключіть Drive і натисніть Продовжити»
- Дати кнопку «Продовжити міграцію» яка не починає заново, а продовжує з місця останньої успішної операції

---

## ПІСЛЯ ВИКОНАННЯ

Після успішного виконання цього TASK архітектор отримає:

1. Базу для написання `TASK_tool_use_preparation_v1` — який буде використовувати `tenantId`/`userId` контекст у всіх тулах
2. Базу для всіх майбутніх TASK — кожен новий модуль одразу пишеться SaaS-готовим
3. Готовий аудит критичних дій
4. Прозору архітектуру ролей — навіть якщо логіка ще заглушка

**Наступний крок:** TASK_tool_use_preparation_v1.md (буде створений архітектором після цього TASK)

---

## ЗВІТ ДЛЯ АРХІТЕКТОРА

Після виконання Claude Code звітує:

```markdown
# Звіт виконання TASK_saas_foundation_v1

## Виконано
- [x] Резервна копія створена
- [x] tenants[] додано з 1 записом
- [x] users[] додано з 1 записом
- [x] auditLog[] створено
- [x] structuralUnits[] створено
- [x] cases[] мігровано: 18 записів оновлено
- [x] hearings[] мігровано: N записів оновлено
- [x] deadlines[] мігровано: N записів оновлено
- [x] notes[] мігровано: N записів оновлено
- [x] permissions.js створено
- [x] executeAction інтегровано
- [x] currentUser helper створено
- [x] CLAUDE.md оновлено
- [x] Тестування пройдено

## Знайдені проблеми
- [список будь-яких проблем що виникли під час роботи]

## Знайдені баги в інших модулях (не виправлені)
- [записані в BUGS_FOUND_DURING_SAAS_FOUNDATION.md]

## Час виконання
- Реальний: X годин
- Прогнозований: 1 день

## Commit hash
- [hash]
```

---

**Кінець TASK**
