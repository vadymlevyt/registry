# КОНТЕКСТ — SaaS / Multi-user
# Legal BMS / АБ Левицького
# Версія 1.0 | Дата: 2026-05-06

> Стартовий контекст для тематичного чату по SaaS-комерціалізації, multi-user активації, тарифних пакетах і ширшій архітектурі.

---

## 1. ПОТОЧНИЙ СТАН — ЩО ВЖЕ ЗАКЛАДЕНО

### SaaS Foundation v1 (2026-05-04, commit 4f719fc)

**schemaVersion: 2** — введено мульти-tenant структуру.

Створено:
- `tenants[]` — організації (поки одна: `ab_levytskyi`)
- `users[]` — користувачі (поки один: vadym як `bureau_owner`)
- `auditLog[]` — критичні дії
- `structuralUnits[]` — підрозділи (заглушка)

Типи tenants (4 фіксовані):
- **solo** — адвокат-фізособа
- **bureau** — адвокатське бюро (наш випадок)
- **association** — об'єднання партнерів
- **firm** — юридична фірма (ієрархічна)

Глобальні ролі (різні за типом tenant):
- Solo: `solo_advocate`, `solo_assistant`
- Bureau: `bureau_owner`, `bureau_lawyer`, `bureau_assistant`
- Association: `association_partner/lawyer/assistant`
- Firm: `firm_managing_partner`, `firm_partner`, `firm_counsel`, `firm_senior/junior_associate`, `firm_paralegal`, `firm_intern`
- Cross-tenant: `external_collaborator`

Ролі в команді справи (caseRole):
- `lead/owner` — повний контроль
- `oversight` — read-only + втручання
- `team_member/co-lead/support` — робота
- `consulted` — read-only + коментує
- `external` — тимчасовий доступ

Сервіси:
- `tenantService.js` — `getCurrentTenant`, `getCurrentUser`, DEFAULT_TENANT/USER
- `permissionService.js` — `checkTenantAccess`, `checkRolePermission`, `checkCaseAccess`
- `auditLogService.js` — `AUDIT_ACTIONS`, `shouldAudit`, `writeAuditLog`
- `migrationService.js` — `migrateRegistry`, `ensureCaseSaasFields`

Поля справи (обов'язкові SaaS):
- `tenantId`, `ownerId`
- `team[]: [{userId, caseRole, addedAt, addedBy, permissions}]`
- `shareType`: private | internal | external
- `externalAccess[]`

`destroy_case` — спеціальна процедура з audit log pre-delete (status: pending → done/failed).

### SaaS Foundation v1.1 Patch (2026-05-05, commit 94faf6c)

**schemaVersion: 3, settingsVersion: "3.0_patch_and_extension"**

Виправлено архітектурний борг:
- agentHistory localStorage slice -20 → -50 (3-tier cache визнано валідним)
- `levytskyi_action_log` видалено (було дублюванням auditLog)
- id mixed types → всі string `case_<n>`
- `driveService.writeCases` мертвий блок видалено

Нові структури:
- `ai_usage[]` — телеметрія токенів AI (LIFO 50000)
- `caseAccess[]` — заглушка індексу для майбутнього масштабу

Розширення tenant:
- `tenant.storage` — provider (`drive_legacy`/`r2_managed`/`drive_byos`), quotaGB, usedBytes
- `tenant.modelPreferences` — null для 9 типів агентів (qiAgent, dossierAgent, document_parser, etc)
- `tenant.subscription.{limits, current, alerts}` — структура обліку лімітів

Розширення case.team:
- `permissions: {canEdit, canDelete, canShare, canAddTeam, canViewBilling, canEditBilling, canRunAI}`
- Дефолти за caseRole (owner = всі true, external = canViewBilling only, etc)

Нові сервіси:
- `aiUsageService.js` — MODEL_PRICING, calculateCost, logAiUsage, getUsageBy*
- `modelResolver.js` — resolveModel(agentType) з ієрархією user → tenant → system
- `subscriptionService.js` — recalculateCurrent, checkLimits

Активовано заглушки:
- `checkTenantAccess` — реальна перевірка
- `checkCaseAccess` — повна логіка з tenant isolation, bureau_owner override, ownerId, team membership, externalAccess

### Billing Foundation v2 (2026-05-05, commit 5a18320)

**schemaVersion: 4, settingsVersion: "4.0_billing_foundation"**

Деталі — у `context_billing_crm_v1.md`.

Ключове для SaaS:
- `time_entries[]` має `tenantId`, `userId` — мульти-tenant ready
- Автогенерація hours billed для `tenant.subscription.current.hoursBilled`
- Permissions для time_entries (canViewTimeEntries, canEditTimeEntry)

---

## 2. АРХІТЕКТУРА — ЩО ВЖЕ ПІДГОТОВЛЕНО, ЩО ЗАГЛУШКА

```
ПОВНІСТЮ АКТИВНЕ:
─────────────────────────────────────────
✅ checkTenantAccess (ізоляція даних tenant)
✅ checkCaseAccess (доступ до справ)
✅ writeAuditLog (критичні дії)
✅ ai_usage логування (10 точок API)
✅ Permissions per case.team (за caseRole)
✅ Bureau_owner може все в межах tenant

ЗАГЛУШКИ — ЧЕКАЮТЬ АКТИВАЦІЇ:
─────────────────────────────────────────
⏸ checkRolePermission (поки true для bureau_owner)
⏸ caseAccess[] індекс (поки порожній)
⏸ tenant.modelPreferences (поки null)
⏸ tenant.subscription.limits (поки null)
⏸ tenant.storage.quotaGB (поки null)
⏸ Запрошення нових юристів (UI немає)
⏸ Структурні юніти бюро (підрозділи)
⏸ External access (зовнішні адвокати)
⏸ Telegram Login Widget для юристів
⏸ Multi-tenant маршрутизація на сервері
─────────────────────────────────────────
```

**Ключове:** структури даних повні, заглушки — тільки в активаційному шарі. Multi-user активується БЕЗ переписування коду — заглушки замінюються на реальну логіку.

---

## 3. MULTI-USER ACTIVATION — ПЛАН

### Тригер запуску

Коли Олена-помічниця реально починає працювати в системі.

### TASK Multi-user Activation v1

**Орієнтовна тривалість:** 1-2 дні роботи Claude Code

**Включає:**

#### 3.1. Активація caseAccess[] індексу

Зараз заглушка. Активуємо:
- При створенні/оновленні team[] → автоматичне оновлення caseAccess[]
- Поля: caseId, userId, tenantId, caseRole, addedAt, expiresAt, permissionsHash
- Index для швидкого пошуку "які справи доступні юристу"

#### 3.2. UI керування користувачами

Нова сторінка "Команда" в системі:
- Список юристів бюро
- Кнопка "Додати юриста"
- Заповнення: email, ПІБ, РНОКПП, роль
- Email-запрошення з посиланням на реєстрацію
- Юрист створює пароль, авторизується

#### 3.3. UI керування доступом до справи

В картці справи — секція "Команда":
- Хто має доступ
- Хто провідний (lead)
- Кнопка "Додати юриста до справи"
- Вибір caseRole і permissions
- Видалити з команди

#### 3.4. Заміна заглушок на реальну логіку

- `checkRolePermission(userId, action, tenantId)` — перевірка дозволу за роллю
- Усі ACTIONS перевіряють permissions в executeAction
- Audit log пише userId на всіх діях

#### 3.5. Видимість даних

Юрист бачить:
- Тільки свої справи (за caseAccess[])
- Тільки свої time_entries (canViewTimeEntries)
- Тільки свої ai_usage (за userId)
- Bureau_owner бачить все в межах tenant

---

## 4. ТАРИФНІ ПАКЕТИ (ПЛАН)

### Концепція

```
SOLO (один адвокат):
─────────────────────────────────────────
- 1 користувач
- До 50 справ
- Sonnet для всіх агентів
- 50K AI токенів/міс
- 5 GB storage
- Telegram бот клієнтський
- Базовий білінг
- Ціна: ~$15-25/міс

BUREAU (бюро, до 5 юристів):
─────────────────────────────────────────
- До 5 користувачів
- До 200 справ
- Sonnet + Opus для досьє-агента (Premium)
- 200K AI токенів/міс
- 20 GB storage
- 2 Telegram боти (клієнтський + робочий)
- Командні чати по справах
- Повний білінг + звіти
- Ціна: ~$50-80/міс

ENTERPRISE (фірма, 20+):
─────────────────────────────────────────
- Без обмежень користувачів
- Без обмежень справ
- Власний вибір моделей AI (Provider Abstraction)
- 1M+ AI токенів/міс
- 100+ GB storage
- White-label (свій брендинг)
- API для інтеграцій
- Пріоритетна підтримка
- Ціна: за запитом
─────────────────────────────────────────
```

### Технічна реалізація

Активуємо вже закладені структури:
- `tenant.subscription.limits` — заповнюємо реальними значеннями
- `tenant.modelPreferences` — Premium юзер обирає Opus
- `tenant.subscription.alerts` — попередження при 80% використання

Нові сервіси:
- `billingPaymentService.js` — інтеграція зі Stripe/LiqPay
- `subscriptionRenewalService.js` — автопродовження підписки
- `usageEnforcementService.js` — блокування при перевищенні

---

## 5. ХОСТИНГ І ІНФРАСТРУКТУРА (МАЙБУТНЄ)

### Поточна архітектура (для прототипу)

```
GitHub Pages (статика)
   ↓
React SPA в браузері
   ↓
Прямі виклики:
- Anthropic API
- Google Drive API
- Document AI
─────────────────────────────────────────

API ключі — в localStorage адвоката.
Ніякого backend.
```

**Працює для одного бюро,** але не масштабується для SaaS.

### SaaS-архітектура (заплановано)

```
ФРОНТЕНД:
─────────────────────────────────────────
- Той самий React SPA
- Cloudflare Pages або Vercel (швидкість)
- Custom domain (наприклад legalbms.app)

BACKEND (новий шар):
─────────────────────────────────────────
- Cloudflare Workers або Vercel Edge
- Node.js / Hono framework
- Маршрутизація API запитів

SHARED АРХІТЕКТУРА:
─────────────────────────────────────────
- Auth: Auth0 / Clerk / власний
- Sessions: JWT
- Multi-tenant routing (tenantId з токену)

STORAGE per tenant:
─────────────────────────────────────────
- Drive (legacy) — bring-your-own
- R2 (managed) — наш storage за тариф
- Per-tenant ізольовані bucket'и

DATABASE:
─────────────────────────────────────────
- registry_data per tenant залишається 
  на storage tenanta (зараз — Drive)
- АБО мігруємо в Postgres/PlanetScale 
  для масштабу

PAYMENT:
─────────────────────────────────────────
- Stripe для західних
- LiqPay для українських
- Webhook → активація tenant.subscription
```

**Ключове:** перехід поетапний. Не "переписати все одразу", а додавати шари:
1. Спочатку залишається Drive як storage
2. Backend з'являється для auth і routing
3. Потім міграція storage опціонально (Drive → R2)

---

## 6. STORAGE MIGRATION (ОКРЕМИЙ TASK)

### Призначення

Функція "Змінити директорію" в системі. Дає адвокату:
- Перенести систему в іншу папку Drive
- Перейти з особистого Drive на корпоративний
- (В майбутньому) Перейти з Drive на R2

### Логіка

```
В МЕЖАХ ОДНОГО DRIVE:
─────────────────────────────────────────
Drive API move (зміна parentId)
- Без копіювання файлів
- Швидко
- Atomically (все або нічого)

МІЖ СХОВИЩАМИ (Drive ↔ R2):
─────────────────────────────────────────
Copy + delete
- Копіюємо всі файли в нове сховище
- Verify integrity
- Видаляємо зі старого
- Оновлюємо tenant.storage.provider

ПРОЦЕДУРА:
─────────────────────────────────────────
1. Вибір нової папки/storage
2. Попередження якщо нова не порожня
3. ОБОВ'ЯЗКОВИЙ бекап перед міграцією
4. Move/copy виконання з progress
5. Оновлення rootFolderId
6. Reload системи
─────────────────────────────────────────
```

### Активує заглушки з SaaS v1.1

- `tenant.storage.provider` змінюється з `drive_legacy` на `r2_managed`
- `tenant.storage.usedBytes` рахується автоматично
- Перевірки лімітів за тарифом

### Тривалість TASK

1 день роботи Claude Code. Виконується **після** Multi-user Activation і Billing UI.

---

## 7. AI PROVIDER ABSTRACTION (ВІДКЛАДЕНО НА 6-12 МІС)

### Тригер

SaaS-комерціалізація. Премиум юзери хочуть:
- Обирати між Claude / GPT-4 / Grok
- Або compliance вимоги змушують GPT (для деяких компаній)

### Архітектура

```
src/services/ai/
├── aiService.js          ← фасад
├── providers/
│   ├── anthropic.js      ← поточний
│   ├── openai.js         ← новий
│   └── grok.js           ← новий
└── adapters/
    ├── messageAdapter.js  ← конвертація форматів
    ├── toolAdapter.js     ← Anthropic tools ↔ OpenAI functions
    └── visionAdapter.js   ← document blocks ↔ vision
```

Зміни в коді — **лінійні**. Кожна точка виклику API замінюється з:
```js
fetch('api.anthropic.com/...')
```
на:
```js
aiService.callAgent('agentType', {messages, tools})
```

10 точок зараз → 10 рядків змін. 50 точок потім → 50 рядків.

### Інтеграція з SaaS

`tenant.modelPreferences` стає реальним:
```json
{
  "qiAgent": "claude-sonnet-4",
  "dossierAgent": "gpt-4o",  // Premium вибір
  "documentParser": "claude-haiku-4-5"
}
```

`aiService.resolveModel()` бачить prefs → роутить на правильний provider.

### Тривалість TASK

1-2 дні Claude Code. **Не зараз** — поки немає реальної потреби.

---

## 8. ОЛЕНА ЯК ПЕРШИЙ ADDITIONAL USER

### Сценарій підключення

1. Олена має email
2. Адвокат у системі: "Додати помічника"
3. Заповнює: ПІБ, email, роль `bureau_assistant`
4. Олена отримує email з посиланням
5. Реєструється, створює пароль
6. Заходить у систему → бачить свої справи

### Що Олена може

За дефолтними permissions для `bureau_assistant`:
- ✅ Бачити справи де вона в команді
- ✅ Додавати нотатки до справ
- ✅ Створювати hearings/deadlines
- ❌ Видаляти справи
- ❌ Бачити white financial billing
- ✅ Чат з агентом досьє по своїх справах

### Що адвокат-керівник може

За дефолтами `bureau_owner`:
- ✅ Все в межах tenant
- ✅ Додавати/видаляти юристів
- ✅ Призначати в команди справ
- ✅ Налаштовувати permissions
- ✅ Бачити все витрачене на AI
- ✅ Керувати білінгом

---

## 9. РОАДМАП SAAS-РОЗВИТКУ

```
PHASE 0 (ЗАРАЗ) — ✅ Foundation готова
─────────────────────────────────────────
- SaaS v1 + v1.1 + Billing v2 інтегровано
- Все має tenantId, userId
- Permissions працюють
- Заглушки чекають активації

PHASE 1 (через 1-3 міс) — Multi-user базовий
─────────────────────────────────────────
- Олена працює як перший юрист бюро
- TASK Multi-user Activation
- UI керування командою
- Активація caseAccess[]
- Перевірка реальних сценаріїв

PHASE 2 (через 4-6 міс) — Підготовка SaaS
─────────────────────────────────────────
- Backend шар (Cloudflare Workers/Vercel)
- Auth система
- Multi-tenant routing
- Реєстрація нових бюро
- Tenant onboarding wizard

PHASE 3 (через 7-9 міс) — Платежі і тарифи
─────────────────────────────────────────
- Stripe/LiqPay інтеграція
- Тарифні плани активуються
- subscription.limits діє
- usageEnforcementService

PHASE 4 (через 9-12 міс) — Storage Migration
─────────────────────────────────────────
- Опціональний перехід на R2
- Storage providers активуються
- Економія для тих хто має багато даних

PHASE 5 (через 12 міс) — Provider Abstraction
─────────────────────────────────────────
- AI Provider Abstraction
- Premium вибір моделей
- White-label для Enterprise

PHASE 6 (12+ міс) — Зрілий продукт
─────────────────────────────────────────
- Маркетинг, лендинг, реклама
- Контентний залп з накопиченого
- API для інтеграцій
- Партнерські програми
─────────────────────────────────────────
```

---

## 10. ВІДКРИТІ ПИТАННЯ

### 10.1. Backend — наш чи бессерверний

Cloudflare Workers (бесерверний) vs DigitalOcean (сервер).
- Workers — простіше, дешево, масштабується
- Сервер — більше контролю, складніше DevOps

### 10.2. Auth провайдер

Auth0 (готовий) vs Clerk (сучасніший) vs власний (контроль, складність).

### 10.3. Database стратегія

Drive як storage per tenant vs Postgres централізований.
- Drive — кожен tenant має свої дані під контролем
- Postgres — швидше запити, складніше privacy

Гібрид — registry_data в БД, файли на storage tenanta.

### 10.4. Multi-region для Європи

GDPR — дані європейських адвокатів мусять бути в EU.
- Зараз Document AI в europe-west2 ✓
- Drive — користувач сам обирає
- Backend — треба буде EU region

### 10.5. White-label для фірм

Як Enterprise тариф дозволяє фірмі брендувати під себе:
- Свій domain
- Свій логотип
- Свої кольори
- Свої email-нотифікації

Технічно — параметри в tenant.branding.

### 10.6. Маршрутизація tenants

Як визначати tenant з URL:
- subdomain (ab-levytskyi.legalbms.app)
- path (legalbms.app/ab-levytskyi)
- автентифікація (з токену)

Найімовірніше — комбінація.

### 10.7. SLA і підтримка

Який SLA пропонувати?
- Solo: best effort
- Bureau: 99% uptime
- Enterprise: 99.9% + dedicated support

---

## 11. ПИТАННЯ НА СТИКУ З ІНШИМИ МОДУЛЯМИ

### З Billing

- Як налаштувати subscription.limits для різних тарифів
- Як рахувати і обмежувати tokensPerMonth
- Premium вибір Opus як окремий платіж чи в підписці

### З CRM

- Multi-user видимість клієнтів (хто з команди бачить кого)
- Передача клієнтів між юристами
- Конфіденційність між клієнтами одного бюро

### З Telegram

- Кожен tenant має свою пару ботів
- Юристи авторизуються через Telegram Login Widget
- Командні чати по справах прив'язані до tenant

### З Документами

- Storage quota per tenant
- Document AI запити з tenant context
- Шаблони документів — системні + tenant + user

---

## 12. ЯК ВЕСТИ ЦЕЙ ТЕМАТИЧНИЙ ЧАТ

### Призначення

Тематичний чат для:
- Multi-user активації (Олена)
- Підготовки до SaaS-комерціалізації
- Тарифних пакетів
- Backend-архітектури
- Storage Migration
- AI Provider Abstraction
- Onboarding нових бюро

### Як стартувати

При старті чату даєш мені:
- Цей контекстний файл
- Поточний CLAUDE.md
- DEVELOPMENT_PHILOSOPHY.md
- Питання або тему

### Чого тут НЕМАЄ

- Розробка модуля досьє (окремий чат)
- Білінг логіка (контекст_billing_crm)
- Маркетинг публічний (інший чат)
- ЄСІТС (окремий)

---

## 13. ФАЙЛИ ПРОЕКТУ

- `report_saas_foundation.md` — звіт SaaS Foundation v1
- `report_saas_foundation_v1_1.md` — звіт Patch
- `report_billing_foundation.md` — Billing v2
- `progress_saas_foundation.md` — прогрес
- `bugs_found_during_saas_foundation.md` — знахідки
- `CLAUDE.md` v5.0 — повна архітектура
- `DEVELOPMENT_PHILOSOPHY.md` — принципи розробки
- `contextual_tails_v1.md` — реєстр хвостів
- `context_billing_crm_v1.md` — Billing+CRM модуль

---

**Кінець контекстного файлу SaaS / Multi-user v1.0**

Готовий для запуску нового тематичного чату.
