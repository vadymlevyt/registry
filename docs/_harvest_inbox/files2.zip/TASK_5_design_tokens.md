# TASK 5 — Design Tokens у `tokens.css` + базові UI компоненти

**Дата формування:** 08.05.2026
**Фаза:** 1.6 — UI Reform (перший TASK)
**Виконавець:** Claude Code (Opus 4.7, 1M context)
**Орієнтовний обсяг:** 6-8 годин
**Передумови:** TASK 1, 2, 3 (з patch'ами), 4 завершені і закомічені

---

## ПРИНЦИПИ ВИКОНАННЯ

**Творчо, виважено, охайно.** Це перший TASK Фази 1.6 (UI Reform). Усе що зробиш зараз стане фундаментом візуальної системи Legal BMS на роки. Адвокат: "хочу щоб система була гарною не тільки ззовні а й зсередини". Старайся писати як писав би сам адвокат якби вмів — простий код, ясні назви, без зайвих абстракцій.

**Перевіряй перед змінами.** TASK 1-4 значно змінили код. Реальний поточний стан App.css і CaseDossier може відрізнятись від того що описано в діагностиці. Перед редагуванням — `view` файлу.

**Тести разом з кодом.** Після TASK 4 у нас є Vitest. Кожен новий компонент має юніт-тест. Це нове правило з DEVELOPMENT_PHILOSOPHY.md — не "потім додамо".

**SaaS-готовність.** Токени мають бути такими щоб у майбутньому можна було легко додати кастомну палітру для тенанта (наприклад, фірмові кольори бюро) — через CSS-перевизначення, не через рефакторинг.

**Без тимчасових рішень.** Якщо щось можна зробити нормально зараз — зроби нормально.

---

## КОНТЕКСТ

### Поточний стан CSS (з діагностики 07.05.2026 + досвід TASK 1-4)

**App.css** — має CSS-змінні в `:root` (рядки 3-21):
```css
--bg: #0f1117    --surface: #191c27    --surface2: #222638
--border: #2d3250    --accent: #4f7cff    --accent2: #7c5cfc
--red: #ff4f6a    --orange: #ff8c42    --green: #3dd68c
--yellow: #ffd166    --text: #e8eaf0    --text2: #8b90a7
--text3: #555a73
--font-head: 'Unbounded'    --font-body: 'Manrope'
--radius: 12px    --radius-sm: 8px
```

**Проблема:** CaseDossier використовує **інший набір кольорів inline**, не звертаючись до CSS-змінних:

| Призначення | App.css | CaseDossier inline |
|-------------|---------|---------------------|
| фон | `--bg #0f1117` | `#0d0f1a` |
| surface | `--surface #191c27` | `#1a1d27` |
| border | `--border #2d3250` | `#2e3148` |
| green | `--green #3dd68c` | `#2ecc71` |
| red | `--red #ff4f6a` | `#e74c3c` |

**Шрифт:** глобально Manrope, але CaseDossier рендериться з `fontFamily: "'Segoe UI',sans-serif"` — обходить Manrope.

**Spacing:** в CaseDossier inline `padding: 6px, 7px, 8px, 10px, 12px` — без узгодженості з токенами.

**Іконки:** виключно emoji. SVG/lucide-react немає (хоча в архітектурних рішеннях зазначено що використовуємо lucide-react).

### Палітра з архітектурних рішень (Блок 1 mockup'ів)

З `dossier_ui_mockups.md` Блок 1 — цільова палітра яку потрібно реалізувати:

```
ОСНОВНА ПАЛІТРА:
#0f1117  фон сторінки
#191c27  фон карток і модалок
#2d3250  бордюри і розділювачі
#a8b3cf  основний текст
#6b7693  другорядний текст
#3b82f6  акцент (посилання, активні стани)
#22c55e  успіх
#f59e0b  попередження
#ef4444  помилка
#e6b450  золотий — для ключових документів (⭐)

КОЛІР ПРОВАДЖЕНЬ:
🟢 #22c55e  Перша інстанція / досудове розслідування
🔵 #3b82f6  Апеляційне провадження
🟡 #eab308  Касаційне провадження
⚪ #6b7693  Інше / без провадження
```

**Розбіжність:** деякі кольори в App.css (`#4f7cff` для accent) відрізняються від цільових з mockup'ів (`#3b82f6`). Обери цільові з mockup'ів — це джерело правди.

### Що з цього випливає

TASK 5 розбивається на 6 підзадач:

- **5.1.** Створити `src/styles/tokens.css` з повною палітрою, типографікою, spacing, радіусами, тінями
- **5.2.** Перевірити що цільова палітра консистентна (єдиний "акцент", єдиний "успіх")
- **5.3.** Базові компоненти: Button, Input, Select, Modal, Card (мінімальний набір для початку — Chip, Toggle, Tabs, Tooltip створимо в TASK 6 окремо)
- **5.4.** Lucide-react установлення і базова обгортка
- **5.5.** Юніт-тести для кожного компонента
- **5.6.** Документація компонентів (storybook-style як коментарі або окремий файл)

---

## TASK 5.1 — `tokens.css`

### Створи директорію і файл

```
src/styles/
└── tokens.css
```

Якщо `src/styles/` ще не існує — створи. У майбутньому туди підуть інші глобальні стилі (animations.css, typography.css і т.д.).

### Структура `tokens.css`

```css
/**
 * Design Tokens для Legal BMS.
 * 
 * Файл — єдине джерело правди для палітри, типографіки, spacing, радіусів і тіней.
 * Усі компоненти і модулі звертаються до цих CSS-змінних, не використовують inline-кольори.
 * 
 * SaaS extension: майбутнє перевизначення палітри для тенанта робиться через
 * додатковий CSS файл який імпортується після tokens.css і перевизначає змінні.
 */

:root {
  /* ============================================================
     ПАЛІТРА
     ============================================================ */
  
  /* Фони і поверхні */
  --color-bg: #0f1117;          /* фон сторінки */
  --color-surface: #191c27;      /* картки, модалки */
  --color-surface-2: #222638;    /* picked-up surface (hover, modal над modal) */
  --color-border: #2d3250;       /* бордюри і розділювачі */
  
  /* Текст */
  --color-text: #e8eaf0;         /* основний текст */
  --color-text-2: #a8b3cf;       /* другорядний (метадані, підрядки) */
  --color-text-3: #6b7693;       /* приглушений (placeholders, disabled) */
  
  /* Акценти і дії */
  --color-accent: #3b82f6;       /* основний акцент (посилання, активні стани) */
  --color-accent-hover: #2563eb; /* hover/active state */
  
  /* Семантичні */
  --color-success: #22c55e;
  --color-warning: #f59e0b;
  --color-danger: #ef4444;
  --color-danger-hover: #dc2626;
  
  /* Особливі */
  --color-gold: #e6b450;         /* ключові документи ⭐ */
  
  /* Кольори проваджень */
  --color-proceeding-first: #22c55e;     /* перша інстанція, досудове */
  --color-proceeding-appeal: #3b82f6;    /* апеляція */
  --color-proceeding-cassation: #eab308; /* касація */
  --color-proceeding-other: #6b7693;     /* інше / без провадження */
  
  /* ============================================================
     ТИПОГРАФІКА
     ============================================================ */
  
  --font-heading: 'Unbounded', system-ui, -apple-system, sans-serif;
  --font-body: 'Manrope', system-ui, -apple-system, sans-serif;
  --font-mono: 'JetBrains Mono', 'SF Mono', Consolas, monospace;
  
  /* Розміри тексту */
  --text-xs: 12px;       /* допоміжний (метадані) */
  --text-sm: 13px;       /* основний інтерфейс */
  --text-base: 14px;     /* контент */
  --text-md: 16px;       /* заголовки секцій */
  --text-lg: 18px;       /* заголовки модалок */
  --text-xl: 22px;       /* заголовки сторінок */
  --text-2xl: 28px;      /* hero */
  
  /* Висота рядка */
  --leading-tight: 1.2;
  --leading-normal: 1.5;
  --leading-relaxed: 1.75;
  
  /* Жирність */
  --weight-regular: 400;
  --weight-medium: 500;
  --weight-semibold: 600;
  --weight-bold: 700;
  
  /* ============================================================
     SPACING
     ============================================================ */
  
  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-5: 20px;
  --space-6: 24px;
  --space-8: 32px;
  --space-10: 40px;
  --space-12: 48px;
  --space-16: 64px;
  
  /* ============================================================
     РАДІУСИ
     ============================================================ */
  
  --radius-xs: 4px;       /* дрібні елементи (chips) */
  --radius-sm: 6px;       /* кнопки, інпути */
  --radius-md: 8px;       /* картки документів */
  --radius-lg: 12px;      /* модалки і великі контейнери */
  --radius-xl: 16px;
  --radius-full: 9999px;  /* pills, avatars */
  
  /* ============================================================
     ТІНІ
     ============================================================ */
  
  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.3);
  --shadow-md: 0 4px 8px rgba(0, 0, 0, 0.4);
  --shadow-lg: 0 12px 24px rgba(0, 0, 0, 0.5);
  --shadow-glow-gold: 0 0 20px rgba(230, 180, 80, 0.3);
  
  /* ============================================================
     TRANSITIONS
     ============================================================ */
  
  --transition-fast: 0.15s ease;
  --transition-base: 0.2s ease;
  --transition-slow: 0.3s ease;
  
  /* ============================================================
     Z-INDEX
     ============================================================ */
  
  --z-dropdown: 100;
  --z-sticky: 200;
  --z-overlay: 800;
  --z-modal: 900;
  --z-toast: 1000;
}

/* ============================================================
   ГЛОБАЛЬНІ СКИДАННЯ І БАЗОВІ ПРАВИЛА
   ============================================================ */

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: var(--font-body);
  font-size: var(--text-base);
  line-height: var(--leading-normal);
  color: var(--color-text);
  background: var(--color-bg);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

h1, h2, h3, h4, h5, h6 {
  font-family: var(--font-heading);
  font-weight: var(--weight-semibold);
  line-height: var(--leading-tight);
  margin: 0;
}

button {
  font-family: inherit;
  cursor: pointer;
}

button:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}
```

### Імпорт у App.jsx або index.html

`tokens.css` має завантажуватись першим. Знайди де завантажується App.css і додай:

```javascript
// src/main.jsx або точка входу
import './styles/tokens.css';
import './App.css';  // вже існує
```

### Не видаляй App.css зараз

App.css містить багато старих стилів (компоненти, layout). НЕ видаляй його в TASK 5. Просто додай tokens.css як шар *перед* App.css. Старі CSS-змінні в App.css можна залишити поки що — вони перевизначаться tokens.css або просто співіснуватимуть.

Очищення App.css і міграція старих компонентів — окремий TASK у Фазі 1.6 (TASK 6 базові компоненти + поступова міграція).

### Критерії приймання TASK 5.1

- `src/styles/tokens.css` створено з повною структурою
- Усі CSS-змінні мають префікс `--color-`, `--text-`, `--space-`, `--radius-`, `--shadow-`, `--font-`, `--z-`, `--transition-` (систематично)
- Файл імпортується в точці входу
- Білд проходить
- На сайті візуально нічого не змінилось (старі стилі досі діють)

---

## TASK 5.2 — Перевірка консистентності палітри

Це не окремий TASK, а **внутрішня перевірка** перед переходом до 5.3.

Звір з `dossier_ui_mockups.md` Блок 1:
- Палітра в tokens.css відповідає mockup'ам?
- Кольори проваджень визначено правильно (4 кольори)?
- Золотий для ключових документів є?

Якщо знайдеш розбіжність між моїм TASK і mockup'ами — пріоритет за mockup'ами (це джерело правди для UI).

Якщо в App.css знайдеш стилі які прив'язані до старих кольорів (наприклад `#4f7cff` для акценту) — НЕ виправляй зараз, це окремий TASK поступової міграції.

---

## TASK 5.3 — Базові UI компоненти

### Створи директорію і файли

```
src/components/UI/
├── Button.jsx
├── Input.jsx
├── Select.jsx
├── Modal.jsx
├── Card.jsx
└── index.js   ← re-export всіх
```

Інші компоненти (Chip, Toggle, Tabs, Tooltip) — окремий TASK 6, не зараз. Зосередимось на 5 базових.

### Button.jsx

```jsx
import './Button.css';

/**
 * Button — універсальна кнопка.
 * 
 * Варіанти:
 * - primary    — основна дія (синій акцент)
 * - secondary  — другорядна дія (прозорий з бордюром)
 * - ghost      — мінімалістична (тільки текст з hover-фоном)
 * - danger     — небезпечна дія (червоний, для видалень)
 * 
 * Розміри:
 * - sm   — компактна (для inline дій, метаданих)
 * - md   — стандартна (default)
 * - lg   — велика (для CTA)
 * 
 * Props:
 * - variant: 'primary' | 'secondary' | 'ghost' | 'danger'
 * - size: 'sm' | 'md' | 'lg'
 * - icon: ReactNode  — іконка ліворуч від тексту
 * - iconRight: ReactNode  — іконка праворуч
 * - loading: boolean  — стан завантаження (показує spinner, блокує клік)
 * - disabled: boolean
 * - fullWidth: boolean
 * - children: текст кнопки
 * - onClick: function
 * - type: 'button' | 'submit'
 */
export function Button({
  variant = 'primary',
  size = 'md',
  icon,
  iconRight,
  loading = false,
  disabled = false,
  fullWidth = false,
  children,
  onClick,
  type = 'button',
  ...rest
}) {
  const className = [
    'ui-button',
    `ui-button--${variant}`,
    `ui-button--${size}`,
    fullWidth && 'ui-button--full',
    loading && 'ui-button--loading'
  ].filter(Boolean).join(' ');
  
  return (
    <button
      type={type}
      className={className}
      disabled={disabled || loading}
      onClick={onClick}
      {...rest}
    >
      {loading && <span className="ui-button__spinner" />}
      {!loading && icon && <span className="ui-button__icon">{icon}</span>}
      <span className="ui-button__label">{children}</span>
      {!loading && iconRight && <span className="ui-button__icon">{iconRight}</span>}
    </button>
  );
}
```

```css
/* Button.css */

.ui-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  border: 1px solid transparent;
  border-radius: var(--radius-sm);
  font-family: var(--font-body);
  font-weight: var(--weight-medium);
  cursor: pointer;
  transition: all var(--transition-fast);
  white-space: nowrap;
  user-select: none;
}

/* Розміри */
.ui-button--sm {
  padding: var(--space-1) var(--space-3);
  font-size: var(--text-xs);
}
.ui-button--md {
  padding: var(--space-2) var(--space-4);
  font-size: var(--text-sm);
}
.ui-button--lg {
  padding: var(--space-3) var(--space-6);
  font-size: var(--text-base);
}

/* Варіанти */
.ui-button--primary {
  background: var(--color-accent);
  color: white;
  border-color: var(--color-accent);
}
.ui-button--primary:hover:not(:disabled) {
  background: var(--color-accent-hover);
  border-color: var(--color-accent-hover);
}

.ui-button--secondary {
  background: transparent;
  color: var(--color-text);
  border-color: var(--color-border);
}
.ui-button--secondary:hover:not(:disabled) {
  background: var(--color-surface-2);
  border-color: var(--color-text-3);
}

.ui-button--ghost {
  background: transparent;
  color: var(--color-text);
  border-color: transparent;
}
.ui-button--ghost:hover:not(:disabled) {
  background: var(--color-surface-2);
}

.ui-button--danger {
  background: var(--color-danger);
  color: white;
  border-color: var(--color-danger);
}
.ui-button--danger:hover:not(:disabled) {
  background: var(--color-danger-hover);
  border-color: var(--color-danger-hover);
}

/* Стани */
.ui-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.ui-button--full {
  width: 100%;
}

.ui-button--loading {
  cursor: wait;
}

.ui-button__icon {
  display: inline-flex;
  align-items: center;
}

.ui-button__spinner {
  width: 14px;
  height: 14px;
  border: 2px solid currentColor;
  border-top-color: transparent;
  border-radius: 50%;
  animation: ui-button-spin 0.6s linear infinite;
}

@keyframes ui-button-spin {
  to { transform: rotate(360deg); }
}
```

### Input.jsx

```jsx
import { useState } from 'react';
import './Input.css';

/**
 * Input — універсальне текстове поле.
 * 
 * Підтримує:
 * - Стандартний text input
 * - Number input
 * - Date input (формат YYYY-MM-DD)
 * - Email
 * - Search (з clear button)
 * - Textarea (через prop multiline)
 * 
 * Props:
 * - type: 'text' | 'number' | 'date' | 'email' | 'search'
 * - value, onChange, placeholder, disabled
 * - label: string  — підпис
 * - error: string  — повідомлення про помилку
 * - hint: string   — підказка під полем
 * - icon: ReactNode  — іконка ліворуч
 * - multiline: boolean  — рендериться як textarea
 * - rows: number  — кількість рядків для textarea
 * - autoFocus: boolean
 */
export function Input({
  type = 'text',
  value,
  onChange,
  placeholder,
  disabled = false,
  label,
  error,
  hint,
  icon,
  multiline = false,
  rows = 4,
  autoFocus = false,
  ...rest
}) {
  const [focused, setFocused] = useState(false);
  
  const wrapperClass = [
    'ui-input',
    focused && 'ui-input--focused',
    error && 'ui-input--error',
    disabled && 'ui-input--disabled'
  ].filter(Boolean).join(' ');
  
  const InputElement = multiline ? 'textarea' : 'input';
  
  return (
    <div className={wrapperClass}>
      {label && <label className="ui-input__label">{label}</label>}
      <div className="ui-input__field">
        {icon && <span className="ui-input__icon">{icon}</span>}
        <InputElement
          type={multiline ? undefined : type}
          rows={multiline ? rows : undefined}
          value={value || ''}
          onChange={(e) => onChange?.(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          placeholder={placeholder}
          disabled={disabled}
          autoFocus={autoFocus}
          className="ui-input__control"
          {...rest}
        />
      </div>
      {error && <div className="ui-input__error">{error}</div>}
      {!error && hint && <div className="ui-input__hint">{hint}</div>}
    </div>
  );
}
```

```css
/* Input.css */

.ui-input {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
}

.ui-input__label {
  font-size: var(--text-xs);
  color: var(--color-text-2);
  font-weight: var(--weight-medium);
}

.ui-input__field {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-2) var(--space-3);
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  transition: border-color var(--transition-fast);
}

.ui-input--focused .ui-input__field {
  border-color: var(--color-accent);
}

.ui-input--error .ui-input__field {
  border-color: var(--color-danger);
}

.ui-input--disabled .ui-input__field {
  opacity: 0.5;
  cursor: not-allowed;
}

.ui-input__icon {
  color: var(--color-text-3);
  display: inline-flex;
  align-items: center;
}

.ui-input__control {
  flex: 1;
  background: transparent;
  border: none;
  outline: none;
  color: var(--color-text);
  font-family: var(--font-body);
  font-size: var(--text-sm);
  resize: vertical;
  min-width: 0;
}

.ui-input__control::placeholder {
  color: var(--color-text-3);
}

.ui-input__control:disabled {
  cursor: not-allowed;
}

.ui-input__error {
  font-size: var(--text-xs);
  color: var(--color-danger);
}

.ui-input__hint {
  font-size: var(--text-xs);
  color: var(--color-text-3);
}
```

### Select.jsx

Реалізуй за тим самим підходом. Native `<select>` обгорнутий у стилізований wrapper.

```jsx
import './Select.css';

/**
 * Select — стандартний select з опціями.
 * 
 * Props:
 * - value, onChange
 * - options: [{ value, label }]
 * - placeholder: string
 * - label, error, hint, disabled — аналогічно Input
 * - searchable: boolean — для майбутнього (поки заглушка)
 */
export function Select({ value, onChange, options, placeholder, label, error, hint, disabled, ...rest }) {
  // ...native select обгорнутий у стилізовану обгортку
}
```

### Modal.jsx

```jsx
import { useEffect } from 'react';
import './Modal.css';

/**
 * Modal — фірмова модалка.
 * 
 * Замінює window.alert/confirm/prompt у системі.
 * Використовується для підтверджень, форм, повідомлень.
 * 
 * Props:
 * - isOpen: boolean
 * - onClose: function
 * - title: string
 * - size: 'sm' | 'md' | 'lg'  — 400/600/900px
 * - children: контент
 * - actions: ReactNode  — нижній ряд кнопок (зазвичай 2-3 Button)
 * - closeOnBackdrop: boolean (default: true)
 * - closeOnEscape: boolean (default: true)
 */
export function Modal({
  isOpen,
  onClose,
  title,
  size = 'md',
  children,
  actions,
  closeOnBackdrop = true,
  closeOnEscape = true
}) {
  // useEffect для escape key
  useEffect(() => {
    if (!isOpen || !closeOnEscape) return;
    const handler = (e) => { if (e.key === 'Escape') onClose?.(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [isOpen, closeOnEscape, onClose]);
  
  if (!isOpen) return null;
  
  return (
    <div 
      className="ui-modal-backdrop" 
      onClick={closeOnBackdrop ? onClose : undefined}
    >
      <div 
        className={`ui-modal ui-modal--${size}`}
        onClick={(e) => e.stopPropagation()}
      >
        {title && (
          <div className="ui-modal__header">
            <h2 className="ui-modal__title">{title}</h2>
            <button 
              className="ui-modal__close" 
              onClick={onClose}
              aria-label="Закрити"
            >×</button>
          </div>
        )}
        <div className="ui-modal__body">
          {children}
        </div>
        {actions && (
          <div className="ui-modal__actions">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
}
```

```css
/* Modal.css */

.ui-modal-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-4);
  z-index: var(--z-modal);
}

.ui-modal {
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-lg);
  max-height: 90vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.ui-modal--sm { width: 400px; max-width: 100%; }
.ui-modal--md { width: 600px; max-width: 100%; }
.ui-modal--lg { width: 900px; max-width: 100%; }

.ui-modal__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--space-4) var(--space-5);
  border-bottom: 1px solid var(--color-border);
}

.ui-modal__title {
  font-size: var(--text-lg);
  font-weight: var(--weight-semibold);
  color: var(--color-text);
}

.ui-modal__close {
  background: transparent;
  border: none;
  color: var(--color-text-2);
  font-size: 24px;
  line-height: 1;
  padding: var(--space-1);
  cursor: pointer;
  border-radius: var(--radius-xs);
  transition: color var(--transition-fast);
}

.ui-modal__close:hover {
  color: var(--color-text);
  background: var(--color-surface-2);
}

.ui-modal__body {
  padding: var(--space-5);
  overflow-y: auto;
  flex: 1;
}

.ui-modal__actions {
  display: flex;
  justify-content: flex-end;
  gap: var(--space-2);
  padding: var(--space-4) var(--space-5);
  border-top: 1px solid var(--color-border);
}
```

### Card.jsx

Простий контейнер з опціональним hover ефектом і бордюром.

```jsx
import './Card.css';

/**
 * Card — універсальний контейнер.
 * 
 * Props:
 * - variant: 'default' | 'interactive' (з hover)
 * - children
 * - onClick — якщо передано і variant interactive — клікабельна
 * - className — додатковий клас
 * - leftBorderColor — кольоровий лівий бордюр (для документів за провадженням)
 */
export function Card({ variant = 'default', children, onClick, className, leftBorderColor, ...rest }) {
  const cls = [
    'ui-card',
    variant === 'interactive' && 'ui-card--interactive',
    className
  ].filter(Boolean).join(' ');
  
  const style = leftBorderColor ? { borderLeftColor: leftBorderColor, borderLeftWidth: '3px' } : undefined;
  
  return (
    <div className={cls} style={style} onClick={onClick} {...rest}>
      {children}
    </div>
  );
}
```

```css
/* Card.css */

.ui-card {
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  padding: var(--space-4);
  transition: all var(--transition-fast);
}

.ui-card--interactive {
  cursor: pointer;
}

.ui-card--interactive:hover {
  background: var(--color-surface-2);
  box-shadow: var(--shadow-md);
}
```

### `src/components/UI/index.js`

```javascript
export { Button } from './Button.jsx';
export { Input } from './Input.jsx';
export { Select } from './Select.jsx';
export { Modal } from './Modal.jsx';
export { Card } from './Card.jsx';
```

Це дозволяє імпортувати компоненти красиво:

```javascript
import { Button, Modal } from '../UI';
```

### Критерії приймання TASK 5.3

- 5 компонентів створено з повною реалізацією і CSS
- Усі використовують CSS-змінні з tokens.css (НЕ inline-кольори, НЕ хардкод pixels)
- Re-export через index.js
- Білд проходить
- Існуючий функціонал не зламано

---

## TASK 5.4 — Lucide-react установлення

### Установіть пакет

```bash
npm install lucide-react
```

### Створи обгортку (опціонально)

Можна використовувати lucide-react напряму:

```jsx
import { ChevronDown, X, Check } from 'lucide-react';

<Button icon={<ChevronDown size={16} />}>Розкрити</Button>
```

Або зробити мінімальну обгортку для уніфікації розмірів:

```javascript
// src/components/UI/icons.js
export { 
  ChevronDown, ChevronUp, ChevronLeft, ChevronRight,
  X, Check, Plus, Minus,
  Search, Filter,
  Edit, Trash2, Copy, Share2,
  Calendar, Clock, MapPin,
  FileText, Folder, Upload, Download,
  AlertTriangle, AlertCircle, Info, CheckCircle
} from 'lucide-react';

// Стандартні розміри
export const ICON_SIZE = {
  xs: 12,
  sm: 14,
  md: 16,
  lg: 20,
  xl: 24
};
```

### Не міняй emoji в існуючому коді зараз

В існуючому CaseDossier багато emoji-іконок. НЕ замінюй їх у TASK 5 — це окремий TASK поступової міграції в Фазі 1.6 (паралельно з міграцією компонентів). Зараз lucide-react установлено і доступний, новий код може його використовувати.

### Критерії приймання TASK 5.4

- lucide-react у package.json
- icons.js з re-export'ом готовий
- Існуючий код не змінюється

---

## TASK 5.5 — Юніт-тести

Усі тести в `tests/unit/` — слідуй структурі з TASK 4.

### `tests/unit/Button.test.jsx`

```javascript
import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { Button } from '../../src/components/UI/Button.jsx';

describe('Button', () => {
  it('renders text content', () => {
    render(<Button>Click me</Button>);
    expect(screen.getByText('Click me')).toBeInTheDocument();
  });
  
  it('calls onClick when clicked', () => {
    const handleClick = vi.fn();
    render(<Button onClick={handleClick}>Click</Button>);
    fireEvent.click(screen.getByText('Click'));
    expect(handleClick).toHaveBeenCalledOnce();
  });
  
  it('does not call onClick when disabled', () => {
    const handleClick = vi.fn();
    render(<Button disabled onClick={handleClick}>Click</Button>);
    fireEvent.click(screen.getByText('Click'));
    expect(handleClick).not.toHaveBeenCalled();
  });
  
  it('does not call onClick when loading', () => {
    const handleClick = vi.fn();
    render(<Button loading onClick={handleClick}>Click</Button>);
    fireEvent.click(screen.getByText('Click'));
    expect(handleClick).not.toHaveBeenCalled();
  });
  
  it('applies variant class', () => {
    const { container } = render(<Button variant="danger">Delete</Button>);
    expect(container.querySelector('.ui-button--danger')).toBeInTheDocument();
  });
  
  it('applies size class', () => {
    const { container } = render(<Button size="lg">Big</Button>);
    expect(container.querySelector('.ui-button--lg')).toBeInTheDocument();
  });
});
```

### Аналогічно для Input, Select, Modal, Card

5 тест-файлів. Покривай:
- Базовий рендеринг
- Передачу props
- Обробка подій (onClick, onChange)
- Стани (disabled, error, loading)
- Edge cases де релевантно

### Установлення React Testing Library

Якщо ще не встановлено:

```bash
npm install --save-dev @testing-library/react @testing-library/jest-dom jsdom
```

### Оновити `vitest.config.js`

Додай jsdom environment для тестів які рендерять React:

```javascript
export default defineConfig({
  test: {
    globals: true,
    environment: 'node',  // дефолт — node
    environmentMatchGlobs: [
      ['tests/unit/**/*.test.jsx', 'jsdom']  // jsdom для UI компонентів
    ],
    // ...
  }
});
```

Або зробити окрему конфігурацію — на твій смак.

### Критерії приймання TASK 5.5

- 5 файлів тестів (Button, Input, Select, Modal, Card)
- Кожен містить мінімум 5-7 тестів
- `npm test` проходить (включно з новими тестами)
- jsdom environment працює для .jsx тестів

---

## TASK 5.6 — Документація компонентів

### Створи файл `src/components/UI/README.md`

```markdown
# UI Components

Базові універсальні компоненти Legal BMS. Використовуються у всіх модулях.

## Імпорт

```javascript
import { Button, Input, Modal } from '@/components/UI';
```

## Доступні компоненти

### Button

Універсальна кнопка з 4 варіантами і 3 розмірами.

**Props:**
- `variant`: 'primary' | 'secondary' | 'ghost' | 'danger'
- `size`: 'sm' | 'md' | 'lg'
- `icon`, `iconRight`: ReactNode
- `loading`: boolean
- `disabled`: boolean
- `fullWidth`: boolean
- `onClick`: function
- `type`: 'button' | 'submit'

**Приклад:**
```jsx
<Button variant="primary" onClick={handleSave}>
  Зберегти
</Button>

<Button variant="danger" icon={<Trash2 size={14} />}>
  Видалити
</Button>
```

### Input

[аналогічний опис]

### Select

[аналогічний опис]

### Modal

[аналогічний опис]

### Card

[аналогічний опис]

## Принципи

1. Усі компоненти використовують CSS-змінні з `src/styles/tokens.css`
2. НЕ використовуй inline-стилі поверх компонентів — додавай новий проп якщо потрібен новий вигляд
3. Тести обов'язкові для кожного компонента
4. SaaS-готовність: палітру можна перевизначити через додатковий tokens-override.css
```

### Критерії приймання TASK 5.6

- README.md створено з документацією
- Кожен компонент описано з props і прикладами
- Принципи зафіксовано

---

## SAAS IMPLICATIONS

Tokens.css спроектовано так щоб у майбутньому можна було:
- Перевизначити кольори для тенанта (фірмова палітра бюро)
- Додати темну/світлу теми (зараз тільки темна)
- Додати локалізовані шрифти для мов з нелатинським алфавітом

Спосіб перевизначення — додатковий CSS файл який імпортується ПІСЛЯ tokens.css і перевизначає змінні. Без перекомпіляції коду.

---

## BILLING IMPLICATIONS

Не зачіпає білінг прямо. Опосередковано: красивий і консистентний UI = краща UX = більше клієнтів = більший виторг (для майбутнього SaaS).

---

## КОМІТ І ПУШ

```bash
git commit -m "feat: TASK 5 — Design tokens (tokens.css) + 5 base UI components (Button, Input, Select, Modal, Card) + lucide-react + tests"
git push origin main
```

GitHub Actions запустить тести → якщо зелено → деплой.

---

## ОЧІКУВАНІ АРТЕФАКТИ ВИКОНАННЯ

Створи файл звіту `report_task5.md` у корені репо.

### Структура звіту

**Резюме TASK 5** — один абзац

**Реалізація з TASK** — таблиця підзадач 5.1-5.6

**Створені файли** — таблиця з призначенням
- src/styles/tokens.css
- src/components/UI/Button.jsx + Button.css
- src/components/UI/Input.jsx + Input.css
- src/components/UI/Select.jsx + Select.css
- src/components/UI/Modal.jsx + Modal.css
- src/components/UI/Card.jsx + Card.css
- src/components/UI/index.js
- src/components/UI/icons.js
- src/components/UI/README.md
- 5 файлів тестів у tests/unit/

**Змінені файли** — package.json, main.jsx (імпорт tokens.css), vitest.config.js (jsdom)

**Відхилення від TASK** — якщо щось зробив інакше

**Знахідки** — якщо створив discovered_issues_during_task5.md

**Тести** — кількість, час виконання

**Білд + push**

### Пояснення в термінал для адвоката

Стиль як родичу що пояснюєш роботу. Без термінів "CSS-змінна", "компонент", "JSX". Адвокат хоче зрозуміти результат і вплив.

Приклад тону:

> Я створив базу для нової візуальної системи. Раніше у нас кольори і розміри були розкидані по всьому коду — місцями один синій, місцями інший, шрифти теж різні. Тепер є одне місце де записано "ось такі кольори, такий шрифт, такі розміри" — і весь код буде брати з цього єдиного джерела.
>
> Що з цього зроблено зараз:
> - Готовий "довідник стилів" (tokens.css) — палітра, шрифти, відступи, заокруглення
> - 5 базових елементів інтерфейсу (кнопки, поля вводу, списки, модальні вікна, картки) — у фірмовому стилі. Раніше у досьє кнопки робились по-різному — тепер можна використовувати готові
> - Бібліотека сучасних іконок (raніше були emoji)
>
> На сайті візуально ще нічого не змінилось — це фундамент. Поступово в наступних TASK ми будемо переписувати інтерфейс досьє на ці нові елементи, і ти побачиш зміни.
>
> Тести: N зелених, прогон Y секунд.
>
> Деталі — у `report_task5.md`.

---

## ВЛАСНА АНАЛІТИКА І ТВОРЧЕ ВИКОНАННЯ

Це фундамент UI на роки. Якщо в процесі виявиш:

- Старі стилі в App.css конфліктують з новими токенами → НЕ виправляй зараз, фіксуй у `discovered_issues_during_task5.md` для наступного TASK поступової міграції
- Потрібен ще якийсь токен якого немає в моєму TASK → додай, поясни в коментарі
- React Testing Library не встановлено правильно → налаштуй коректно з jsdom environment
- Знайдеш кращий спосіб організації CSS (наприклад через CSS Modules) → не змінюй, дотримуйся плану. Це окрема велика тема.

**Критерій якості:** інший розробник через 6 місяців відкриває tokens.css і одразу розуміє палітру. Відкриває Button.jsx і за 2 хвилини знає всі його варіанти. Простота і ясність.

Не вважай TASK дзвоном з небес. Адаптуйся.

---

**Кінець TASK 5.**
