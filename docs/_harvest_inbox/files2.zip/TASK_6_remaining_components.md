# TASK 6 — Решта базових UI компонентів (Chip, Toggle, Tabs, Tooltip)

**Дата формування:** 08.05.2026
**Фаза:** 1.6 — UI Reform (другий TASK)
**Виконавець:** Claude Code (Opus 4.7, 1M context)
**Орієнтовний обсяг:** 4-6 годин
**Передумови:** TASK 1-5 завершені і закомічені

---

## ПРИНЦИПИ ВИКОНАННЯ

**Творчо, виважено, охайно.** Це продовження TASK 5 — додаємо решту базових компонентів які знадобляться для повноцінної міграції CaseDossier і інших модулів. Дотримуйся тієї самої якості коду, тієї самої структури, тих самих принципів іменування.

**Перевіряй перед змінами.** TASK 5 створив структуру `src/components/UI/` з `Button`, `Input`, `Select`, `Modal`, `Card`. Подивись як вона організована, дотримуйся того ж підходу.

**Тести разом з кодом.** Кожен новий компонент — тест у `tests/unit/<Component>.test.jsx` з jsdom environment.

**SaaS-готовність.** Компоненти параметризовані через props, без хардкоду тенант-специфічних значень.

**Без тимчасових рішень.** Якщо щось можна зробити нормально зараз — зроби нормально.

---

## КОНТЕКСТ

### Стан після TASK 5

В `src/components/UI/` уже є:
- `Button.jsx` + `Button.css` — універсальна кнопка (4 варіанти, 3 розміри, loading, icon)
- `Input.jsx` + `Input.css` — поле введення (text/number/date/email/search) з multiline
- `Select.jsx` + `Select.css` — dropdown з опціями
- `Modal.jsx` + `Modal.css` — модалка (3 розміри, escape, backdrop)
- `Card.jsx` + `Card.css` — контейнер з leftBorderColor для проваджень
- `index.js` — barrel export
- `icons.js` — lucide-react re-export з ICON_SIZE
- `README.md` — документація

Усе будується на CSS-змінних з `src/styles/tokens.css`. Жодних inline-кольорів.

### Що залишилось додати (з оригінального плану Фази 1.6)

З `dossier_ui_mockups.md` Блок 1 — повний список базових компонентів:
> Button, Input, Select, **Chip**, Card, Modal, **Tabs**, **Toggle**, **Tooltip**

Перші 5 у TASK 5. Решта 4 (Chip, Toggle, Tabs, Tooltip) — у цьому TASK.

### Де ці компоненти знадобляться

- **Chip** — для тегів документів, фільтрів, маркерів проваджень. Активно використовується в Реєстрі Матеріалів, фільтрах справ.
- **Toggle** — для перемикачів увімк/вимк. Сім перемикачів в DocumentProcessor, налаштування агента, опції в модалках.
- **Tabs** — горизонтальні вкладки (Огляд / Матеріали / Робота з документами / Канва), Дерево/Реєстр перемикач.
- **Tooltip** — підказки на hover (метадані документа, пояснення кнопок, контекст ⚠).

### Що з цього випливає

TASK 6 розбивається на 5 підзадач:

- **6.1** — Chip компонент
- **6.2** — Toggle компонент
- **6.3** — Tabs компонент
- **6.4** — Tooltip компонент
- **6.5** — Тести і оновлення документації

---

## TASK 6.1 — Chip

### Призначення

Невеликий компактний елемент для відображення тегів, статусів, фільтрів. Може бути клікабельним (interactive) або статичним.

### Файли

- `src/components/UI/Chip.jsx`
- `src/components/UI/Chip.css`

### Реалізація

```jsx
import './Chip.css';
import { X } from 'lucide-react';

/**
 * Chip — компактний елемент для тегів, фільтрів, статусів.
 * 
 * Варіанти:
 * - default     — нейтральний (для тегів документів)
 * - accent      — акцентний синій (для активних фільтрів)
 * - success     — зелений (статус "active")
 * - warning     — помаранчевий (попередження)
 * - danger      — червоний (помилки)
 * - proceeding  — для проваджень (колір передається через `color` prop)
 * 
 * Розміри:
 * - sm  — компактний (default)
 * - md  — середній
 * 
 * Props:
 * - variant: 'default' | 'accent' | 'success' | 'warning' | 'danger' | 'proceeding'
 * - size: 'sm' | 'md'
 * - color: string  — для variant='proceeding' (CSS-змінна або hex)
 * - removable: boolean  — показує × кнопку
 * - onRemove: function  — обробник кліку по ×
 * - onClick: function   — клік по самому chip (interactive)
 * - icon: ReactNode     — іконка зліва
 * - children: текст
 */
export function Chip({
  variant = 'default',
  size = 'sm',
  color,
  removable = false,
  onRemove,
  onClick,
  icon,
  children,
  ...rest
}) {
  const className = [
    'ui-chip',
    `ui-chip--${variant}`,
    `ui-chip--${size}`,
    onClick && 'ui-chip--clickable'
  ].filter(Boolean).join(' ');
  
  const style = variant === 'proceeding' && color 
    ? { '--chip-color': color }
    : undefined;
  
  return (
    <span 
      className={className} 
      style={style}
      onClick={onClick}
      {...rest}
    >
      {icon && <span className="ui-chip__icon">{icon}</span>}
      <span className="ui-chip__label">{children}</span>
      {removable && (
        <button
          className="ui-chip__remove"
          onClick={(e) => {
            e.stopPropagation();
            onRemove?.();
          }}
          aria-label="Видалити"
        >
          <X size={12} />
        </button>
      )}
    </span>
  );
}
```

```css
/* Chip.css */

.ui-chip {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  border-radius: var(--radius-xs);
  font-family: var(--font-body);
  font-weight: var(--weight-medium);
  white-space: nowrap;
  user-select: none;
  transition: all var(--transition-fast);
}

/* Розміри */
.ui-chip--sm {
  padding: 2px var(--space-2);
  font-size: var(--text-xs);
  height: 22px;
}
.ui-chip--md {
  padding: var(--space-1) var(--space-3);
  font-size: var(--text-sm);
  height: 28px;
}

/* Варіанти */
.ui-chip--default {
  background: var(--color-surface-2);
  color: var(--color-text-2);
  border: 1px solid var(--color-border);
}
.ui-chip--accent {
  background: rgba(59, 130, 246, 0.15);
  color: var(--color-accent);
  border: 1px solid var(--color-accent);
}
.ui-chip--success {
  background: rgba(34, 197, 94, 0.15);
  color: var(--color-success);
  border: 1px solid var(--color-success);
}
.ui-chip--warning {
  background: rgba(245, 158, 11, 0.15);
  color: var(--color-warning);
  border: 1px solid var(--color-warning);
}
.ui-chip--danger {
  background: rgba(239, 68, 68, 0.15);
  color: var(--color-danger);
  border: 1px solid var(--color-danger);
}
.ui-chip--proceeding {
  background: color-mix(in srgb, var(--chip-color) 15%, transparent);
  color: var(--chip-color);
  border: 1px solid var(--chip-color);
}

/* Стани */
.ui-chip--clickable {
  cursor: pointer;
}
.ui-chip--clickable:hover {
  filter: brightness(1.2);
}

.ui-chip__icon {
  display: inline-flex;
  align-items: center;
}

.ui-chip__label {
  line-height: 1;
}

.ui-chip__remove {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  border: none;
  color: inherit;
  cursor: pointer;
  padding: 0;
  margin-left: var(--space-1);
  border-radius: var(--radius-xs);
  opacity: 0.7;
  transition: opacity var(--transition-fast);
}
.ui-chip__remove:hover {
  opacity: 1;
}
```

### Критерії приймання TASK 6.1

- Chip.jsx + Chip.css створено
- 6 варіантів працюють
- 2 розміри
- removable з коректним stopPropagation
- proceeding варіант приймає color prop і застосовує через CSS-змінну

---

## TASK 6.2 — Toggle

### Призначення

Перемикач увімк/вимк (switch). Використовується для опцій, налаштувань, перемикачів в DP.

### Файли

- `src/components/UI/Toggle.jsx`
- `src/components/UI/Toggle.css`

### Реалізація

```jsx
import './Toggle.css';

/**
 * Toggle — перемикач увімк/вимк (switch).
 * 
 * Props:
 * - checked: boolean
 * - onChange: function(newValue: boolean)
 * - disabled: boolean
 * - label: string  — текст ліворуч від перемикача
 * - description: string  — додатковий опис під label (для опцій)
 * - size: 'sm' | 'md'  — компактний / стандартний
 */
export function Toggle({
  checked = false,
  onChange,
  disabled = false,
  label,
  description,
  size = 'md',
  ...rest
}) {
  const handleClick = () => {
    if (!disabled) onChange?.(!checked);
  };
  
  const className = [
    'ui-toggle',
    `ui-toggle--${size}`,
    checked && 'ui-toggle--checked',
    disabled && 'ui-toggle--disabled'
  ].filter(Boolean).join(' ');
  
  return (
    <label className={className} {...rest}>
      <span className="ui-toggle__control">
        <input
          type="checkbox"
          checked={checked}
          onChange={() => onChange?.(!checked)}
          disabled={disabled}
          className="ui-toggle__input"
        />
        <span className="ui-toggle__track">
          <span className="ui-toggle__thumb" />
        </span>
      </span>
      {(label || description) && (
        <span className="ui-toggle__text">
          {label && <span className="ui-toggle__label">{label}</span>}
          {description && <span className="ui-toggle__description">{description}</span>}
        </span>
      )}
    </label>
  );
}
```

```css
/* Toggle.css */

.ui-toggle {
  display: inline-flex;
  align-items: center;
  gap: var(--space-3);
  cursor: pointer;
  user-select: none;
}

.ui-toggle--disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.ui-toggle__control {
  position: relative;
  display: inline-flex;
  align-items: center;
}

.ui-toggle__input {
  opacity: 0;
  position: absolute;
  pointer-events: none;
}

.ui-toggle__track {
  background: var(--color-border);
  border-radius: var(--radius-full);
  position: relative;
  transition: background var(--transition-fast);
}

.ui-toggle--sm .ui-toggle__track {
  width: 32px;
  height: 18px;
}
.ui-toggle--md .ui-toggle__track {
  width: 40px;
  height: 22px;
}

.ui-toggle__thumb {
  background: white;
  border-radius: 50%;
  position: absolute;
  top: 2px;
  left: 2px;
  transition: transform var(--transition-fast);
  box-shadow: var(--shadow-sm);
}

.ui-toggle--sm .ui-toggle__thumb {
  width: 14px;
  height: 14px;
}
.ui-toggle--md .ui-toggle__thumb {
  width: 18px;
  height: 18px;
}

.ui-toggle--checked .ui-toggle__track {
  background: var(--color-accent);
}

.ui-toggle--sm.ui-toggle--checked .ui-toggle__thumb {
  transform: translateX(14px);
}
.ui-toggle--md.ui-toggle--checked .ui-toggle__thumb {
  transform: translateX(18px);
}

.ui-toggle__text {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.ui-toggle__label {
  font-size: var(--text-sm);
  color: var(--color-text);
  font-weight: var(--weight-medium);
}

.ui-toggle__description {
  font-size: var(--text-xs);
  color: var(--color-text-3);
}
```

### Критерії приймання TASK 6.2

- Toggle.jsx + Toggle.css створено
- Двостанний перемикач працює
- onChange отримує новий boolean
- 2 розміри
- label + description працюють
- disabled блокує клік

---

## TASK 6.3 — Tabs

### Призначення

Горизонтальні вкладки. Використовується в шапці модуля Досьє (Огляд / Матеріали / Робота з документами / Канва), у перемикачах режимів (Реєстр / Дерево).

### Файли

- `src/components/UI/Tabs.jsx`
- `src/components/UI/Tabs.css`

### Реалізація

```jsx
import './Tabs.css';

/**
 * Tabs — горизонтальні вкладки.
 * 
 * Контрольований компонент — батько передає activeId і onChange.
 * 
 * Props:
 * - tabs: [{ id, label, icon?, badge?, disabled? }]
 *   - id: унікальний ідентифікатор
 *   - label: текст вкладки
 *   - icon: ReactNode (опціонально)
 *   - badge: string | number (опціональний бейдж, наприклад "(24) ⚠3")
 *   - disabled: boolean
 * - activeId: string  — id активної вкладки
 * - onChange: function(newId: string)
 * - variant: 'default' | 'pills'  — підкреслення / pill
 * - fullWidth: boolean  — вкладки заповнюють контейнер на повну ширину
 */
export function Tabs({
  tabs = [],
  activeId,
  onChange,
  variant = 'default',
  fullWidth = false,
  ...rest
}) {
  const className = [
    'ui-tabs',
    `ui-tabs--${variant}`,
    fullWidth && 'ui-tabs--full'
  ].filter(Boolean).join(' ');
  
  return (
    <div className={className} role="tablist" {...rest}>
      {tabs.map(tab => (
        <button
          key={tab.id}
          role="tab"
          aria-selected={tab.id === activeId}
          className={[
            'ui-tabs__tab',
            tab.id === activeId && 'ui-tabs__tab--active',
            tab.disabled && 'ui-tabs__tab--disabled'
          ].filter(Boolean).join(' ')}
          disabled={tab.disabled}
          onClick={() => !tab.disabled && onChange?.(tab.id)}
        >
          {tab.icon && <span className="ui-tabs__icon">{tab.icon}</span>}
          <span className="ui-tabs__label">{tab.label}</span>
          {tab.badge != null && (
            <span className="ui-tabs__badge">{tab.badge}</span>
          )}
        </button>
      ))}
    </div>
  );
}
```

```css
/* Tabs.css */

.ui-tabs {
  display: inline-flex;
  gap: var(--space-1);
  border-bottom: 1px solid var(--color-border);
}

.ui-tabs--full {
  display: flex;
  width: 100%;
}

.ui-tabs--full .ui-tabs__tab {
  flex: 1;
}

.ui-tabs__tab {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-3) var(--space-4);
  background: transparent;
  border: none;
  color: var(--color-text-2);
  font-family: var(--font-body);
  font-size: var(--text-sm);
  font-weight: var(--weight-medium);
  cursor: pointer;
  position: relative;
  transition: color var(--transition-fast);
  white-space: nowrap;
}

.ui-tabs__tab:hover:not(:disabled) {
  color: var(--color-text);
}

/* Default variant — підкреслення */
.ui-tabs--default .ui-tabs__tab--active {
  color: var(--color-accent);
}

.ui-tabs--default .ui-tabs__tab--active::after {
  content: '';
  position: absolute;
  bottom: -1px;
  left: 0;
  right: 0;
  height: 2px;
  background: var(--color-accent);
}

/* Pills variant */
.ui-tabs--pills {
  border-bottom: none;
  background: var(--color-surface);
  border-radius: var(--radius-md);
  padding: 4px;
}

.ui-tabs--pills .ui-tabs__tab {
  border-radius: var(--radius-sm);
}

.ui-tabs--pills .ui-tabs__tab--active {
  background: var(--color-surface-2);
  color: var(--color-text);
}

/* Стани */
.ui-tabs__tab--disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.ui-tabs__icon {
  display: inline-flex;
  align-items: center;
}

.ui-tabs__badge {
  display: inline-flex;
  align-items: center;
  padding: 0 var(--space-1);
  background: var(--color-surface-2);
  border-radius: var(--radius-xs);
  font-size: var(--text-xs);
  font-weight: var(--weight-semibold);
  min-width: 20px;
  height: 18px;
  justify-content: center;
}
```

### Критерії приймання TASK 6.3

- Tabs.jsx + Tabs.css створено
- 2 варіанти (default, pills)
- Підтримка icon + badge
- Контрольований компонент (activeId, onChange)
- aria-selected для accessibility
- disabled працює

---

## TASK 6.4 — Tooltip

### Призначення

Підказка при hover. Використовується для пояснення кнопок, метаданих документів, контексту маркерів ⚠.

### Файли

- `src/components/UI/Tooltip.jsx`
- `src/components/UI/Tooltip.css`

### Реалізація

```jsx
import { useState, useRef, useEffect } from 'react';
import './Tooltip.css';

/**
 * Tooltip — підказка при hover.
 * 
 * Wrapper-компонент: обгортає дочірній елемент і показує tooltip при hover/focus.
 * 
 * Props:
 * - content: string | ReactNode  — текст підказки
 * - placement: 'top' | 'right' | 'bottom' | 'left'  — позиція (default 'top')
 * - delay: number  — затримка перед показом у ms (default 500)
 * - children: тригер-елемент
 * - disabled: boolean  — не показувати tooltip
 */
export function Tooltip({
  content,
  placement = 'top',
  delay = 500,
  children,
  disabled = false
}) {
  const [visible, setVisible] = useState(false);
  const timerRef = useRef(null);
  
  const show = () => {
    if (disabled || !content) return;
    timerRef.current = setTimeout(() => setVisible(true), delay);
  };
  
  const hide = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    setVisible(false);
  };
  
  useEffect(() => () => {
    if (timerRef.current) clearTimeout(timerRef.current);
  }, []);
  
  return (
    <span 
      className="ui-tooltip-wrapper"
      onMouseEnter={show}
      onMouseLeave={hide}
      onFocus={show}
      onBlur={hide}
    >
      {children}
      {visible && content && (
        <span className={`ui-tooltip ui-tooltip--${placement}`} role="tooltip">
          {content}
        </span>
      )}
    </span>
  );
}
```

```css
/* Tooltip.css */

.ui-tooltip-wrapper {
  position: relative;
  display: inline-flex;
}

.ui-tooltip {
  position: absolute;
  z-index: var(--z-overlay);
  background: var(--color-surface-2);
  color: var(--color-text);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  padding: var(--space-2) var(--space-3);
  font-size: var(--text-xs);
  font-weight: var(--weight-regular);
  line-height: var(--leading-normal);
  white-space: nowrap;
  max-width: 280px;
  white-space: normal;
  box-shadow: var(--shadow-md);
  pointer-events: none;
  animation: ui-tooltip-fade-in 0.15s ease;
}

@keyframes ui-tooltip-fade-in {
  from { opacity: 0; transform: translateY(2px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Позиції */
.ui-tooltip--top {
  bottom: calc(100% + 6px);
  left: 50%;
  transform: translateX(-50%);
}

.ui-tooltip--bottom {
  top: calc(100% + 6px);
  left: 50%;
  transform: translateX(-50%);
}

.ui-tooltip--right {
  left: calc(100% + 6px);
  top: 50%;
  transform: translateY(-50%);
}

.ui-tooltip--left {
  right: calc(100% + 6px);
  top: 50%;
  transform: translateY(-50%);
}
```

### Критерії приймання TASK 6.4

- Tooltip.jsx + Tooltip.css створено
- Працює на hover і focus
- 4 позиції (top/right/bottom/left)
- Затримка перед показом
- Cleanup timerа при unmount

---

## TASK 6.5 — Тести і документація

### Тести

Створи 4 файли тестів за тим самим патерном що TASK 5:

**`tests/unit/Chip.test.jsx`**
```javascript
// @vitest-environment jsdom
import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { Chip } from '../../src/components/UI/Chip.jsx';

describe('Chip', () => {
  it('renders text content', () => {
    render(<Chip>Tag</Chip>);
    expect(screen.getByText('Tag')).toBeInTheDocument();
  });
  
  it('applies variant class', () => {
    const { container } = render(<Chip variant="success">OK</Chip>);
    expect(container.querySelector('.ui-chip--success')).toBeInTheDocument();
  });
  
  it('shows remove button when removable', () => {
    render(<Chip removable onRemove={() => {}}>Tag</Chip>);
    expect(screen.getByLabelText('Видалити')).toBeInTheDocument();
  });
  
  it('calls onRemove when × clicked', () => {
    const handleRemove = vi.fn();
    render(<Chip removable onRemove={handleRemove}>Tag</Chip>);
    fireEvent.click(screen.getByLabelText('Видалити'));
    expect(handleRemove).toHaveBeenCalledOnce();
  });
  
  it('stopPropagation on remove click', () => {
    const handleClick = vi.fn();
    const handleRemove = vi.fn();
    render(<Chip onClick={handleClick} removable onRemove={handleRemove}>Tag</Chip>);
    fireEvent.click(screen.getByLabelText('Видалити'));
    expect(handleRemove).toHaveBeenCalled();
    expect(handleClick).not.toHaveBeenCalled();
  });
  
  it('proceeding variant applies color via style', () => {
    const { container } = render(<Chip variant="proceeding" color="#22c55e">Перша</Chip>);
    const chip = container.querySelector('.ui-chip--proceeding');
    expect(chip.style.getPropertyValue('--chip-color')).toBe('#22c55e');
  });
});
```

**`tests/unit/Toggle.test.jsx`**
- renders label
- calls onChange with !checked
- does not change when disabled
- shows description when provided
- size variants render

**`tests/unit/Tabs.test.jsx`**
- renders all tabs
- shows badge if provided
- calls onChange when tab clicked
- aria-selected on active tab
- disabled tab not clickable
- pills variant applies different class

**`tests/unit/Tooltip.test.jsx`**
- shows content on mouse enter (after delay)
- hides on mouse leave
- placement class applied
- disabled does not show
- cleanup timer on unmount (no warnings)

Кожен файл — мінімум 5-7 тестів.

### Оновити index.js

```javascript
// src/components/UI/index.js
export { Button } from './Button.jsx';
export { Input } from './Input.jsx';
export { Select } from './Select.jsx';
export { Modal } from './Modal.jsx';
export { Card } from './Card.jsx';
export { Chip } from './Chip.jsx';
export { Toggle } from './Toggle.jsx';
export { Tabs } from './Tabs.jsx';
export { Tooltip } from './Tooltip.jsx';
```

### Оновити README.md

Додай секції для нових компонентів (Chip, Toggle, Tabs, Tooltip) з prop-таблицями і прикладами в тому самому стилі що для перших 5.

### Критерії приймання TASK 6.5

- 4 файли тестів створено
- Усі тести зелені (`npm test`)
- index.js оновлено
- README.md має документацію всіх 9 компонентів
- Білд чистий

---

## SAAS IMPLICATIONS

Усі нові компоненти параметризовані через props без хардкоду тенант-специфічних значень. Кольори через CSS-змінні з tokens.css — у майбутньому темізація працює автоматично.

---

## BILLING IMPLICATIONS

Не зачіпає білінг прямо.

---

## КОМІТ І ПУШ

```bash
git commit -m "feat: TASK 6 — remaining base UI components (Chip, Toggle, Tabs, Tooltip) + 25+ new tests"
git push origin main
```

GitHub Actions запустить тести → якщо зелено → деплой.

---

## ОЧІКУВАНІ АРТЕФАКТИ ВИКОНАННЯ

Створи файл звіту `report_task6.md` у корені репо.

### Структура звіту

**Резюме TASK 6** — один абзац

**Реалізація з TASK** — таблиця підзадач 6.1-6.5

**Створені файли** — таблиця:
- src/components/UI/Chip.jsx + Chip.css
- src/components/UI/Toggle.jsx + Toggle.css
- src/components/UI/Tabs.jsx + Tabs.css
- src/components/UI/Tooltip.jsx + Tooltip.css
- 4 файли тестів

**Змінені файли** — index.js, README.md

**Тести** — кількість, час виконання

**Білд + push**

### Пояснення в термінал для адвоката

Стиль як родичу. Без термінів типу "props", "JSX", "компонент". Адвокат хоче зрозуміти результат і вплив.

Приклад тону:

> Я доробив решту базових елементів інтерфейсу які знадобляться для повноцінного оновлення досьє. Тепер у нас повний набір "будівельних блоків": кнопки, поля вводу, списки, модальні вікна, картки (з минулого разу) і тепер ще:
>
> - **Чіпси** (chip) — маленькі позначки тегів і фільтрів. Будуть використовуватись для відображення категорій документів, активних фільтрів у Реєстрі, кольорових позначок проваджень.
> - **Перемикачі** (toggle) — для увімкнення/вимкнення опцій. У документ-процесорі буде сім таких перемикачів які ти вмикаєш на свій смак.
> - **Вкладки** (tabs) — для перемикання між Оглядом / Матеріалами / Роботою з документами / Канвою у досьє.
> - **Підказки** (tooltip) — текст при наведенні на елемент. Допоможе пояснити що означає маркер ⚠, які метадані у документа і таке інше.
>
> На сайті візуально ще нічого не змінилось — це фундамент. Тепер коли всі базові блоки готові, у наступних TASK будемо переписувати конкретні шматки досьє.
>
> Тести: N зелених. Прогон Y секунд.
>
> Деталі — у `report_task6.md`.

---

## ВЛАСНА АНАЛІТИКА І ТВОРЧЕ ВИКОНАННЯ

Якщо в процесі виявиш:
- Потрібен ще якийсь компонент якого немає в моєму TASK → НЕ додавай зараз, фіксуй у `discovered_issues_during_task6.md`. Базовий набір — Button, Input, Select, Modal, Card, Chip, Toggle, Tabs, Tooltip. Все інше — спеціалізовані.
- Tooltip потребує бібліотеки positioning (як floating-ui) для складних кейсів → не додавай, проста CSS-позиція достатньо для початку. Якщо потім захочемо складнішу логіку — окремий TASK.
- Знайдеш кращий спосіб організації CSS → не змінюй, дотримуйся структури з TASK 5 для консистентності.

**Критерій якості:** інший розробник через 6 місяців відкриває Chip.jsx і за 1-2 хвилини розуміє всі його варіанти. Простота і ясність.

Не вважай TASK дзвоном з небес. Адаптуйся.

---

**Кінець TASK 6.**
