# TASK 1 — Канонічна схема документа + createDocument() + documents_extended + міграція v4→v5

**Дата формування:** 08.05.2026
**Фаза:** 1.5 (Канон даних і ACTIONS) — перший TASK
**Виконавець:** Claude Code (Opus 4.6, 1M context)
**Орієнтовний обсяг:** 8-12 годин

---

## ПРИНЦИПИ ВИКОНАННЯ

**Творчо і виважено.** Цей TASK описує цільовий стан і дає орієнтовні точки в коді. Реальні шляхи і номери рядків можуть відрізнятися від описаних — код міг змінитись з моменту останньої діагностики (07.05.2026). 

**Перевіряй перед змінами.** Перед редагуванням будь-якого файлу — `view` його щоб побачити поточний стан. Якщо номери рядків в TASK не співпадають з реальністю — шукай по контексту (назвах функцій, ключових словах). Не довіряй TASK сліпо.

**Користуйся діагностикою.** В репо є `diagnostic_report_2026-05-07.md` з повним статичним аналізом коду. Звіртайся з нею при сумнівах. Якщо TASK і діагностика суперечать — діагностика свіжіша, але можлива і вона застаріла. Звіртай з реальним кодом.

**Документація йде разом з кодом.** Якщо в процесі виконання TASK виявиш що CLAUDE.md в зачеплених розділах застарів — створи `recommended_task_claude_md_audit.md` з конкретними розділами що потребують оновлення. Не оновлюй CLAUDE.md в цьому TASK (це окремий TASK CLAUDE.md Audit).

**SaaS-готовність.** Закладаємо одразу: tenantId, userId, createdAt, updatedAt, audit log готовність. Це частина "ембріон з повним ДНК" принципу.

**Без тимчасових рішень.** Якщо щось треба буде переробляти потім — не робимо зараз неправильно.

---

## КОНТЕКСТ

### Архітектурні рішення (з `dossier_architecture_decisions.md`)

**Канонічна схема документа** — 18 легких полів у `cases[].documents[]` (registry, завжди завантажене) + 6 важких у `.metadata/documents_extended.json` з lazy-load.

**Принцип Single Source of Truth для документів** (з `context_dossier_session_2026-05-07_v1_1.md` 1.1):

> `cases[].documents[]` у `registry_data.json` — єдине джерело легких метаданих документів справи. Важкі поля (теги, нотатки, історія обробки, анотації) виносяться у `documents_extended.json` у `.metadata/` папки справи з лазі-завантаженням. Концепція окремого `documents_index.json` у папці кожної справи відкидається — створює гібрид з постійною синхронізацією.

**Чотири історичні точки створення документа**, які треба об'єднати:
1. Швидкий аплоад через CaseDossier (drag-n-drop у вкладці Огляду)
2. DocumentProcessor після завершення обробки пакету
3. Додавання документа з зовнішнього URL/файлу через Реєстр Матеріалів (якщо така UI-точка існує)
4. Міграційні/тестові дані (`INITIAL_CASES`)

Кожна точка зараз заповнює різні набори полів. Нова функція `createDocument()` приймає raw metadata і повертає валідний об'єкт з усіма полями і дефолтами.

### Поточний стан коду (з `diagnostic_report_2026-05-07.md`)

Орієнтовні точки які знала діагностика на 07.05.2026 (перевір актуальність):

- `App.jsx:827` — точка створення документа (одна з)
- `App.jsx:965-968` — точка створення документа (інша)
- `src/components/CaseDossier/index.jsx:828-845` — uploadFile у CaseDossier
- `src/components/DocumentProcessor/index.jsx` — окрема нарізка `splitPDFByDocuments` (DocumentProcessor:107-140)
- `App.jsx` — `INITIAL_CASES` (20 справ) ініціалізують `storage` як `null`
- `src/services/ocrService.js` — фасад OCR (вже існує)

Орієнтовний поточний `schemaVersion` — 4. Перевір у `registry_data.json` структурі або у `App.jsx` константі.

### Що з цього випливає

Робота розбивається на 5 підзадач:
- **TASK 1.1.** Канонічна схема `documentSchema.js`
- **TASK 1.2.** Функція `createDocument()` + `validateDocument()`
- **TASK 1.3.** Сервіс `documentsExtended.js` для важких полів з lazy-load
- **TASK 1.4.** Об'єднання чотирьох точок створення на нову функцію
- **TASK 1.5.** Міграція registry `schemaVersion: 4 → 5`

Виконуй послідовно. Між підзадачами — коротка перевірка що все працює (систему запускати не потрібно, достатньо переконатись що код компілюється і існуючі функції не зламані).

---

## TASK 1.1 — Канонічна схема `documentSchema.js`

### Створи файл `src/schemas/documentSchema.js`

Папка `src/schemas/` може ще не існувати — створи її.

Файл повинен експортувати:

```javascript
// 18 легких полів канонічної схеми
export const CANONICAL_DOCUMENT_FIELDS = {
  // Ідентифікація
  id: { type: 'string', required: true, description: 'doc_<nanoid>' },
  name: { type: 'string', required: true, description: 'Людська назва документа' },
  originalName: { type: 'string', required: false, description: 'Оригінальне ім'я файлу як прийшло' },
  
  // Класифікація (обов'язкова, але може бути null для unclassified)
  category: { 
    type: 'string', 
    required: true, 
    nullable: true,
    enum: ['pleading', 'court_act', 'evidence', 'contract', 'correspondence', 'identification', 'other', null],
    description: 'Тип документа. null = маркер ⚠'
  },
  author: { 
    type: 'string', 
    required: true, 
    nullable: true,
    enum: ['ours', 'opp', 'court', 'third_party', null],
    description: 'Хто автор. null = маркер ⚠'
  },
  documentNature: { 
    type: 'string', 
    required: true,
    enum: ['searchable', 'scanned'],
    description: 'searchable = є текстовий шар, scanned = тільки зображення'
  },
  namingStatus: {
    type: 'string',
    required: true,
    enum: ['auto', 'manual', 'pending'],
    description: 'auto = згенеровано системою, manual = адвокат перейменував, pending = очікує'
  },
  isKey: { type: 'boolean', required: true, default: false, description: 'Ключовий документ ⭐' },
  
  // Зв'язки
  procId: { 
    type: 'string', 
    required: true, 
    nullable: true,
    description: 'ID провадження. null = маркер ⚠. Посилається на case.proceedings[].id'
  },
  
  // Drive
  driveId: { type: 'string', required: true, description: 'Google Drive file ID' },
  driveUrl: { type: 'string', required: false, description: 'Прямий URL на Drive' },
  folder: { 
    type: 'string', 
    required: true,
    enum: ['00_INBOX_СПРАВИ', '01_ОРИГІНАЛИ', '02_ОБРОБЛЕНІ', '03_ФРАГМЕНТИ', '04_ПОЗИЦІЯ', '05_ЗОВНІШНІ'],
    description: 'У якій підпапці справи лежить'
  },
  
  // Розмір і формат
  pageCount: { type: 'number', required: false, description: 'Кількість сторінок' },
  size: { type: 'number', required: true, description: 'Розмір файлу в байтах' },
  icon: { type: 'string', required: true, default: '📄', description: 'Емодзі іконка типу документа' },
  
  // Дати
  date: { type: 'string', required: false, format: 'date', description: 'Дата документа (не створення запису). YYYY-MM-DD' },
  addedAt: { type: 'string', required: true, format: 'datetime', description: 'ISO timestamp коли додано в систему' },
  updatedAt: { type: 'string', required: true, format: 'datetime', description: 'ISO timestamp останнього оновлення' },
  
  // Аудит для SaaS
  addedBy: { 
    type: 'string', 
    required: true,
    enum: ['lawyer_via_dp', 'lawyer_manual', 'agent', 'ecits', 'migration'],
    description: 'Хто додав документ'
  },
  
  // Стан
  status: { 
    type: 'string', 
    required: true,
    enum: ['active', 'archived'],
    default: 'active'
  }
};

// 6 важких полів (зберігаються в documents_extended.json з lazy-load)
export const EXTENDED_DOCUMENT_FIELDS = {
  documentId: { type: 'string', required: true, description: 'Зв'язок з canonical id' },
  tags: { type: 'array', items: 'string', default: [] },
  notes: { type: 'string', default: '' },
  annotations: { 
    type: 'array', 
    items: 'object',
    description: 'Анотації документа (працюють у режимі Текст у Viewer)',
    default: []
  },
  processingHistory: { 
    type: 'array', 
    items: 'object',
    description: 'Історія обробки: events створення, OCR, нарізки, ручних правок',
    default: []
  },
  extractedTextSummary: { 
    type: 'string', 
    description: '200-500 символів короткого змісту для tooltip превью',
    default: ''
  },
  customFields: { type: 'object', default: {} }
};

// Список критичних полів для маркера ⚠
export const CRITICAL_FIELDS_FOR_WARNING = ['procId', 'category', 'author'];

// Поточна версія схеми
export const CURRENT_SCHEMA_VERSION = 5;
```

### Критерії приймання TASK 1.1
- Файл існує і експортує константи
- Структура полів відповідає опису вище (18 легких + 6 важких)
- Жодних змін в існуючому коді на цьому етапі
- Файл імпортується без помилок (тестово додай import у будь-якому існуючому файлі і перевір що компілюється)

---

## TASK 1.2 — Функції `createDocument()` і `validateDocument()`

### Створи файл `src/services/documentFactory.js`

```javascript
import { CANONICAL_DOCUMENT_FIELDS, CURRENT_SCHEMA_VERSION } from '../schemas/documentSchema.js';
import { nanoid } from 'nanoid'; // або інший способу генерації id який вже є в проекті

/**
 * Створити валідний об'єкт документа з сирих метаданих
 * @param {Object} metadata - сирі метадані з будь-якої точки створення
 * @returns {Object} валідний документ за канонічною схемою
 */
export function createDocument(metadata) {
  // Генерація id якщо не передано
  const id = metadata.id || `doc_${nanoid(12)}`;
  
  const now = new Date().toISOString();
  
  const document = {
    // Ідентифікація
    id,
    name: metadata.name || metadata.originalName || 'Без назви',
    originalName: metadata.originalName || null,
    
    // Класифікація
    category: metadata.category || null,
    author: metadata.author || null,
    documentNature: metadata.documentNature || detectNature(metadata),
    namingStatus: metadata.namingStatus || 'pending',
    isKey: metadata.isKey || false,
    
    // Зв'язки
    procId: metadata.procId || null,
    
    // Drive
    driveId: metadata.driveId,
    driveUrl: metadata.driveUrl || null,
    folder: metadata.folder || '01_ОРИГІНАЛИ',
    
    // Розмір і формат
    pageCount: metadata.pageCount || null,
    size: metadata.size || 0,
    icon: metadata.icon || pickIcon(metadata),
    
    // Дати
    date: metadata.date || null,
    addedAt: metadata.addedAt || now,
    updatedAt: metadata.updatedAt || now,
    
    // Аудит
    addedBy: metadata.addedBy || 'lawyer_manual',
    
    // Стан
    status: metadata.status || 'active'
  };
  
  return document;
}

/**
 * Валідувати об'єкт документа
 * @param {Object} doc - об'єкт документа
 * @returns {{valid: boolean, errors: string[]}}
 */
export function validateDocument(doc) {
  const errors = [];
  
  // Перевір кожне поле канонічної схеми
  for (const [fieldName, fieldDef] of Object.entries(CANONICAL_DOCUMENT_FIELDS)) {
    const value = doc[fieldName];
    
    // Required
    if (fieldDef.required && !fieldDef.nullable && (value === undefined || value === null || value === '')) {
      errors.push(`Поле '${fieldName}' є обов'язковим`);
      continue;
    }
    
    // Required nullable — поле має бути присутнім але може бути null
    if (fieldDef.required && fieldDef.nullable && value === undefined) {
      errors.push(`Поле '${fieldName}' має бути присутнім (може бути null)`);
      continue;
    }
    
    // Type checking
    if (value !== null && value !== undefined) {
      if (fieldDef.type === 'string' && typeof value !== 'string') {
        errors.push(`Поле '${fieldName}' має бути string, отримано ${typeof value}`);
      }
      if (fieldDef.type === 'number' && typeof value !== 'number') {
        errors.push(`Поле '${fieldName}' має бути number, отримано ${typeof value}`);
      }
      if (fieldDef.type === 'boolean' && typeof value !== 'boolean') {
        errors.push(`Поле '${fieldName}' має бути boolean, отримано ${typeof value}`);
      }
    }
    
    // Enum
    if (fieldDef.enum && value !== null && value !== undefined) {
      if (!fieldDef.enum.includes(value)) {
        errors.push(`Поле '${fieldName}' має бути одним з [${fieldDef.enum.join(', ')}], отримано '${value}'`);
      }
    }
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Хелпер: визначити природу документа з метаданих
 */
function detectNature(metadata) {
  if (metadata.documentNature) return metadata.documentNature;
  
  // Якщо явно вказано що з OCR — scanned
  if (metadata.fromOCR || metadata.ocrProvider) return 'scanned';
  
  // PDF з текстовим шаром — searchable
  // (можна перевірити через pdf-lib якщо є файл, але зараз — за дефолтом)
  const ext = (metadata.originalName || metadata.name || '').toLowerCase().split('.').pop();
  if (['docx', 'html', 'txt', 'md'].includes(ext)) return 'searchable';
  
  // За дефолтом — searchable
  return 'searchable';
}

/**
 * Хелпер: підібрати іконку за типом документа
 */
function pickIcon(metadata) {
  if (metadata.icon) return metadata.icon;
  
  const category = metadata.category;
  switch (category) {
    case 'pleading': return '📋';
    case 'court_act': return '⚖';
    case 'evidence': return '📑';
    case 'contract': return '📄';
    case 'correspondence': return '✉';
    default: return '📄';
  }
}

/**
 * Хелпер: чи документ потребує перегляду (маркер ⚠)
 */
export function needsReview(doc) {
  return doc.procId === null || doc.category === null || doc.author === null;
}

/**
 * Хелпер: повертає список критичних полів які null
 */
export function getMissingCriticalFields(doc) {
  const missing = [];
  if (doc.procId === null) missing.push('провадження');
  if (doc.category === null) missing.push('тип');
  if (doc.author === null) missing.push('автор');
  return missing;
}
```

### Якщо `nanoid` ще не є в проекті

Перевір `package.json`. Якщо немає — використай інший механізм генерації id який вже є в проекті (наприклад, утиліти з App.jsx чи existing helper). Не додавай нову npm-залежність якщо є альтернатива.

### Критерії приймання TASK 1.2
- Файл `documentFactory.js` створений
- `createDocument(metadata)` повертає валідний об'єкт що проходить `validateDocument()`
- `validateDocument(doc)` коректно ловить відсутні обов'язкові поля
- `needsReview(doc)` коректно ідентифікує документи з маркером ⚠
- Існуючий код не зламано (компіляція проходить)

---

## TASK 1.3 — Сервіс `documentsExtended.js`

### Створи файл `src/services/documentsExtended.js`

Сервіс для роботи з `.metadata/documents_extended.json` з lazy-load.

```javascript
import { driveRequest, getDriveFile, createDriveFile } from './driveService.js';
import { EXTENDED_DOCUMENT_FIELDS } from '../schemas/documentSchema.js';

// In-memory кеш в межах сесії
const cache = new Map(); // key: caseId, value: { extended: {...}, loadedAt: Date }

/**
 * Завантажити documents_extended.json для справи
 * @param {string} caseId 
 * @param {Object} caseData - повний об'єкт справи (для отримання driveFolderId)
 * @returns {Promise<Object>} мапа documentId → extended fields
 */
export async function loadExtendedForCase(caseId, caseData) {
  // Перевір кеш
  if (cache.has(caseId)) {
    return cache.get(caseId).extended;
  }
  
  // Знайти .metadata папку
  // ВАЖЛИВО: ніколи не використовувати кирилицю в q= Drive API
  // Використовуй патерн з ensureSubFolders (CaseDossier:656-691)
  
  const metadataFolderId = await findMetadataFolder(caseData);
  if (!metadataFolderId) {
    // Папка не існує — повертаємо порожній об'єкт
    const empty = {};
    cache.set(caseId, { extended: empty, loadedAt: new Date() });
    return empty;
  }
  
  // Знайти documents_extended.json
  const fileId = await findExtendedFile(metadataFolderId);
  if (!fileId) {
    // Файл не існує — повертаємо порожній об'єкт
    const empty = {};
    cache.set(caseId, { extended: empty, loadedAt: new Date() });
    return empty;
  }
  
  // Прочитати файл
  try {
    const content = await readDriveFileText(fileId);
    const extended = JSON.parse(content);
    cache.set(caseId, { extended, loadedAt: new Date() });
    return extended;
  } catch (err) {
    console.error('Error loading documents_extended.json:', err);
    return {};
  }
}

/**
 * Зберегти documents_extended.json для справи
 * @param {string} caseId 
 * @param {Object} caseData 
 * @param {Object} extended - повна мапа documentId → extended fields
 */
export async function saveExtendedForCase(caseId, caseData, extended) {
  const metadataFolderId = await ensureMetadataFolder(caseData);
  const json = JSON.stringify(extended, null, 2);
  
  // Перевір чи файл існує — оновити, інакше створити
  const existingFileId = await findExtendedFile(metadataFolderId);
  if (existingFileId) {
    await updateDriveFile(existingFileId, json);
  } else {
    await createDriveFile(metadataFolderId, 'documents_extended.json', json);
  }
  
  // Оновити кеш
  cache.set(caseId, { extended, loadedAt: new Date() });
}

/**
 * Отримати extended-поля для конкретного документа
 */
export async function getExtendedForDocument(caseId, caseData, documentId) {
  const allExtended = await loadExtendedForCase(caseId, caseData);
  return allExtended[documentId] || createEmptyExtended(documentId);
}

/**
 * Оновити extended-поля для документа
 */
export async function setExtendedForDocument(caseId, caseData, documentId, fields) {
  const allExtended = await loadExtendedForCase(caseId, caseData);
  allExtended[documentId] = {
    ...createEmptyExtended(documentId),
    ...allExtended[documentId],
    ...fields
  };
  await saveExtendedForCase(caseId, caseData, allExtended);
}

/**
 * Інвалідувати кеш для справи (наприклад після прямих змін на Drive)
 */
export function invalidateCache(caseId) {
  cache.delete(caseId);
}

/**
 * Створити порожні extended-поля
 */
function createEmptyExtended(documentId) {
  return {
    documentId,
    tags: [],
    notes: '',
    annotations: [],
    processingHistory: [],
    extractedTextSummary: '',
    customFields: {}
  };
}

// Хелпери для роботи з Drive
async function findMetadataFolder(caseData) {
  // Шукай .metadata серед підпапок справи
  // Використовуй ensureSubFolders патерн
  // Не використовуй кирилицю в q=
  // ...
}

async function ensureMetadataFolder(caseData) {
  // Знайди .metadata, якщо немає — створи
  // ...
}

async function findExtendedFile(metadataFolderId) {
  // Шукай документ documents_extended.json у .metadata
  // ...
}

async function readDriveFileText(fileId) {
  // Прочитай текстовий вміст файлу через Drive API
  // ...
}

async function updateDriveFile(fileId, content) {
  // Перепиши вміст файлу
  // ...
}
```

**Реалізуй хелпери в кінці файлу.** Дивись існуючі функції в `src/services/driveService.js` як референс. ВАЖЛИВО: ніколи не використовувати кирилицю в `q=` Drive API — це порушення правила #8 з CLAUDE.md. Використовуй патерн з `ensureSubFolders` в `CaseDossier:656-691` (отримати всі підпапки без фільтра, шукати в JS).

### Критерії приймання TASK 1.3
- Файл `documentsExtended.js` створений з повною реалізацією
- Lazy-load працює: повторні виклики `loadExtendedForCase` не йдуть у Drive
- `getExtendedForDocument` для нового документа повертає порожні поля
- `setExtendedForDocument` зберігає на Drive у `.metadata/documents_extended.json`
- Жодного звернення до кирилиці в `q=` Drive API
- Структура `.metadata/` папки створюється якщо не існує
- Існуючий код не зламано

---

## TASK 1.4 — Об'єднання чотирьох точок створення документа

### Знайди всі точки створення документа

Перед редагуванням — пошук по коду. Використовуй grep або search по ключових словах: `documents.push`, `documents:`, `addDocument`, `createDocument`, `id: 'doc_`, `name:`. 

Орієнтовні точки які знала діагностика на 07.05.2026:
- `App.jsx:827` 
- `App.jsx:965-968`
- `src/components/CaseDossier/index.jsx:828-845` (uploadFile)
- `src/components/DocumentProcessor/index.jsx` (splitPDFByDocuments :107-140)
- `INITIAL_CASES` в App.jsx (для тестових справ)

Перевір актуальність цих точок. Можливо є додаткові які діагностика пропустила.

### Заміни кожну на виклик `createDocument()`

Приклад до:
```javascript
// Стара точка створення документа
const newDoc = {
  id: `doc_${Date.now()}`,
  name: file.name,
  driveId: uploadedFile.id,
  pageCount: pages,
  // ...не всі поля канонічної схеми
};
caseData.documents.push(newDoc);
```

Приклад після:
```javascript
import { createDocument } from '../services/documentFactory.js';

const newDoc = createDocument({
  name: file.name,
  originalName: file.name,
  driveId: uploadedFile.id,
  driveUrl: uploadedFile.webViewLink,
  pageCount: pages,
  size: file.size,
  documentNature: hasTextLayer ? 'searchable' : 'scanned',
  folder: '01_ОРИГІНАЛИ',
  addedBy: 'lawyer_manual', // або 'lawyer_via_dp' або інше залежно від точки
});

// Документ автоматично має всі канонічні поля включно з addedAt/updatedAt
caseData.documents.push(newDoc);
```

### Особливості по точках

**App.jsx (точки 827 і 965-968):** перевір контекст — для якого сценарію створюється документ. Постав правильний `addedBy`.

**CaseDossier (uploadFile :828-845):** це швидкий аплоад через drag-n-drop. `addedBy: 'lawyer_manual'`. `folder` залежить від того куди завантажується (швидкий аплоад → `00_INBOX_СПРАВИ` за новою архітектурою, але якщо ще не реалізовано — поки що `01_ОРИГІНАЛИ`).

**DocumentProcessor (splitPDFByDocuments :107-140):** це нарізаний документ після обробки. `addedBy: 'lawyer_via_dp'`. `folder: '02_ОБРОБЛЕНІ'` (або '01_ОРИГІНАЛИ' для оригіналу). Природа залежить від того як обробився.

**INITIAL_CASES:** це сід-дані для нових тенантів. `addedBy: 'migration'`. Перевір чи актуальний цей блок коду.

### Не зламай функціонал

Після кожної заміни — переконайся що функціонал не зламано. Не запускай систему руками — просто переконайся що:
- Імпорти правильні
- Жоден існуючий тест (якщо є) не зламано
- Лінтер не лається (якщо налаштовано)

### Критерії приймання TASK 1.4
- Усі чотири історичні точки створення документа використовують `createDocument()`
- Параметри передаються коректно (особливо `addedBy`, `folder`, `documentNature`)
- Жодних дублюючих ідентифікаторів (`id: 'doc_${Date.now()}'`) поза `createDocument()`
- Існуючий функціонал не зламано

---

## TASK 1.5 — Міграція registry `schemaVersion: 4 → 5`

### Створи файл `src/services/migrations/v4ToV5.js`

```javascript
import { createDocument } from '../documentFactory.js';

/**
 * Мігрувати реєстр з schemaVersion 4 на 5
 * Запускається один раз при першому відкритті системи з v5
 * 
 * Зміни:
 * - Документи доповнюються відсутніми канонічними полями
 * - Старі поля що не входять в канонічну схему — переносяться в customFields в documents_extended
 * - Додається schemaVersion: 5
 * 
 * @param {Object} registryData - повний об'єкт registry_data.json
 * @returns {{registry: Object, extendedByCase: Object}} 
 *   registry - оновлений registry з v5 структурою
 *   extendedByCase - мапа caseId → documents_extended мапа (для збереження окремо)
 */
export function migrateRegistryV4toV5(registryData) {
  const result = {
    registry: { ...registryData },
    extendedByCase: {} // caseId → { documentId → extended }
  };
  
  // Перевірка версії
  const currentVersion = registryData.schemaVersion || 1;
  if (currentVersion >= 5) {
    console.log(`[migration] Already at v${currentVersion}, no migration needed`);
    return result;
  }
  
  if (currentVersion < 4) {
    throw new Error(`Migration from v${currentVersion} to v5 not supported. Need v4 first.`);
  }
  
  // Мігрувати кожну справу
  result.registry.cases = registryData.cases.map(caseItem => {
    const migratedCase = { ...caseItem };
    const caseExtended = {};
    
    if (Array.isArray(caseItem.documents)) {
      migratedCase.documents = caseItem.documents.map(oldDoc => {
        const { canonical, extended } = splitDocumentV4toV5(oldDoc);
        if (extended) {
          caseExtended[canonical.id] = extended;
        }
        return canonical;
      });
    }
    
    result.extendedByCase[caseItem.id] = caseExtended;
    
    return migratedCase;
  });
  
  // Оновити версію схеми
  result.registry.schemaVersion = 5;
  result.registry.lastMigration = {
    from: currentVersion,
    to: 5,
    at: new Date().toISOString()
  };
  
  console.log(`[migration] v${currentVersion} → v5 completed: ${result.registry.cases.length} cases`);
  return result;
}

/**
 * Розділити старий v4 документ на canonical (легкі поля) і extended (важкі)
 */
function splitDocumentV4toV5(oldDoc) {
  // Створи canonical через createDocument щоб отримати всі дефолти
  const canonical = createDocument({
    id: oldDoc.id,
    name: oldDoc.name,
    originalName: oldDoc.originalName || oldDoc.name,
    category: oldDoc.category || null,
    author: oldDoc.author || null,
    documentNature: oldDoc.documentNature || (oldDoc.scanned ? 'scanned' : 'searchable'),
    namingStatus: oldDoc.namingStatus || 'manual',
    isKey: oldDoc.isKey || (Array.isArray(oldDoc.tags) && oldDoc.tags.includes('ключовий')),
    procId: oldDoc.procId || null,
    driveId: oldDoc.driveId,
    driveUrl: oldDoc.driveUrl,
    folder: oldDoc.folder || '01_ОРИГІНАЛИ',
    pageCount: oldDoc.pageCount,
    size: oldDoc.size || 0,
    icon: oldDoc.icon,
    date: oldDoc.date,
    addedAt: oldDoc.addedAt || oldDoc.createdAt || new Date().toISOString(),
    updatedAt: oldDoc.updatedAt || oldDoc.addedAt || new Date().toISOString(),
    addedBy: oldDoc.addedBy || 'migration',
    status: oldDoc.status || 'active'
  });
  
  // Витягни важкі поля
  const extended = {
    documentId: canonical.id,
    tags: Array.isArray(oldDoc.tags) ? oldDoc.tags.filter(t => t !== 'ключовий') : [],
    notes: oldDoc.notes || '',
    annotations: Array.isArray(oldDoc.annotations) ? oldDoc.annotations : [],
    processingHistory: Array.isArray(oldDoc.processingHistory) ? oldDoc.processingHistory : [],
    extractedTextSummary: oldDoc.extractedTextSummary || oldDoc.summary || '',
    customFields: {}
  };
  
  // Зберегти невідомі поля у customFields для безпеки
  const knownFields = new Set([
    'id', 'name', 'originalName', 'category', 'author', 'documentNature',
    'namingStatus', 'isKey', 'procId', 'driveId', 'driveUrl', 'folder',
    'pageCount', 'size', 'icon', 'date', 'addedAt', 'updatedAt', 'addedBy', 'status',
    'tags', 'notes', 'annotations', 'processingHistory', 'extractedTextSummary',
    'createdAt', 'scanned', 'summary'
  ]);
  
  for (const [key, value] of Object.entries(oldDoc)) {
    if (!knownFields.has(key)) {
      extended.customFields[key] = value;
    }
  }
  
  // Якщо в extended нічого немає крім обов'язкових — повернути null
  const hasContent = extended.tags.length > 0 || 
                     extended.notes || 
                     extended.annotations.length > 0 ||
                     extended.processingHistory.length > 0 ||
                     extended.extractedTextSummary ||
                     Object.keys(extended.customFields).length > 0;
  
  return {
    canonical,
    extended: hasContent ? extended : null
  };
}
```

### Інтегруй виклик міграції в App.jsx при завантаженні registry

Знайди місце де завантажується `registry_data.json` (орієнтовно — функція ініціалізації при старті системи). Додай перевірку версії і виклик міграції:

```javascript
import { migrateRegistryV4toV5 } from './services/migrations/v4ToV5.js';
import { saveExtendedForCase } from './services/documentsExtended.js';
import { CURRENT_SCHEMA_VERSION } from './schemas/documentSchema.js';

// При завантаженні registry
const registryData = await loadRegistryFromDrive();

if ((registryData.schemaVersion || 1) < CURRENT_SCHEMA_VERSION) {
  console.log('[startup] Migrating registry...');
  const { registry, extendedByCase } = migrateRegistryV4toV5(registryData);
  
  // Зберегти оновлений registry
  await saveRegistryToDrive(registry);
  
  // Зберегти extended для кожної справи окремо
  for (const [caseId, extended] of Object.entries(extendedByCase)) {
    if (Object.keys(extended).length > 0) {
      const caseData = registry.cases.find(c => c.id === caseId);
      if (caseData) {
        await saveExtendedForCase(caseId, caseData, extended);
      }
    }
  }
  
  console.log('[startup] Migration complete');
}
```

### Безпека міграції

**Перед запуском міграції — створи бекап.** Логіка приблизно така:

```javascript
// Перед міграцією
const backup = JSON.stringify(registryData);
const backupName = `registry_data_v${currentVersion}_before_migration_${Date.now()}.json`;
await createDriveFile(rootFolderId, backupName, backup);
```

Це окремий файл у `_backups/` (створи папку якщо немає). Якщо міграція провалиться або щось піде не так — є повний оригінал.

### Критерії приймання TASK 1.5
- Файл `migrations/v4ToV5.js` створений з повною реалізацією
- Міграція коректно розділяє документ на canonical (18 полів) і extended (6 полів + customFields)
- Невідомі поля старого документа потрапляють в `customFields` (безпека)
- Тег "ключовий" мігрується в `isKey: true` (а не залишається в tags)
- Інтеграція в App.jsx викликає міграцію при першому відкритті v5
- Перед міграцією створюється бекап у `_backups/`
- Існуючі справи відкриваються після міграції без помилок

---

## ОБЩЕ КРИТЕРІЇ ПРИЙМАННЯ TASK 1

1. Усі п'ять підзадач (1.1-1.5) виконані
2. Жоден з існуючих функціоналів не зламано
3. Реальний `registry_data.json` адвоката (з 18+ справами) проходить міграцію без помилок
4. Документи з `INITIAL_CASES` після міграції валідні
5. `.metadata/documents_extended.json` створюється для справ де є важкі дані
6. Бекап до міграції збережений у `_backups/`
7. CLAUDE.md правило #8 (заборона кирилиці в q= Drive API) дотримано
8. Якщо CLAUDE.md потребує оновлення в зачеплених розділах — створено файл `recommended_task_claude_md_audit.md` з описом

---

## SAAS IMPLICATIONS

**Готовність до multi-tenant:** канонічна схема включає `addedBy` для аудиту. Це поле використовуватиметься коли в системі буде кілька юристів бюро. Зараз `addedBy` = роль ('lawyer_via_dp', 'lawyer_manual', 'agent', etc), пізніше може стати `userId` або `{userId, role}`.

**Готовність до permissions:** документи в `cases[].documents[]` залишаться видимими для всіх хто має доступ до справи. Чутливі поля (annotations з privacy='private') винесені в `documents_extended.json` де при потребі можна додати фільтрацію за userId.

**Готовність до billing:** `addedAt`, `addedBy`, `processingHistory` дають базу для майбутніх звітів використання. `processingHistory` в extended може зберігати ai_usage події.

---

## BILLING IMPLICATIONS

`processingHistory` в `documents_extended.json` — місце куди будуть писатись події обробки документа (OCR, нарізка, очищення Haiku, генерація summary) з посиланнями на ai_usage. Зараз структура заклажена як порожній масив, реальне заповнення — в TASK Document Processor v2 (Фаза 2).

---

## ВЛАСНА АНАЛІТИКА І ТВОРЧЕ ВИКОНАННЯ

Цей TASK описує цільовий стан. Якщо в процесі виявиш:

- Кращий спосіб організації коду → роби, але обов'язково поясни в коментарі чому відхилився від TASK
- Помилку в архітектурному рішенні → зупинися, опиши проблему в окремому файлі `discovered_issues_during_task1.md` і чекай на рішення
- Застарілий чи неактуальний код у зачеплених місцях → зафіксуй у `recommended_task_claude_md_audit.md` для майбутнього CLAUDE.md Audit
- Можливі регресії в інших місцях → перерахуй їх в коментарі при здачі TASK

Не вважай TASK дзвоном з небес. Це план який треба виконати з розумом.

---

## ОЧІКУВАНІ АРТЕФАКТИ ВИКОНАННЯ

При здачі TASK додай:

1. Повний список створених/змінених файлів з коротким описом
2. Список знайдених точок створення документів які заміняв (з file:line)
3. Опис що зробив у міграції на тестових даних
4. Якщо створив `recommended_task_claude_md_audit.md` — опис його змісту
5. Якщо створив `discovered_issues_during_task1.md` — опис проблем
6. Список потенційних регресій на майбутнє (якщо помітив)

---

**Кінець TASK 1.**
