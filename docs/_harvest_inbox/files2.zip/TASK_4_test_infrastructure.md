# TASK 4 — Test Infrastructure Setup (Vitest + юніт-тести + інтеграційні)

**Дата формування:** 08.05.2026
**Фаза:** 1.5 (Канон даних і ACTIONS) — четвертий TASK
**Виконавець:** Claude Code (Opus 4.7, 1M context)
**Орієнтовний обсяг:** 4-6 годин
**Передумови:** TASK 1, TASK 2, TASK 3 (з patch'ами) завершені і закомічені

---

## ПРИНЦИПИ ВИКОНАННЯ

**Творчо, виважено, з повагою до якості коду.** Це інфраструктурний TASK як TASK 3. Інфраструктура тестування буде використовуватись усіма майбутніми TASK — кожна нова функція повинна автоматично писатись з тестами в цьому форматі.

Адвокат явно сказав: "хочу щоб робились перевірки максимально для того щоб потім не фіксити не правити без кінця. Вже є такий досвід — це набагато важче ніж гарно робити із самого початку". Постав достатньо тестів щоб майбутні зміни в коді не ламали поточну логіку без помітки.

**Перевіряй перед змінами.** Багато sanity-tests з TASK 1/2/3 уже існують у `scripts/`. Ці тести логічно структуровані і покривають критичну логіку — переюзовуй їх замість писати з нуля. Просто переформатуй під Vitest синтаксис.

**Якість тестів важливіша за кількість.** 50 хороших тестів які перевіряють реальну поведінку кращі ніж 200 формальних. Тести мають ловити справжні баги — не просто валідувати що "функція повертає об'єкт".

**Без тимчасових рішень.** Vitest стане частиною CI/CD — від цього залежатиме чи деплоїться код на сайт. Зробити правильно з першого разу.

**Швидкість виконання.** Тести мають бути швидкими — повний прогон за 30 секунд або менше. Інакше CI/CD стає повільним і люди починають ігнорувати червоні тести.

---

## КОНТЕКСТ

### Поточний стан тестування

З `diagnostic_report_2026-05-07.md` розділ 9.1:

> Тести. У package.json немає скриптів test. Жодних unit/integration/e2e тестів.
> CI/CD pipeline. Немає тест-job, немає lint-job.

Тобто **тестів зараз немає взагалі**. CI/CD деплоїть прямо без перевірок — будь-який зламаний коміт йде на сайт.

З TASK 1, TASK 2, TASK 3 у репо є sanity-tests як standalone Node.js скрипти:

```
scripts/
├── sanity_test_task1.mjs (з TASK 1)
├── sanity_test_task2.mjs (з TASK 2)
├── sanity_test_task3_basic.mjs
├── sanity_test_task3_multiturn.mjs
├── sanity_test_task3_tooldefs.mjs
└── sanity_test_task3_integration.mjs
```

Сумарно ~22 + 22 + 301 = ~345 тестових assertions покривають канонічну схему, ACTIONS, PERMISSIONS, Tool Use Foundation.

Запускаються вручну через `node scripts/sanity_test_taskN.mjs`. Якщо забути — в CI/CD не виконуються.

### Що з цього випливає

TASK 4 робить дві речі:

1. **Налаштовує Vitest** — стандартний test runner для Vite-проектів. Підключений в `npm test`, в CI/CD GitHub Actions. Конфіг мінімальний.

2. **Мігрує існуючі sanity-tests у Vitest формат** — переформатує `scripts/sanity_test_*.mjs` у `tests/` директорію зі стандартними `describe()`/`it()`/`expect()` блоками. Логіка тестів лишається — змінюється тільки оформлення.

3. **Додає кілька нових інтеграційних тестів** для типових workflow'ів (drag-n-drop, агент додає засідання, DP додає документи).

### Що TASK НЕ робить

- НЕ додає UI тести (Playwright, React Testing Library з emulator). Це окрема велика тема — Фаза майбутнього коли система буде в продакшні
- НЕ робить mutation testing або coverage reports — простий pass/fail зараз достатньо
- НЕ переписує всю логіку тестів — переформатовує існуюче
- НЕ створює моки для реального Anthropic API чи Drive API — тести працюють на чистих функціях і моках

---

## TASK 4.1 — Налаштування Vitest

### Додай Vitest у package.json

```bash
npm install --save-dev vitest @vitest/ui
```

Це додасть `vitest` (test runner) і `@vitest/ui` (опціонально — гарний UI для перегляду тестів локально).

### Додай скрипти у package.json

```json
{
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "test": "vitest run",
    "test:watch": "vitest",
    "test:ui": "vitest --ui"
  }
}
```

- `npm test` — одноразовий прогон (для CI/CD)
- `npm run test:watch` — watch mode (під час розробки)
- `npm run test:ui` — графічний UI у браузері (опціонально)

### Створи `vitest.config.js` в корені репо

```javascript
import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,                 // describe, it, expect доступні без імпортів
    environment: 'node',            // node environment (не jsdom — тестуємо сервіси, не UI)
    include: ['tests/**/*.test.{js,mjs,jsx}'],
    exclude: ['node_modules', 'dist', '.git'],
    testTimeout: 10000,             // 10 секунд на тест (vs дефолт 5)
    pool: 'threads',
    poolOptions: {
      threads: {
        maxThreads: 4,
        minThreads: 1
      }
    },
    reporters: process.env.CI ? ['default', 'json'] : ['default'],
    outputFile: process.env.CI ? './test-results.json' : undefined
  }
});
```

### Створи структуру директорії tests/

```
tests/
├── unit/
│   ├── documentFactory.test.js
│   ├── documentSchema.test.js
│   ├── documentsExtended.test.js
│   ├── migrations.test.js
│   ├── toolDefinitions.test.js
│   └── toolUseRunner.test.js
└── integration/
    ├── actions.test.js
    ├── drag-n-drop.test.js
    ├── agent-workflow.test.js
    └── document-processor.test.js
```

### Критерії приймання TASK 4.1

- `npm test` запускається і виконується
- Vitest знаходить тести в `tests/` директорії
- Конфіг працює на CI (Node 20)
- Білд проходить (Vitest у devDependencies, не блокує prod build)

---

## TASK 4.2 — Юніт-тести: міграція sanity-tests у Vitest

### Принцип міграції

Кожен `scripts/sanity_test_*.mjs` файл переформатовуй у відповідний `tests/unit/*.test.js` зі структурою:

**Було (sanity-test):**
```javascript
import { createDocument, validateDocument } from '../src/services/documentFactory.js';

const doc = createDocument({ name: 'Test', driveId: 'fake' });
const { valid, errors } = validateDocument(doc);
console.log('valid:', valid);
if (!valid) {
  console.error('FAIL:', errors);
  process.exit(1);
}
console.log('✓ Test 1: createDocument generates valid document');
```

**Стало (Vitest):**
```javascript
import { describe, it, expect } from 'vitest';
import { createDocument, validateDocument } from '../../src/services/documentFactory.js';

describe('documentFactory', () => {
  describe('createDocument', () => {
    it('generates valid document with required fields', () => {
      const doc = createDocument({ name: 'Test', driveId: 'fake' });
      const { valid } = validateDocument(doc);
      expect(valid).toBe(true);
    });
    
    it('generates unique ids', () => {
      const doc1 = createDocument({});
      const doc2 = createDocument({});
      expect(doc1.id).not.toBe(doc2.id);
    });
  });
});
```

### Файли для міграції

**`tests/unit/documentFactory.test.js`** — з `scripts/sanity_test_task1.mjs` секції про createDocument/validateDocument:
- createDocument з повними даними
- createDocument з мінімальними даними (дефолти)
- createDocument генерує унікальні id
- validateDocument ловить відсутні required поля
- validateDocument ловить enum violations
- needsReview коректно ідентифікує документи з ⚠
- getMissingCriticalFields повертає правильний список

**`tests/unit/documentSchema.test.js`** — нові тести по канонічній схемі:
- CANONICAL_DOCUMENT_FIELDS має всі 18 полів
- EXTENDED_DOCUMENT_FIELDS має 6 полів
- CRITICAL_FIELDS_FOR_WARNING містить procId, category, author
- CURRENT_SCHEMA_VERSION === 5
- Енам'и валідні (немає null у списках де не очікується)

**`tests/unit/documentsExtended.test.js`** — з sanity-tests TASK 1:
- loadExtendedForCase повертає порожній об'єкт для нової справи
- saveExtendedForCase і loadExtendedForCase round-trip
- getExtendedForDocument для нового документа повертає дефолти
- setExtendedForDocument мерджить поля коректно
- Кешування — повторний loadExtendedForCase не йде в Drive (мокнути Drive API і перевірити що викликався тільки раз)

**`tests/unit/migrations.test.js`** — з sanity-tests TASK 1:
- migrateRegistryV4toV5 на v4 даних → v5 структура
- splitDocumentV4toV5 розділяє документ на canonical + extended
- Невідомі поля старого документа → customFields
- Тег "ключовий" → isKey: true
- Дати у вільному форматі → customFields.legacyDateText
- Ідемпотентність — повторний запуск не ламає дані

**`tests/unit/toolDefinitions.test.js`** — з `scripts/sanity_test_task3_tooldefs.mjs`:
- Усі tools у DOSSIER_AGENT_TOOLS мають required fields
- Енам'и tools відповідають канонічній схемі
- DOSSIER_AGENT_TOOLS синхронізований з PERMISSIONS.dossier_agent
- EXCLUDED_FROM_DOSSIER_TOOLS пояснений
- Немає масивних types (Anthropic-friendly)
- Немає дублікатів name

**`tests/unit/toolUseRunner.test.js`** — з sanity-tests TASK 3 basic + multiturn:
- runToolUse: text-only response
- runToolUse: single tool call success
- runToolUse: multiple tool blocks паралельно
- runToolUse: tool падає (executeAction returns success: false)
- runToolUse: tool throws exception
- runToolUse: caseId protection (override на context.caseId)
- runMultiTurnConversation: 2 turn dialogue
- runMultiTurnConversation: maxTurns truncation
- callAPIWithRetry: 429 з Retry-After
- callAPIWithRetry: success on first try
- callAPIWithRetry: max retries exceeded

### Принципи якості міграції

1. **Зберігай сенс тесту**, не тільки assertion. Якщо sanity-test перевіряв "createDocument завжди генерує id" — Vitest тест має робити те саме. Не міняй що тестується.

2. **Групуй пов'язані тести у describe блоки**. `describe('documentFactory') > describe('createDocument') > it('generates unique ids')`. Це робить вивід зрозумілим.

3. **Назви тестів описові.** "тест 1" — погано. "generates unique ids for each call" — добре.

4. **Один it = одна assertion (або тісно пов'язана група).** Якщо в одному тесті 5 різних перевірок — розбий на 5 it.

5. **Setup через `beforeEach`** для повторюваних даних:
```javascript
let mockCases;
beforeEach(() => {
  mockCases = [{ id: 'case_001', documents: [] }];
});
```

6. **Видали старі sanity-tests після міграції.** Залишати дублі поганий стиль. Видали `scripts/sanity_test_*.mjs` після того як переконаєшся що Vitest тести покривають все.

### Критерії приймання TASK 4.2

- 6 файлів у `tests/unit/` створено
- Кожен файл містить describe/it блоки з зрозумілими назвами
- Усі assertions з sanity-tests перенесено
- `npm test` прогоняє всі і всі зелені
- Старі `scripts/sanity_test_*.mjs` видалено

---

## TASK 4.3 — Інтеграційні тести типових workflow'ів

### Що таке інтеграційні тести

Юніт-тести перевіряють одну функцію ізольовано. Інтеграційні — перевіряють що **кілька функцій працюють разом** правильно. Наприклад "drag-n-drop додає документ через executeAction → запис у state → коректно валідовано".

Ці тести цінніші бо ловлять **взаємодію** компонентів, не тільки окремі частини. Вони і повільніші — за рахунок mock'ів і setup'у.

### Файл `tests/integration/actions.test.js`

Тест executeAction з реальним PERMISSIONS, ACTIONS, validateDocument. Без mock'ів окрім state setters.

```javascript
import { describe, it, expect, beforeEach, vi } from 'vitest';

// Імпортуємо потрібне з App.jsx через експорт або повторюємо логіку
// Якщо ACTIONS і PERMISSIONS не експортуються — потрібно експортувати їх для тестування

describe('executeAction integration', () => {
  let cases, setCases, executeAction;
  
  beforeEach(() => {
    cases = [{
      id: 'case_001',
      name: 'Тестова справа',
      documents: [],
      hearings: [],
      proceedings: []
    }];
    setCases = vi.fn(updater => {
      cases = typeof updater === 'function' ? updater(cases) : updater;
    });
    // executeAction з реального коду але з ін'єкцією наших setCases
  });
  
  it('add_document успішно додає документ', async () => {
    const newDoc = createDocument({ name: 'Test', driveId: 'fake_id', size: 100, addedBy: 'lawyer_manual' });
    const result = await executeAction('dossier_agent', 'add_document', { 
      caseId: 'case_001', 
      document: newDoc 
    });
    
    expect(result.success).toBe(true);
    expect(cases[0].documents).toHaveLength(1);
    expect(cases[0].documents[0].id).toBe(newDoc.id);
  });
  
  it('add_document блокується якщо агент не має дозволу', async () => {
    const newDoc = createDocument({ name: 'Test', driveId: 'fake' });
    const result = await executeAction('dashboard_agent', 'add_document', { 
      caseId: 'case_001', 
      document: newDoc 
    });
    
    expect(result.success).toBe(false);
    expect(result.error).toContain('Немає повноважень');
  });
  
  it('delete_document блокується для агентів без _fromUI', async () => {
    // ...
  });
  
  it('delete_document проходить з _fromUI: true', async () => {
    // ...
  });
  
  it('add_documents batch атомарна валідація', async () => {
    const docs = [
      createDocument({ name: 'Doc 1', driveId: 'a' }),
      { name: 'Невалідний', /* без обов'язкових полів */ },
      createDocument({ name: 'Doc 3', driveId: 'c' })
    ];
    
    const result = await executeAction('document_processor_agent', 'add_documents', {
      caseId: 'case_001',
      documents: docs
    });
    
    expect(result.success).toBe(false);
    expect(cases[0].documents).toHaveLength(0);  // нічого не додано
  });
});
```

### Файл `tests/integration/drag-n-drop.test.js`

Симулює сценарій: адвокат перетягує файли в досьє → uploadFileLocal → add_document через executeAction → запис у state.

```javascript
describe('drag-n-drop workflow', () => {
  it('1 файл успішно додається в реєстр', async () => {
    // mock uploadFileLocal returns { driveId: 'fake_id' }
    // викликається add_document через executeAction
    // перевіряється що cases[0].documents має 1 запис з ⚠ маркером
    // (procId, category, author = null)
  });
  
  it('3 файли по черзі — всі додаються', async () => {
    // ...
  });
  
  it('Якщо upload fails — інші файли все одно додаються', async () => {
    // mock uploadFileLocal: 2й виклик throws, 1й і 3й success
    // expected: 2 документи в реєстрі (1 і 3)
  });
});
```

### Файл `tests/integration/agent-workflow.test.js`

Симулює сценарій: агент досьє отримує запит "додай засідання на 15 травня о 10:00" → tool_use → executeAction → state оновлено.

```javascript
describe('dossier agent workflow', () => {
  it('Single tool call: add_hearing', async () => {
    // Mock callAnthropicAPI returns:
    //   content: [
    //     { type: 'text', text: 'Додаю засідання...' },
    //     { type: 'tool_use', id: 't1', name: 'add_hearing', input: { caseId: 'case_001', date: '2026-05-15', time: '10:00' } }
    //   ]
    // 
    // Викликаємо runMultiTurnConversation
    // Перевіряємо: hearings має 1 запис, finalText містить підтвердження
  });
  
  it('Multi-turn: add_proceeding then add_document', async () => {
    // Mock returns 2 turns послідовно
    // Перевіряємо обидві дії виконані, фінальний текст коректний
  });
  
  it('caseId protection: модель передає інший caseId', async () => {
    // Mock returns tool_use з input.caseId = 'WRONG_ID'
    // Перевіряємо: executeAction отримав params.caseId = context.caseId
    // tool_result містить _caseIdOverridden: true
  });
  
  it('Error propagation: tool fails', async () => {
    // executeAction returns success: false
    // Перевіряємо: модель отримує is_error: true, runMultiTurn продовжує
  });
});
```

### Файл `tests/integration/document-processor.test.js`

Заглушка з 1-2 простими тестами для майбутнього TASK Document Processor v2:

```javascript
describe('document processor integration (placeholder)', () => {
  it('add_documents через document_processor_agent додає batch', async () => {
    const docs = [
      createDocument({ name: 'Позов', driveId: 'a', addedBy: 'lawyer_via_dp' }),
      createDocument({ name: 'Відзив', driveId: 'b', addedBy: 'lawyer_via_dp' }),
      createDocument({ name: 'Ухвала', driveId: 'c', addedBy: 'lawyer_via_dp' })
    ];
    
    const result = await executeAction('document_processor_agent', 'add_documents', {
      caseId: 'case_001',
      documents: docs
    });
    
    expect(result.success).toBe(true);
    expect(result.addedCount).toBe(3);
  });
  
  it('document_processor_agent заблокований на create_case', async () => {
    const result = await executeAction('document_processor_agent', 'create_case', {});
    expect(result.success).toBe(false);
  });
});
```

### Експорт ACTIONS, PERMISSIONS, executeAction для тестів

Якщо вони зараз закриті в App.jsx — треба експортувати щоб тести могли імпортувати. Можна:

**Варіант A:** Винести в окремий файл `src/services/actionsRegistry.js` (краще архітектурно — App.jsx стає чистішим).

**Варіант B:** Просто експортувати з App.jsx через `export const ACTIONS = ...; export const PERMISSIONS = ...;`.

Виберіть простіший варіант. Якщо рішення значне (винесення в окремий файл) — спочатку запустити sanity-перевірку що нічого не зламалось.

### Критерії приймання TASK 4.3

- 4 файли в `tests/integration/` створено
- Інтеграційні тести покривають критичні workflow'и
- Mock'и реалістичні — не "успіх просто бо так"
- `npm test` прогоняє всі і всі зелені
- Час виконання всіх тестів < 30 секунд

---

## TASK 4.4 — Інтеграція з GitHub Actions CI/CD

### Оновити `.github/workflows/deploy.yml`

Поточний workflow деплоїть прямо без перевірок. Додаємо тест-job який блокує деплой при червоних тестах.

```yaml
name: Deploy

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

jobs:
  test:                              # НОВИЙ JOB
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npm test
      
  build:
    needs: test                       # ЗАЛЕЖИТЬ ВІД test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npm run build
      - uses: actions/configure-pages@v5
      - uses: actions/upload-pages-artifact@v3
        with:
          path: dist
          
  deploy:
    needs: build
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - id: deployment
        uses: actions/deploy-pages@v4
```

Тепер flow: push → test job (npm test) → якщо зелено → build → deploy. Якщо червоний тест — деплой не відбувається.

### Створи (або онови) `.github/workflows/pr-checks.yml`

Опціонально — щоб тести запускались і на pull requests перед merge. Зараз гілка одна (main), pull requests не використовуються — тому це опційно.

### Критерії приймання TASK 4.4

- `.github/workflows/deploy.yml` має новий test job
- test job блокує build і deploy при failure
- При push на main автоматично запускаються тести
- Якщо червоні — на сайт не деплоїться

---

## TASK 4.5 — Документація

### Додай розділ "Тестування" в CLAUDE.md

Додай у розділі "розробка" або в новій секції:

```markdown
## ТЕСТУВАННЯ

Стек: Vitest (test runner)

### Команди

- `npm test` — повний прогон
- `npm run test:watch` — watch mode для розробки
- `npm run test:ui` — графічний UI

### Структура

```
tests/
├── unit/               — юніт-тести сервісів
└── integration/        — інтеграційні тести workflow'ів
```

### Правило для нових TASK

Кожен новий TASK з суттєвими змінами повинен:
1. Додати юніт-тести для нових функцій у `tests/unit/`
2. Додати інтеграційні тести для нових workflow'ів у `tests/integration/`
3. Перевірити що `npm test` повністю зелений перед коммітом

CI/CD блокує деплой при червоних тестах.
```

### Принцип "тести разом з кодом" у DEVELOPMENT_PHILOSOPHY.md

Додай новий пункт у розділі правил:

```markdown
### Тести разом з кодом

Кожна нова функція пишеться разом з тестом. Не "потім додамо тести коли встигнемо" — це ніколи не настає. TASK з суттєвими змінами без оновлення тестів не вважається завершеним.
```

### Критерії приймання TASK 4.5

- CLAUDE.md має розділ Тестування
- DEVELOPMENT_PHILOSOPHY.md оновлено

---

## SAAS IMPLICATIONS

Тести зараз перевіряють одну справу і одного користувача (DEFAULT_TENANT). Коли активується multi-user — додаткові тести:
- checkTenantAccess блокує крос-tenant дії
- checkCaseAccess блокує доступ до чужих справ
- audit log містить tenantId і userId у кожному записі

Це окремий TASK Multi-user Activation — не зараз. Інфраструктура Vitest вже готова до цього розширення.

---

## BILLING IMPLICATIONS

Тести не пишуть в реальний ai_usage (бо це призведе до забруднення даних). Mock'и `logAiUsage` коректно перевіряють що функція викликається з правильними параметрами, але самі записи не йдуть у registry.

При запуску тестів локально — окремий test environment. У CI — теж ізольований.

---

## КОМІТ І ПУШ

Після всіх змін і успішного `npm test`:

```bash
git commit -m "feat: TASK 4 — Vitest test infrastructure (50+ unit tests + 15+ integration tests + CI integration)"
git push origin main
```

GitHub Actions запустить тести → якщо зелено → деплой.

---

## ОЧІКУВАНІ АРТЕФАКТИ ВИКОНАННЯ

Створи файл звіту `report_task4.md` у корені репо.

### Структура файлу звіту

**Резюме TASK 4** — один абзац що зроблено

**Реалізація з TASK** — таблиця підзадач 4.1-4.5 зі статусом і file:line

**Створені файли** — таблиця з призначенням
- vitest.config.js
- tests/unit/*.test.js (6 файлів)
- tests/integration/*.test.js (4 файли)

**Змінені файли** — package.json, .github/workflows/deploy.yml, CLAUDE.md, DEVELOPMENT_PHILOSOPHY.md

**Видалені файли** — scripts/sanity_test_*.mjs (всі 6 файлів після успішної міграції)

**Покриття тестами** — таблиця:
| Модуль | Юніт-тести | Інтеграція |
|--------|------------|-----------|
| documentFactory | 12 | - |
| toolUseRunner | 15 | - |
| executeAction | - | 8 |
| ... | ... | ... |

**Сумарно тестів** — кількість

**Час виконання** — `npm test` секунд

**CI/CD статус** — тест job додано, блокує deploy при failure

**Знахідки** — якщо щось виявив під час міграції

**Білд + push**

### Пояснення в термінал для адвоката

Коротке людське пояснення без термінів типу "Vitest", "CI/CD", "юніт-тест". Стиль як родичу.

Що в поясненні:
- Що зроблено простими словами (тепер у системи є автоматичні перевірки)
- Як це впливає на роботу (помилки ловляться до того як ти їх побачиш)
- Що тепер відбувається при кожному оновленні (автоматичні перевірки → якщо щось зламано, деплой не йде)
- Скільки перевірок зараз (X зелених)
- Як швидко вони працюють (за Y секунд)
- Що тобі робити (нічого — все автоматично, але якщо побачиш на GitHub червоний індикатор замість зеленого — кажи)

Приклад тону:

> Я зробив систему автоматичних перевірок. Тепер коли ми робимо будь-яку зміну в коді — перед тим як вона потрапить на сайт, понад N автоматичних тестів перевіряють що нічого не зламано. Якщо хоч один тест червоний — сайт не оновлюється поки не виправимо.
>
> Що тобі це дає:
> - Раніше якщо я ламав щось — ти бачив це сам коли заходив на сайт
> - Тепер до сайту йде тільки те що пройшло всі перевірки
> - Якщо щось не пройшло — Claude Code побачить червоний результат і виправить перед коммітом
>
> Скільки перевірок зараз: N зелених, прогон займає Y секунд
>
> Деталі — у `report_task4.md`.

---

## ВЛАСНА АНАЛІТИКА І ТВОРЧЕ ВИКОНАННЯ

Якщо в процесі виявиш:
- Sanity-tests мають баги (тестують неправильне) — виправ при міграції з поясненням у звіті
- ACTIONS/PERMISSIONS закриті в App.jsx — винеси в окремий файл (TASK 4.3 варіант A) це покращення архітектури
- Деякі сервіси неможливо тестувати без рефакторингу — зафіксуй у `discovered_issues_during_task4.md` для майбутнього
- Vitest може запропонувати додаткові плагіни (coverage, naming) — за дефолтом не додавай, тільки базова конфігурація

**Критерій якості тестів:** якщо я через 3 місяці зміню code path який тести покривають і не помічу баг — це поганий тест. Якщо помічу — добрий. Тести мають ловити реальні зміни поведінки.

Не вважай TASK дзвоном з небес. Адаптуйся під реальність коду.

---

**Кінець TASK 4.**
