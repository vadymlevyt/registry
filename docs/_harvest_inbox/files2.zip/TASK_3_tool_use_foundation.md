# TASK 3 — Tool Use Foundation для модуля Досьє

**Дата формування:** 08.05.2026
**Фаза:** 1.5 (Канон даних і ACTIONS) — третій TASK
**Виконавець:** Claude Code (Opus 4.7, 1M context)
**Орієнтовний обсяг:** 8-12 годин
**Передумови:** TASK 1 і TASK 2 завершені і закомічені

---

## ПРИНЦИПИ ВИКОНАННЯ

**Творчо, виважено, з повагою до якості коду.** Це інфраструктурний TASK. Те що зробиш зараз буде використовуватись усіма майбутніми агентами на Tool Use — Document Processor v2, Canvas, ЄСІТС агент. Якість коду тут визначає якість усіх наступних модулів.

Адвокат явно сказав: "Я хочу щоб система була гарною не тільки ззовні а й зсередини. Якби я сам це писав — старався б щоб код був охайним". Старайся писати так як писав би сам адвокат якби вмів — простий, читабельний, без зайвих абстракцій, з ясними назвами, з коментарями де логіка нетривіальна.

**Перевіряй перед змінами.** TASK 1 і TASK 2 значно змінили код. Номери рядків з діагностики 07.05.2026 застаріли. Шукай реальні точки в коді через grep і view перед редагуванням.

**Користуйся існуючою діагностикою.** В репо `diagnostic_report_2026-05-07.md` має розділи 1.2 (agent_history), 1.3 (контекст-менеджер), 1.4 (PERMISSIONS — оновлено в TASK 2), 1.6 (ACTIONS — оновлено в TASK 2).

**Тести максимально.** Адвокат явно просить більше перевірок: "хочу щоб робились перевірки максимально для того щоб потім не фіксити не правити без кінця. Вже є такий досвід — це набагато важче ніж гарно робити із самого початку". Пиши кілька sanity-test файлів якщо одного замало. Покривай edge cases. Краще зайва перевірка ніж пропущений баг.

**SaaS-готовність.** Tool Use Runner закладається з multi-tenant і multi-user в розумі.

**Без тимчасових рішень.** Tool Use буде використовуватись роками — роби нормально з першого разу.

---

## КОНТЕКСТ

### Що таке Tool Use і навіщо це потрібно

Зараз агенти спілкуються з системою через парсинг тексту: повертають у відповіді блок `ACTION_JSON: { ... }`, App.jsx ловить його регулярним виразом, виконує дію через executeAction. Це працює, але має проблеми: парсинг крихкий, типізації немає, multi-turn складно реалізувати.

**Tool Use** — нативний механізм Anthropic API: передаємо tools з input_schema, модель повертає `tool_use` блок з типізованими параметрами, виконуємо tool, повертаємо `tool_result`, модель може call'ити ще tools або завершити з фінальним текстом.

### Стратегічне рішення (з DEVELOPMENT_PHILOSOPHY.md)

Tool Use вперше реалізується для агента досьє. Модуль Досьє з самого початку будується на Tool Use, не на ACTION_JSON. Це **єдиний раз** коли ми закладаємо інфраструктуру:

```
src/services/
├── toolUseRunner.js       — універсальний раннер (НОВЕ)
└── toolDefinitions.js     — реєстр доступних tools (НОВЕ)
```

Наступні модулі (DP v2, Canvas) переюзовують.

**НЕ мігруємо на Tool Use:**
- QI agent — стабільний, працює, не чіпаємо
- Dashboard agent — стабільний  
- Dossier-чат у поточному вигляді — він де-факто ще не повноцінно реалізований, тому замість міграції — реалізація з нуля одразу на Tool Use

### Контентні промпти НЕ змінюються

Tool Use стосується тільки шару повернення команд. Контентні промпти агентів залишаються 1:1.

Для агента досьє контентний промпт ще не існує повноцінно — його будемо допрацьовувати в наступних TASK Фази 1.6. Цей TASK закладає тільки інфраструктуру і базовий placeholder промпт.

### Поточний стан після TASK 1 і TASK 2

- ACTIONS: 38 (включно з новими 8 з TASK 2)
- PERMISSIONS: 4 ролі (qi, dashboard, dossier, document_processor)
- executeAction: async, повертає {success, error?, ...result}
- API виклики до Anthropic: через fetch з anthropic-dangerous-direct-browser-access
- agent_history для досьє: 3-tier (registry / localStorage / Drive), slice -50 при збереженні, slice -10 при API
- Поточний агент досьє: викликається з CaseDossier (точне розташування рядків після TASK 2 — перевір через grep)

---

## TASK 3.1 — `toolDefinitions.js`

### Створи файл `src/services/toolDefinitions.js`

Реєстр визначень tools у форматі Anthropic API. Структура одного tool:

```javascript
{
  name: 'add_document',          // відповідає action name з ACTIONS
  description: '...',             // що робить tool, коли викликати
  input_schema: {                 // JSON Schema параметрів
    type: 'object',
    properties: { ... },
    required: [...]
  }
}
```

### Tools для агента досьє (повний перелік)

Має бути визначення для кожного ACTION з PERMISSIONS.dossier_agent (з TASK 2). Перевір реальний список через grep `'dossier_agent'` у App.jsx.

Очікуваний список:
- `add_document`, `update_document` (без delete — UI only)
- `add_proceeding`, `update_proceeding` (без delete — UI only)
- `add_hearing`, `update_hearing`, `delete_hearing`
- `add_deadline`, `update_deadline`, `delete_deadline`
- `add_note`, `update_note`, `delete_note`, `pin_note`, `unpin_note`
- `update_case_field`, `close_case`, `restore_case`
- `update_processing_context`

### Якість description'ів

Description — головне що читає модель щоб обрати правильний tool. Принципи:

1. **Actionable.** Не "Додає документ" — а "Додати один документ у справу. Створює запис у реєстрі. Використовується коли адвокат каже додати конкретний документ або при drag-n-drop з UI."

2. **Edge cases в описі.** "Якщо тип документа невідомий — передавай null, документ отримає маркер ⚠ для подальшого ручного класифікації."

3. **Розрізнення подібних tools.** В description add_document обов'язково: "Для пакетного додавання багатьох документів використовуй add_documents (доступний Document Processor агенту)".

### Енами

Усі енам'и мають точно відповідати канонічній схемі (TASK 1) і реальним ACTIONS (TASK 2):

- category: ['pleading', 'motion', 'court_act', 'evidence', 'contract', 'correspondence', 'identification', 'other', null]
- author: ['ours', 'opponent', 'court', 'third_party', null]  ⚠ `opponent`, не `opp`
- documentNature: ['searchable', 'scanned']
- namingStatus: ['auto', 'manual', 'pending']
- proceeding type: ['first_instance', 'appeal', 'cassation', 'enforcement', 'review_new_circumstances', 'pre_trial_investigation', 'other']
- proceeding color: ['green', 'blue', 'yellow', 'gray']

### Експортуй так

Кожен tool — окрема константа (для зручності тестування і документування):

```javascript
export const ADD_DOCUMENT_TOOL = { ... };
export const UPDATE_DOCUMENT_TOOL = { ... };
// ...

// Реєстри по ролях агентів
export const DOSSIER_AGENT_TOOLS = [
  ADD_DOCUMENT_TOOL,
  UPDATE_DOCUMENT_TOOL,
  // ...
];

// Заглушка для майбутнього DP v2
export const DOCUMENT_PROCESSOR_AGENT_TOOLS = [];

// Утиліта
export function getToolsForAgent(agentId) {
  switch (agentId) {
    case 'dossier_agent': return DOSSIER_AGENT_TOOLS;
    case 'document_processor_agent': return DOCUMENT_PROCESSOR_AGENT_TOOLS;
    default: return [];
  }
}
```

### Критерії приймання TASK 3.1
- Усі tools з PERMISSIONS.dossier_agent мають визначення
- Description'и descriptive і інформативні (не просто перепис назви action)
- Енам'и валідні і відповідають реальній схемі
- DOSSIER_AGENT_TOOLS список повний і синхронізований
- Файл імпортується без помилок

---

## TASK 3.2 — `toolUseRunner.js`

### Створи файл `src/services/toolUseRunner.js`

Універсальний раннер який:
1. Приймає API відповідь моделі з tool_use блоками
2. Викликає executeAction для кожного tool_use блоку
3. Формує tool_result блоки для наступного API турну
4. Логує ai_usage з токенами і вартістю
5. Підтримує multi-turn діалог

### Архітектура (дві основні функції)

**`runToolUse({ apiResponse, agentId, userId, tenantId, executeAction, caseId })`** — обробляє одну API відповідь, повертає `{ toolResults, hasToolUse, finalText, errors }`.

**`runMultiTurnConversation({ callAnthropicAPI, initialMessages, tools, systemPrompt, context, maxTurns })`** — керує циклом турнів. Викликає API → runToolUse → якщо hasToolUse → ще турн з tool_results → повтор. Зупиняється коли hasToolUse=false (фінальний текст) або досягнуто maxTurns.

### Принципи реалізації

1. **Декомпозиція.** Окремі чисті функції для одного блоку, для одної відповіді, для multi-turn.

2. **Помилки не каскадуються.** Якщо один tool падає — інші виконуються, помилки в errors array.

3. **Multi-turn з обмеженням.** maxTurns=10 за дефолтом, захист від нескінченного циклу.

4. **Контекст автоматично.** caseId з context додається до params якщо модель пропустила.

5. **Token logging.** Після кожного API турну писати ai_usage.

### Приклад використання

```javascript
const { finalText, totalToolCalls, errors } = await runMultiTurnConversation({
  callAnthropicAPI: async ({ messages, tools, systemPrompt }) => {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { ... },
      body: JSON.stringify({ model, max_tokens, system: systemPrompt, messages, tools })
    });
    return await response.json();
  },
  initialMessages: [...history, { role: 'user', content: userMessage }],
  tools: DOSSIER_AGENT_TOOLS,
  systemPrompt: DOSSIER_AGENT_SYSTEM_PROMPT,
  context: {
    agentId: 'dossier_agent',
    userId,
    tenantId,
    executeAction,
    caseId: caseData.id
  },
  maxTurns: 10
});
```

### Критерії приймання TASK 3.2
- toolUseRunner.js створено з повною реалізацією
- runToolUse коректно обробляє text + tool_use блоки
- runMultiTurnConversation працює з maxTurns
- Помилки tools не блокують виконання інших
- ai_usage логування інтегровано
- Файл добре прокоментований

---

## TASK 3.3 — Інтеграція з агентом досьє

### Знайди поточний код агента досьє

Через grep знайди функцію яка робить API виклик з CaseDossier — імовірно `handleSendMessage`, `sendChat`, або подібне навколо рядків 1286-1373 (з діагностики, перевір актуальність).

Поточний flow:
1. Підготовка історії (slice -10)
2. Виклик API
3. Парсинг ACTION_JSON якщо є
4. Додавання в історію

### Заміни на Tool Use flow

```javascript
import { runMultiTurnConversation } from '../../services/toolUseRunner.js';
import { DOSSIER_AGENT_TOOLS } from '../../services/toolDefinitions.js';

async function handleSendMessage(userMessage) {
  const history = agentMessages.slice(-10).map(m => ({ role: m.role, content: m.content }));
  
  try {
    const { finalText, totalToolCalls, errors } = await runMultiTurnConversation({
      callAnthropicAPI: callAPIWithRetry,  // з TASK 3.6
      initialMessages: [...history, { role: 'user', content: userMessage }],
      tools: DOSSIER_AGENT_TOOLS,
      systemPrompt: DOSSIER_AGENT_SYSTEM_PROMPT,
      context: {
        agentId: 'dossier_agent',
        userId: getCurrentUserId(),
        tenantId: getCurrentTenantId(),
        executeAction,
        caseId: caseData.id
      },
      maxTurns: 10
    });
    
    // Оновити історію
    setAgentMessages(prev => [
      ...prev,
      { role: 'user', content: userMessage, ts: new Date().toISOString() },
      { role: 'assistant', content: finalText, ts: new Date().toISOString() }
    ]);
    
    // Логування
    if (totalToolCalls > 0) {
      console.log(`[dossier_agent] Executed ${totalToolCalls} tool calls`);
    }
    if (errors.length > 0) {
      console.warn('[dossier_agent] Tool errors:', errors);
    }
  } catch (err) {
    setAgentMessages(prev => [
      ...prev,
      { role: 'user', content: userMessage, ts: new Date().toISOString() },
      { role: 'assistant', content: '⚠ Не вдалось зв\'язатись з агентом. Спробуйте ще раз.', ts: new Date().toISOString() }
    ]);
    console.error('[dossier_agent] API error:', err);
  }
}
```

### Прибери ACTION_JSON парсинг

Якщо в коді є парсинг `ACTION_JSON:` через regex/depth counter — прибери повністю. У Tool Use він не потрібен.

### Системний промпт

Якщо для досьє ще немає системного промпту — створи мінімальний placeholder:

```javascript
const DOSSIER_AGENT_SYSTEM_PROMPT = `Ти агент досьє адвоката Вадима Левицького.

Контекст: ти працюєш всередині модуля Досьє конкретної справи. Адвокат відкрив справу і веде з тобою розмову про неї.

Твоя робота:
- Відповідай на запитання про справу
- Виконуй дії через надані tools коли треба внести зміни (додати засідання, дедлайн, нотатку, документ, провадження)
- Якщо адвокат говорить нечітко — перепитай, не вгадуй
- Дотримуйся української мови

Важливо:
- Використовуй tools тільки коли впевнений у параметрах
- Дати у форматі YYYY-MM-DD, час у форматі HH:MM (24-год)
- Якщо адвокат каже "наступного понеділка" — обчисли реальну дату
- Не вигадуй ID — користуйся тими які є в контексті`;
```

Контент промпту можна доопрацьовувати в наступних TASK. Зараз важлива інфраструктура.

### Критерії приймання TASK 3.3
- Агент досьє використовує runMultiTurnConversation
- Tools передаються в API виклик
- Multi-turn діалог працює
- ACTION_JSON парсинг видалено
- Адвокат бачить фінальний текст агента
- Помилки обробляються gracefully

---

## TASK 3.4 — Edge cases

Перевір що ці випадки обробляються коректно. Якщо щось не покривається — додай обробку:

**A. Tool падає у середині multi-turn.** add_proceeding success → add_document помилка. Очікуване: перший tool збережено, помилка повертається моделі через tool_result, модель адаптується.

**B. Мережева помилка в середині multi-turn.** Перший турн ОК, другий fetch падає. Очікуване: дії з першого турну збережені, адвокат бачить дружнє повідомлення про втрачений зв'язок.

**C. Модель повертає невалідні параметри.** date='завтра' замість YYYY-MM-DD. Очікуване: executeAction провалюється з валідаційною помилкою, модель отримує error через tool_result, виправляє формат.

**D. Модель залипає у циклі.** 10 turns без фінального тексту. Очікуване: maxTurns зупиняє, повертає truncated:true, UI показує попередження.

### Критерії приймання TASK 3.4
- Усі чотири випадки мають визначену поведінку
- Тести покривають принаймні два

---

## TASK 3.5 — Token counting і ai_usage

### Перевір aiUsageService

Подивись `src/services/aiUsageService.js`. Якщо існує — переюзовуй API. Якщо немає — створи.

### Структура запису ai_usage

```javascript
{
  id: 'aiu_<timestamp>_<random>',
  agentId: 'dossier_agent',
  userId,
  tenantId,
  caseId,
  model: 'claude-sonnet-4-20250514',
  inputTokens: 1234,
  outputTokens: 567,
  toolCalls: 3,
  costUsd: 0.0123,
  timestamp: ISO_string
}
```

### MODEL_PRICING константа

Винеси у `aiUsageService.js`:

```javascript
const MODEL_PRICING = {
  'claude-sonnet-4-20250514': { input: 3, output: 15 },        // $/M tokens
  'claude-haiku-4-5-20251001': { input: 0.25, output: 1.25 },
  'claude-opus-4-7': { input: 15, output: 75 }
};

export function calculateCost(model, inputTokens, outputTokens) {
  const pricing = MODEL_PRICING[model];
  if (!pricing) {
    console.warn(`[aiUsageService] Unknown model: ${model}`);
    return 0;
  }
  return (inputTokens / 1_000_000) * pricing.input + 
         (outputTokens / 1_000_000) * pricing.output;
}
```

### Критерії приймання TASK 3.5
- ai_usage пишеться після кожного API турну
- Структура повна включно з costUsd
- MODEL_PRICING винесено константою

---

## TASK 3.6 — Помилки і retry

### Дружні повідомлення замість технічних

**API недоступний** (мережа, 5xx): "Не вдалось зв'язатись з агентом. Спробуйте ще раз через хвилину."

**401**: "Перевірте API ключ Claude в налаштуваннях."

**429** (rate limit): "Забагато запитів за короткий час. Спробуйте через хвилину."

### Retry для transient errors

Exponential backoff для 429 і 5xx:

```javascript
async function callAPIWithRetry(params, maxRetries = 3) {
  let lastError;
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { ... },
        body: JSON.stringify(params)
      });
      
      if (response.status === 429 || response.status >= 500) {
        const delay = Math.pow(2, attempt) * 1000;
        await new Promise(r => setTimeout(r, delay));
        continue;
      }
      
      if (!response.ok) {
        throw new Error(`API error ${response.status}`);
      }
      
      return await response.json();
    } catch (err) {
      lastError = err;
      if (attempt === maxRetries - 1) throw err;
      await new Promise(r => setTimeout(r, Math.pow(2, attempt) * 1000));
    }
  }
  throw lastError;
}
```

### Критерії приймання TASK 3.6
- Дружні повідомлення про помилки (не технічні)
- Retry для transient errors
- Помилки логуються в console для діагностики

---

## TASK 3.7 — Тести

### 4 файли тестів покриваючих різні аспекти

**`scripts/sanity_test_task3_basic.mjs`** — базовий runToolUse:
- text-only response (немає tool_use)
- single tool_use call (success)
- multiple tool_use blocks паралельно
- tool падає (executeAction success: false)
- tool кидає exception

**`scripts/sanity_test_task3_multiturn.mjs`** — multi-turn:
- 2 турна послідовно (tool → tool → final text)
- maxTurns обмеження (моделює залипання)
- помилка в середині multi-turn (мережа в 2-му турні)
- успішне завершення з 3 tool calls

**`scripts/sanity_test_task3_tooldefs.mjs`** — валідація definitions:
- усі tools мають required fields (name, description, input_schema)
- усі енам'и валідні (відповідають канонічній схемі)
- DOSSIER_AGENT_TOOLS синхронізований з PERMISSIONS.dossier_agent з App.jsx
- немає дублікатів name

**`scripts/sanity_test_task3_integration.mjs`** — інтеграційний:
- end-to-end з реальним tool definitions
- mock API response який повертає правдоподібний tool_use для add_hearing
- перевірити що executeAction викликався з правильними параметрами
- перевірити що ai_usage записався з правильним costUsd

### Запуск

```bash
node scripts/sanity_test_task3_basic.mjs
node scripts/sanity_test_task3_multiturn.mjs
node scripts/sanity_test_task3_tooldefs.mjs
node scripts/sanity_test_task3_integration.mjs
```

Усі мають проходити.

### Критерії приймання TASK 3.7
- 4 файли тестів створено
- Кожен покриває свій аспект
- Усі тести проходять

---

## SAAS IMPLICATIONS

Tool Use Foundation одразу готовий до multi-tenant:
- tenantId і userId передаються в context кожного виклику
- ai_usage пишеться з повними ідентифікаторами
- PERMISSIONS перевіряються через executeAction

Майбутні зміни:
- Pricing per tenant — закладається в costUsd
- Limits per tenant — окремий TASK через перевірку перед runToolUse
- Custom tools per tenant — окрема велика тема

---

## BILLING IMPLICATIONS

Кожен виклик агента досьє пише ai_usage з:
- agentId='dossier_agent'
- toolCalls counter
- Точний costUsd

Ці записи будуть основою для звітів. UI — Billing UI v1 (через 6+ міс).

---

## КОМІТ І ПУШ

```bash
git commit -m "feat: TASK 3 — Tool Use Foundation (toolDefinitions + toolUseRunner) + dossier agent migrated to native Tool Use"
git push origin main
```

GitHub Actions задеплоїть за 2-3 хвилини.

---

## ОЧІКУВАНІ АРТЕФАКТИ ВИКОНАННЯ

Створи файл звіту `report_task3.md` у корені репо.

### Структура файлу звіту

**Резюме TASK 3** — один абзац що зроблено

**Реалізація з TASK** — таблиця підзадач 3.1-3.7 зі статусом і file:line

**Створені файли** — таблиця з призначенням

**Змінені файли** — діапазони рядків і що додано

**Відхилення від TASK з обґрунтуванням** — якщо щось зробив інакше

**Знахідки** — посилання на discovered_issues_during_task3.md якщо створював

**Sanity-tests результати** — pass/fail для кожного файлу тестів

**Білд + push** — статус білду, коміт hash, push status

### Пояснення в термінал для адвоката

Після створення `report_task3.md` виведи в термінал зрозуміле людське пояснення для адвоката. Стиль як родичу що пояснюєш свою роботу. Без термінів типу "Tool Use", "tool_use блок", "API endpoint", "JSON Schema" — це все має лишитись у файлі звіту.

Що в поясненні:
- Що зробив простими словами
- Як це впливає на роботу системи (що тепер може чого не могла раніше)
- Чи все працює (тести, білд, кількість зелених перевірок)
- Що адвокату треба перевірити на сайті
- Куди зберігся детальний звіт

Приклад тону:

> Я заклав основу для нового способу спілкування агента-помічника із системою. Тепер коли ти пишеш агенту в досьє "додай засідання на 15 травня о 10 ранку", агент не пише про це текстом який система намагається розпарсити, а напряму викликає правильну дію через структурований механізм. Це надійніше, точніше, і дає змогу агенту виконувати кілька дій підряд.
>
> Що змінилось:
> - Агент досьє переведено на новий механізм. Решта агентів (Quick Input, Дашборд) працюють як раніше — вони стабільні, не чіпаємо.
> - Кожен виклик агента детально логується (скільки токенів, скільки tools, скільки коштує) — у майбутньому це буде в білінг-звітах.
>
> Чи все працює: так, всі автоматичні перевірки зелені (X тестів у Y файлах), білд проходить.
>
> Що тобі зробити: зайди на сайт після деплою, відкрий справу Кісельової, відкрий бічну панель агента, спробуй щось попросити (наприклад "додай засідання на наступний понеділок о 10 ранку"). Агент має додати засідання і відповісти підтвердженням.
>
> Повний технічний звіт — у файлі `report_task3.md` в корені репо. Завантаж його в адмін-чат щоб подивитись деталі.

---

## ВЛАСНА АНАЛІТИКА І ТВОРЧЕ ВИКОНАННЯ

Цей TASK закладає інфраструктуру яка буде використовуватись роками.

Якщо в процесі виявиш:
- Кращий спосіб організації коду → роби, поясни в коментарі
- Помилку в архітектурному рішенні → зупинись, опиши в `discovered_issues_during_task3.md`
- При інтеграції з агентом досьє щось ламається → з'ясуй причину перед коммітом
- Існуюча обгортка над fetch до Anthropic вже є — переюзовуй
- aiUsageService уже існує — адаптуйся під існуючу структуру

**Критерій якості:** код має бути таким щоб через 6 місяців хтось інший міг прочитати і зрозуміти за 10 хвилин що відбувається. Простота і ясність важливіші за хитрі абстракції.

Не вважай TASK дзвоном з небес. Перевіряй реальність коду. Адаптуйся.

---

**Кінець TASK 3.**
