# TASK 8 — Заміна `window.alert/confirm/prompt` і системних повідомлень на фірмові модалки + toast

**Дата формування:** 08.05.2026
**Фаза:** 1.6 — UI Reform (четвертий TASK)
**Виконавець:** Claude Code (Opus 4.7, 1M context)
**Орієнтовний обсяг:** 4-6 годин
**Передумови:** TASK 1-7 завершені і закомічені

---

## ПРИНЦИПИ ВИКОНАННЯ

**Творчо, виважено, охайно.** Цей TASK — не просто механічна заміна `window.confirm` на Modal. Це втілення двох ключових принципів архітектури з контекстного файлу:

**Принцип 1.2 "Агент не маскує проблеми"** — система не приховує помилки технічними повідомленнями, не виконує мовчки довгі операції. Завжди прозоро повідомляє адвокату що відбувається.

**Принцип 1.3 "Помилки людською мовою"** — жодних "system error", "code 422", "failed to fetch". Будь-яке повідомлення містить:
- Суть проблеми
- Можливі причини
- Варіанти вирішення
- Що пропонує система зробити

**Перевіряй перед змінами.** TASK 7 уже зачепив частину системних повідомлень. Спочатку зроби інвентар — скільки залишилось, де вони.

**Тести разом з кодом.** Кожна нова модалка/toast має тест. Кожна заміна `window.confirm` має оновлений тест якщо існував.

**SaaS-готовність.** Не зачіпає прямо, але уніфіковані повідомлення легше локалізуються в майбутньому (одна точка зміни замість десятків `setContextMsg`).

**Без тимчасових рішень.** Не лиши `// TODO replace this confirm later` — заміни одразу.

---

## КОНТЕКСТ

### Поточний стан (з TASK 7 знахідок)

**SystemModal вже існує** — використовується через функції `systemConfirm`, `systemAlert`. Перевір актуальне розташування — імовірно `src/components/SystemModal.jsx` або в `App.jsx`.

**Що ще не мігровано** (3 категорії):

**Категорія А: `window.alert` / `window.confirm` / `window.prompt`** — стандартні браузерні діалоги. Виглядають як системні віконечка ОС, не вписуються в дизайн системи. Знаходимо через grep і замінюємо.

**Категорія Б: `setContextMsg('❌ Не вдалось зберегти')` / `setContextMsg('✅ Готово')`** — це **toast-style повідомлення** (короткі статусні нотатки які зникають). Зараз вони рендеряться як emoji-префікс + текст. Треба замінити на структуровані Toast компоненти (новий компонент який створимо).

**Категорія В: Inline `<div>` з повідомленнями** — окремі попередження вшиті в JSX (`⚠️ Без папки`, `❌ Неправильний формат`). Деякі вже мігровано в TASK 7 на lucide-іконки. Залишок — переробити на Banner компонент (новий).

### Поточний flow помилок (з діагностики)

Зараз помилки в чаті агента приходять як:
- `⚠️ Помилка ${status}` — assistant message в історії
- `⚠️ Мережева помилка: ${err.message}` — те саме
- `setErrorCategory('llm_failed')` — ставиться флаг
- `❌ API помилка ${status}` — у Dashboard

Це механічно: технічна помилка → текст з emoji. Треба переробити на структуровані повідомлення.

### Що з цього випливає

TASK 8 розбивається на 6 підзадач:

- **8.1** — Інвентар: повний список усіх `window.alert/confirm/prompt`, `setContextMsg`, inline-повідомлень
- **8.2** — Створити Toast компонент (для коротких статусних повідомлень)
- **8.3** — Створити Banner компонент (для inline-попереджень всередині секцій)
- **8.4** — Створити словник стандартних повідомлень (`src/services/messages.js`) — централізоване місце де записані фрази
- **8.5** — Міграція в CaseDossier (всі точки)
- **8.6** — Тести і документація

---

## TASK 8.1 — Інвентар повідомлень

### Знайти всі точки

```bash
# window.alert/confirm/prompt
grep -rn "window\.alert\|window\.confirm\|window\.prompt" src/

# Системні модалки (для перевірки що мігровано)
grep -rn "systemConfirm\|systemAlert" src/

# Toast-style повідомлення
grep -rn "setContextMsg\|showMsg\|setErrorMsg" src/

# Emoji-префікси у setContextMsg
grep -rn "setContextMsg('❌\|setContextMsg('✅\|setContextMsg('⚠" src/

# Inline помилки у JSX
grep -rn '"⚠️\|"❌\|"✅' src/components/CaseDossier/index.jsx
```

### Створи тимчасовий audit-файл

`_temp_messages_audit.md` — таблиця що знайдено:

```markdown
## CaseDossier messages inventory

### Категорія А: window.* діалоги
| Рядок | Виклик | Контекст | Заміна |
|-------|--------|----------|--------|
| 745   | window.confirm("Очистити історію?") | clearAgentHistory | systemConfirm з Modal |
| 1234  | window.alert("Файл занадто великий") | uploadFile | Toast danger |

### Категорія Б: setContextMsg toast-style
| Рядок | Текст | Тип | Заміна |
|-------|-------|-----|--------|
| 567   | "❌ Не вдалось зберегти на Drive" | error | toast({ variant: 'error', title: '...' }) |
| 612   | "✅ Контекст створено" | success | toast({ variant: 'success', ... }) |
| 789   | "⏳ Завантаження..." | progress | toast({ variant: 'info', persistent: true }) |

### Категорія В: Inline JSX повідомлення
| Рядок | Контекст | Заміна |
|-------|----------|--------|
| 1456  | div "⚠️ Без папки" | Banner warning |
| 1678  | div "❌ Не вдалось підключитись" | Banner danger |

### Залишити як є (поза scope)
| Рядок | Причина |
|-------|---------|
| 2225 | placeholder mock-кнопки (TASK 9 переписуватиме) |
```

### Критерії приймання TASK 8.1

- Інвентар повний, кожна точка класифікована
- Сумнівні випадки винесено в розділ "обговорити"

---

## TASK 8.2 — Toast компонент

### Призначення

Короткі статусні повідомлення які з'являються знизу/зверху екрану і автоматично зникають через кілька секунд. Аналог браузерних snackbar/toast.

### Файли

- `src/components/UI/Toast.jsx`
- `src/components/UI/Toast.css`
- `src/components/UI/ToastContainer.jsx` — контейнер на верхньому рівні
- `src/services/toast.js` — імперативний API (`toast.success(...)`, `toast.error(...)`)

### Архітектура

Toast використовується **імперативно** — з будь-якого місця коду викликаєш `toast.success('Збережено')` і toast з'являється. Не треба передавати state через props.

Реалізація через event emitter або через React Context з провайдером на верхньому рівні App.jsx.

### Реалізація сервісу

```javascript
// src/services/toast.js

const subscribers = new Set();
let nextId = 1;

/**
 * Імперативне API toast-повідомлень.
 * 
 * Використання:
 *   import { toast } from '../services/toast.js';
 *   
 *   toast.success('Документ збережено');
 *   toast.error('Не вдалось зв'язатись з Drive', {
 *     description: 'Перевірте підключення',
 *     duration: 5000
 *   });
 *   toast.info('Обробка PDF...', { persistent: true });
 *   toast.dismiss(toastId);  // ручне закриття persistent
 * 
 * Принципи (з контекстного файлу 1.3):
 * - title: коротко суть (3-5 слів)
 * - description: причина і пропозиція дії (1 речення)
 * - action: опціональна кнопка ("Спробувати ще", "Налаштування Drive")
 */

export const toast = {
  success(title, options = {}) {
    return show({ variant: 'success', title, ...options });
  },
  
  error(title, options = {}) {
    return show({ variant: 'error', title, ...options });
  },
  
  warning(title, options = {}) {
    return show({ variant: 'warning', title, ...options });
  },
  
  info(title, options = {}) {
    return show({ variant: 'info', title, ...options });
  },
  
  dismiss(id) {
    subscribers.forEach(fn => fn({ type: 'dismiss', id }));
  }
};

function show({ variant, title, description, action, duration, persistent }) {
  const id = nextId++;
  const message = {
    id,
    variant,
    title,
    description,
    action,
    duration: duration ?? (variant === 'error' ? 6000 : 3500),
    persistent: persistent ?? false,
    createdAt: Date.now()
  };
  
  subscribers.forEach(fn => fn({ type: 'add', message }));
  return id;
}

// Внутрішнє API для ToastContainer
export function subscribeToToasts(fn) {
  subscribers.add(fn);
  return () => subscribers.delete(fn);
}
```

### Реалізація компонента

```jsx
// src/components/UI/Toast.jsx
import { CheckCircle, AlertCircle, AlertTriangle, Info, X } from 'lucide-react';
import './Toast.css';

const VARIANT_ICONS = {
  success: CheckCircle,
  error: AlertCircle,
  warning: AlertTriangle,
  info: Info
};

/**
 * Toast — одне повідомлення.
 * 
 * Props:
 * - variant: 'success' | 'error' | 'warning' | 'info'
 * - title: короткий текст
 * - description: опціональний детальний опис
 * - action: { label, onClick }  — опціональна кнопка дії
 * - onDismiss: function
 */
export function Toast({ variant, title, description, action, onDismiss }) {
  const Icon = VARIANT_ICONS[variant] || Info;
  
  return (
    <div className={`ui-toast ui-toast--${variant}`} role="alert">
      <Icon className="ui-toast__icon" size={20} />
      <div className="ui-toast__content">
        <div className="ui-toast__title">{title}</div>
        {description && <div className="ui-toast__description">{description}</div>}
        {action && (
          <button
            className="ui-toast__action"
            onClick={() => { action.onClick(); onDismiss?.(); }}
          >
            {action.label}
          </button>
        )}
      </div>
      <button
        className="ui-toast__close"
        onClick={onDismiss}
        aria-label="Закрити"
      >
        <X size={14} />
      </button>
    </div>
  );
}
```

### Реалізація контейнера

```jsx
// src/components/UI/ToastContainer.jsx
import { useEffect, useState } from 'react';
import { Toast } from './Toast.jsx';
import { subscribeToToasts } from '../../services/toast.js';
import './Toast.css';

export function ToastContainer() {
  const [toasts, setToasts] = useState([]);
  
  useEffect(() => {
    return subscribeToToasts(({ type, message, id }) => {
      if (type === 'add') {
        setToasts(prev => [...prev, message]);
        if (!message.persistent) {
          setTimeout(() => {
            setToasts(prev => prev.filter(t => t.id !== message.id));
          }, message.duration);
        }
      } else if (type === 'dismiss') {
        setToasts(prev => prev.filter(t => t.id !== id));
      }
    });
  }, []);
  
  const dismiss = (id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };
  
  if (toasts.length === 0) return null;
  
  return (
    <div className="ui-toast-container">
      {toasts.map(t => (
        <Toast
          key={t.id}
          variant={t.variant}
          title={t.title}
          description={t.description}
          action={t.action}
          onDismiss={() => dismiss(t.id)}
        />
      ))}
    </div>
  );
}
```

### CSS

```css
/* Toast.css */

.ui-toast-container {
  position: fixed;
  bottom: var(--space-6);
  right: var(--space-6);
  z-index: var(--z-toast);
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  max-width: 420px;
}

.ui-toast {
  display: flex;
  align-items: flex-start;
  gap: var(--space-3);
  padding: var(--space-3) var(--space-4);
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-left-width: 3px;
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-md);
  animation: ui-toast-slide-in 0.2s ease;
}

@keyframes ui-toast-slide-in {
  from { transform: translateX(100%); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
}

.ui-toast--success { border-left-color: var(--color-success); }
.ui-toast--success .ui-toast__icon { color: var(--color-success); }

.ui-toast--error { border-left-color: var(--color-danger); }
.ui-toast--error .ui-toast__icon { color: var(--color-danger); }

.ui-toast--warning { border-left-color: var(--color-warning); }
.ui-toast--warning .ui-toast__icon { color: var(--color-warning); }

.ui-toast--info { border-left-color: var(--color-accent); }
.ui-toast--info .ui-toast__icon { color: var(--color-accent); }

.ui-toast__icon {
  flex-shrink: 0;
  margin-top: 2px;
}

.ui-toast__content {
  flex: 1;
  min-width: 0;
}

.ui-toast__title {
  font-size: var(--text-sm);
  font-weight: var(--weight-semibold);
  color: var(--color-text);
  line-height: var(--leading-tight);
}

.ui-toast__description {
  font-size: var(--text-xs);
  color: var(--color-text-2);
  margin-top: var(--space-1);
  line-height: var(--leading-normal);
}

.ui-toast__action {
  background: transparent;
  border: none;
  color: var(--color-accent);
  font-size: var(--text-xs);
  font-weight: var(--weight-medium);
  margin-top: var(--space-2);
  padding: 0;
  cursor: pointer;
}
.ui-toast__action:hover {
  text-decoration: underline;
}

.ui-toast__close {
  background: transparent;
  border: none;
  color: var(--color-text-3);
  cursor: pointer;
  padding: 0;
  margin-top: 2px;
}
.ui-toast__close:hover {
  color: var(--color-text);
}
```

### Підключити ToastContainer на верхньому рівні

В `App.jsx` додай у JSX (краще на самому верху, поруч з основним layout):

```jsx
import { ToastContainer } from './components/UI/ToastContainer.jsx';

// в return App:
<>
  <ToastContainer />
  {/* решта layout */}
</>
```

### Критерії приймання TASK 8.2

- Toast.jsx + ToastContainer.jsx + toast.js створено
- API `toast.success/error/warning/info` працює
- ToastContainer підключено в App.jsx
- Імперативний виклик з будь-якого місця коду показує toast
- Auto-dismiss через duration працює
- persistent: true тримає toast до ручного закриття
- action кнопка викликається і закриває toast

---

## TASK 8.3 — Banner компонент

### Призначення

Inline-попередження всередині секцій. На відміну від Toast — не зникає автоматично, прив'язаний до місця в UI.

Приклад використання: на вкладці "Огляд" вгорі може бути Banner "⚠ Категорія справи не визначена" — поки адвокат не виправить, banner лишається.

### Файли

- `src/components/UI/Banner.jsx`
- `src/components/UI/Banner.css`

### Реалізація

```jsx
import { CheckCircle, AlertCircle, AlertTriangle, Info, X } from 'lucide-react';
import { Button } from './Button.jsx';
import './Banner.css';

const VARIANT_ICONS = {
  success: CheckCircle,
  error: AlertCircle,
  warning: AlertTriangle,
  info: Info
};

/**
 * Banner — inline-попередження в межах секції.
 * 
 * Props:
 * - variant: 'success' | 'error' | 'warning' | 'info'
 * - title: короткий заголовок
 * - description: опціональний опис
 * - actions: опціональний масив кнопок [{ label, onClick, variant? }]
 * - dismissible: boolean — показує × для закриття
 * - onDismiss: function
 */
export function Banner({ variant = 'info', title, description, actions, dismissible, onDismiss }) {
  const Icon = VARIANT_ICONS[variant] || Info;
  
  return (
    <div className={`ui-banner ui-banner--${variant}`} role="status">
      <Icon className="ui-banner__icon" size={18} />
      <div className="ui-banner__content">
        <div className="ui-banner__title">{title}</div>
        {description && <div className="ui-banner__description">{description}</div>}
        {actions && actions.length > 0 && (
          <div className="ui-banner__actions">
            {actions.map((a, i) => (
              <Button
                key={i}
                variant={a.variant || 'secondary'}
                size="sm"
                onClick={a.onClick}
              >
                {a.label}
              </Button>
            ))}
          </div>
        )}
      </div>
      {dismissible && (
        <button
          className="ui-banner__close"
          onClick={onDismiss}
          aria-label="Закрити"
        >
          <X size={14} />
        </button>
      )}
    </div>
  );
}
```

### CSS

```css
.ui-banner {
  display: flex;
  align-items: flex-start;
  gap: var(--space-3);
  padding: var(--space-3) var(--space-4);
  border-radius: var(--radius-md);
  border-left: 3px solid;
}

.ui-banner--success {
  background: rgba(34, 197, 94, 0.08);
  border-left-color: var(--color-success);
}
.ui-banner--success .ui-banner__icon { color: var(--color-success); }

.ui-banner--error {
  background: rgba(239, 68, 68, 0.08);
  border-left-color: var(--color-danger);
}
.ui-banner--error .ui-banner__icon { color: var(--color-danger); }

.ui-banner--warning {
  background: rgba(245, 158, 11, 0.08);
  border-left-color: var(--color-warning);
}
.ui-banner--warning .ui-banner__icon { color: var(--color-warning); }

.ui-banner--info {
  background: rgba(59, 130, 246, 0.08);
  border-left-color: var(--color-accent);
}
.ui-banner--info .ui-banner__icon { color: var(--color-accent); }

.ui-banner__icon {
  flex-shrink: 0;
  margin-top: 2px;
}

.ui-banner__content {
  flex: 1;
  min-width: 0;
}

.ui-banner__title {
  font-size: var(--text-sm);
  font-weight: var(--weight-semibold);
  color: var(--color-text);
}

.ui-banner__description {
  font-size: var(--text-xs);
  color: var(--color-text-2);
  margin-top: var(--space-1);
}

.ui-banner__actions {
  display: flex;
  gap: var(--space-2);
  margin-top: var(--space-3);
}

.ui-banner__close {
  background: transparent;
  border: none;
  color: var(--color-text-3);
  cursor: pointer;
  padding: 0;
}
.ui-banner__close:hover { color: var(--color-text); }
```

### Експортувати з index.js

```javascript
export { Toast } from './Toast.jsx';
export { ToastContainer } from './ToastContainer.jsx';
export { Banner } from './Banner.jsx';
```

### Критерії приймання TASK 8.3

- Banner.jsx + Banner.css створено
- 4 варіанти працюють
- Опціональні actions і dismissible
- Експортовано з UI index.js

---

## TASK 8.4 — Словник стандартних повідомлень

### Файл `src/services/messages.js`

Централізоване місце для часто використовуваних фраз. Принцип: якщо помилка може виникнути в кількох місцях — її текст пишеться один раз тут.

```javascript
/**
 * Стандартні повідомлення системи.
 * 
 * Принципи (з контекстного файлу 1.3 "Помилки людською мовою"):
 * - Жодних "system error", "code 422", "failed to fetch"
 * - Кожне повідомлення містить: суть / причину / пропозицію дії
 * - title — коротко (3-5 слів)
 * - description — пояснення (1 речення)
 * - action — опціональна кнопка вирішення
 */

export const messages = {
  // ============================================================
  // DRIVE
  // ============================================================
  drive: {
    notConnected: () => ({
      title: 'Drive не підключено',
      description: 'Підключіть Google Drive у налаштуваннях щоб зберігати документи.',
      action: { label: 'Налаштування' }  // onClick передається в місці виклику
    }),
    
    tokenExpired: () => ({
      title: 'Сесія Drive завершилась',
      description: 'Перепідключіть Google Drive — токен авторизації застарів.',
      action: { label: 'Перепідключити' }
    }),
    
    saveFailed: (filename) => ({
      title: 'Не вдалось зберегти на Drive',
      description: filename 
        ? `Файл "${filename}" не завантажено. Перевірте підключення і спробуйте знову.`
        : 'Перевірте підключення до Drive і спробуйте знову.',
      action: { label: 'Спробувати ще' }
    }),
    
    fileNotFound: (filename) => ({
      title: 'Файл не знайдено на Drive',
      description: `Файл "${filename}" видалено або переміщено вручну. Можна оновити реєстр через Перевірку цілісності.`
    }),
    
    folderMissing: (caseName) => ({
      title: 'Папка справи не існує на Drive',
      description: `Для справи "${caseName}" немає папки. Створити структуру папок зараз?`,
      action: { label: 'Створити' }
    })
  },
  
  // ============================================================
  // API (Anthropic / агенти)
  // ============================================================
  api: {
    networkError: () => ({
      title: 'Не вдалось зв\'язатись з агентом',
      description: 'Перевірте інтернет-з\'єднання і спробуйте ще раз.'
    }),
    
    rateLimit: () => ({
      title: 'Забагато запитів',
      description: 'Зачекайте хвилину перед наступним повідомленням до агента.'
    }),
    
    apiKeyInvalid: () => ({
      title: 'Перевірте API ключ',
      description: 'API ключ Claude недійсний або застарів. Оновіть у налаштуваннях.',
      action: { label: 'Налаштування' }
    }),
    
    serverError: () => ({
      title: 'Сервіс тимчасово недоступний',
      description: 'Анropic API не відповідає. Спробуйте за хвилину.'
    })
  },
  
  // ============================================================
  // ДОКУМЕНТИ
  // ============================================================
  documents: {
    saved: () => ({
      title: 'Документ збережено',
      variant: 'success'
    }),
    
    deleted: (mode) => {
      const descriptions = {
        full: 'Документ видалено з реєстру і з Drive.',
        registry_only: 'Документ видалено з реєстру. Файл залишився на Drive як архівна копія.',
        archive: 'Документ архівовано. Можна повернути через перемикач "Показати архівні".'
      };
      return {
        title: 'Документ видалено',
        description: descriptions[mode] || descriptions.full,
        variant: 'success'
      };
    },
    
    uploadFailed: (filename) => ({
      title: `Не вдалось додати "${filename}"`,
      description: 'Перевірте розмір файлу і формат. Підтримуються PDF, DOCX, зображення.'
    }),
    
    fileTooLarge: (filename, maxMb) => ({
      title: 'Файл занадто великий',
      description: `"${filename}" перевищує ліміт ${maxMb} МБ. Стисніть або розділіть на частини.`
    })
  },
  
  // ============================================================
  // ПРОВАДЖЕННЯ
  // ============================================================
  proceedings: {
    deleteWarning: (procName, docCount) => ({
      title: `Видалити провадження "${procName}"?`,
      description: docCount > 0
        ? `У провадженні ${docCount} документів. Вони не видаляться, але стануть "без провадження" з маркером ⚠.`
        : 'У провадженні немає документів. Видалити?',
      variant: 'warning'
    }),
    
    deleted: (procName, affectedDocs) => ({
      title: `Провадження "${procName}" видалено`,
      description: affectedDocs > 0 
        ? `${affectedDocs} документів стали "без провадження".`
        : null,
      variant: 'success'
    })
  },
  
  // ============================================================
  // СПРАВА
  // ============================================================
  case: {
    closeConfirm: (caseName) => ({
      title: `Закрити справу "${caseName}"?`,
      description: 'Активні засідання і дедлайни лишаться видимими. Справа переміститься в архів.',
      variant: 'warning'
    }),
    
    deleteConfirm: (caseName) => ({
      title: `Видалити справу "${caseName}" повністю?`,
      description: 'Видаляться всі дані справи і папка на Drive. Цю дію НЕМОЖЛИВО скасувати.',
      variant: 'error'
    }),
    
    saved: () => ({
      title: 'Справу збережено',
      variant: 'success'
    })
  }
};
```

### Як використовувати

```javascript
import { toast } from '../services/toast.js';
import { messages } from '../services/messages.js';

// Замість window.alert('Не вдалось зберегти на Drive')
toast.error(messages.drive.saveFailed(filename).title, {
  description: messages.drive.saveFailed(filename).description,
  action: {
    label: messages.drive.saveFailed(filename).action.label,
    onClick: () => retryUpload(filename)
  }
});

// Або скорочено через хелпер:
import { showMessage } from '../services/toast.js';
showMessage('error', messages.drive.saveFailed(filename), { onAction: () => retryUpload(filename) });
```

Можеш зробити такий хелпер `showMessage` в `toast.js` для зменшення повторюваності.

### Критерії приймання TASK 8.4

- `messages.js` створено зі стандартними фразами
- Кожне повідомлення містить title + description (де релевантно) + action (де релевантно)
- Немає технічного жаргону ("HTTP 429", "JSON parse error")
- Українська мова
- Шаблонні повідомлення приймають параметри (filename, caseName)

---

## TASK 8.5 — Міграція в CaseDossier

### Принцип

Йди за інвентарем з TASK 8.1. Кожну точку замінюй за категорією:

**Категорія А (window.* діалоги):**
- Простий confirm → `systemConfirm` з Modal (вже існує)
- Довгий діалог з кількома варіантами → нова Modal з декількома Button у actions

**Категорія Б (setContextMsg toast):**
- `setContextMsg('❌ ...')` → `toast.error(...)`
- `setContextMsg('✅ ...')` → `toast.success(...)`
- `setContextMsg('⏳ ...')` → `toast.info(..., { persistent: true })` + `toast.dismiss()` коли закінчилось
- `setContextMsg('⚠️ ...')` → `toast.warning(...)`

**Категорія В (inline JSX повідомлення):**
- Постійні попередження → Banner
- Стани закриваються адвокатом → Banner з dismissible

### Приклад заміни

**Було:**
```javascript
const handleSave = async () => {
  setContextMsg('⏳ Збереження...');
  try {
    await saveToDrive(data);
    setContextMsg('✅ Збережено');
  } catch (err) {
    setContextMsg('❌ Не вдалось зберегти: ' + err.message);
  }
};
```

**Стало:**
```javascript
import { toast } from '../../services/toast.js';
import { messages } from '../../services/messages.js';

const handleSave = async () => {
  const progressId = toast.info('Збереження...', { persistent: true });
  try {
    await saveToDrive(data);
    toast.dismiss(progressId);
    toast.success(messages.documents.saved().title);
  } catch (err) {
    toast.dismiss(progressId);
    const msg = messages.drive.saveFailed(filename);
    toast.error(msg.title, {
      description: msg.description,
      action: { label: msg.action.label, onClick: handleSave }
    });
    console.error('Save failed:', err);  // технічна деталь — у консолі для діагностики
  }
};
```

Зверни увагу:
- Технічну помилку (`err.message`) НЕ показуєм адвокату — залишаємо в console.error для діагностики
- Адвокат бачить дружнє повідомлення з пропозицією дії ("Спробувати ще")
- Прогрес-toast persistent, явно закривається при завершенні

### Можливе видалення setContextMsg

Якщо `setContextMsg` був state/setter для inline-повідомлення внизу екрану, і всі його використання мігровано на toast — можна видалити сам state. Перевір що ніщо більше не залежить.

### Критерії приймання TASK 8.5

- Усі точки з інвентаря TASK 8.1 мігровано
- `window.alert/confirm/prompt` не залишилось у CaseDossier
- `setContextMsg` з emoji-префіксами не залишилось (або setContextMsg видалено повністю якщо не потрібен)
- Тести які тестували старі повідомлення оновлено
- Білд чистий

---

## TASK 8.6 — Тести і документація

### Тести

**`tests/unit/Toast.test.jsx`** — 6-8 тестів:
- Рендериться з title
- Описує variant через клас
- Викликає onDismiss при кліку на ×
- Action кнопка викликається і закриває
- 4 варіанти з різними іконками

**`tests/unit/Banner.test.jsx`** — 5-7 тестів:
- Рендериться з title і description
- Variant клас застосовується
- Actions рендеряться як Button
- Dismissible × показується тільки коли треба
- onDismiss викликається

**`tests/unit/toast-service.test.js`** — 5-7 тестів:
- toast.success/error/warning/info генерують правильний variant
- Кожен виклик повертає унікальний id
- subscribeToToasts отримує події
- toast.dismiss(id) генерує dismiss подію

**`tests/integration/messages.test.js`** — 5 тестів:
- messages.drive.saveFailed повертає валідну структуру
- Параметри (filename) підставляються в description
- Усі повідомлення мають title (мінімум)
- Жодне не містить технічного жаргону (regex check на "error", "failed", "code")

### Видалити тимчасовий audit-файл

Після завершення міграції видали `_temp_messages_audit.md`.

### Оновити README.md

Додай у `src/components/UI/README.md` секції для Toast і Banner з прикладами.

### Створи `src/services/messages.md`

Документація як використовувати словник повідомлень:

```markdown
# Стандартні повідомлення системи

## Призначення

Централізоване місце для текстів повідомлень користувачу. Замість inline-рядків — використовуй `messages.<категорія>.<подія>`.

## Принципи

1. **Без технічного жаргону.** Замість "HTTP 429" — "Забагато запитів".
2. **Структура повідомлення:** title (3-5 слів) + description (1 речення) + action (опціонально).
3. **Українська мова.**
4. **Параметризовані функції** для динамічних значень (filename, caseName).

## Як використовувати

[приклад коду]

## Як додавати нові повідомлення

[інструкція]
```

### Критерії приймання TASK 8.6

- 4 файли тестів створено, всі зелені
- README оновлено
- messages.md створено
- audit-файл видалено

---

## SAAS IMPLICATIONS

Централізований словник повідомлень готує до локалізації — у майбутньому при додаванні англійської мови треба буде перекласти один файл `messages.js`, не сотні рядків по всьому коду.

Toast/Banner компоненти параметризовані через CSS-змінні — темізація для тенанта працюватиме.

---

## BILLING IMPLICATIONS

Не зачіпає. Опосередковано — зрозумілі повідомлення про помилки = менше дзвінків у підтримку = нижчі operational costs.

---

## КОМІТ І ПУШ

```bash
git commit -m "feat: TASK 8 — replace window.alert/confirm/prompt and emoji-prefixed setContextMsg with branded Toast/Banner/Modal + centralized messages dictionary"
git push origin main
```

---

## ОЧІКУВАНІ АРТЕФАКТИ ВИКОНАННЯ

Створи файл звіту `report_task8.md` у корені репо.

### Структура звіту

**Резюме TASK 8** — один абзац

**Реалізація з TASK** — таблиця 8.1-8.6

**Підрахунок міграцій:**

| Категорія | Знайдено | Мігровано | Залишено (поза scope) |
|-----------|---------|-----------|------------------------|
| window.alert | N | N | 0 |
| window.confirm | M | M | 0 |
| window.prompt | K | K | 0 |
| setContextMsg('❌...') | X | X | 0 |
| setContextMsg('✅...') | Y | Y | 0 |
| Inline JSX warnings | Z | Z | 0 |

**Створені файли:** Toast.jsx, ToastContainer.jsx, Banner.jsx, toast.js, messages.js, messages.md, тести

**Змінені файли:** CaseDossier/index.jsx (з діапазонами), App.jsx (підключення ToastContainer), index.js, README.md

**Відхилення від TASK** — якщо щось зробив інакше

**Знахідки** — discovered_issues_during_task8.md якщо є

**Тести і білд**

### Пояснення в термінал для адвоката

Стиль як родичу. Без термінів "Toast", "Banner", "API". Адвокат хоче зрозуміти результат і вплив.

Приклад тону:

> Я переробив повідомлення системи. Раніше коли щось ішло не так, ти бачив рядки з emoji як "❌ Не вдалось зберегти" або стандартне браузерне віконечко "Видалити справу? OK / Cancel". Тепер усе оформлено в фірмовому стилі.
>
> Що змінилось:
> - **Швидкі повідомлення** (збережено / помилка / попередження) тепер з'являються справа знизу як акуратні картки, автоматично зникають через 3-6 секунд.
> - **Підтвердження дій** (видалити справу, закрити справу) — у фірмових модалках з чітким описом наслідків замість стандартного браузерного віконечка.
> - **Постійні попередження** (наприклад "Drive не підключено") — як inline-плашки в інтерфейсі, з кнопкою рішення.
>
> Принципи нових повідомлень:
> - Замість технічного "HTTP 429" пишемо "Забагато запитів" + пропозицію "зачекайте хвилину".
> - Кожне повідомлення має суть і пропозицію дії (де треба).
> - Технічні деталі помилок лишаються в консолі для розробника, але адвокат їх не бачить.
>
> Чи все працює: тести зелені, білд чистий.
>
> Що тобі зробити: спробуй на сайті після деплою — натисни "Закрити справу" в досьє, спробуй видалити нотатку, побачиш нові модалки. Якщо буде перетягувати файли — побачиш повідомлення про результат справа знизу.
>
> Деталі — у `report_task8.md`.

---

## ВЛАСНА АНАЛІТИКА І ТВОРЧЕ ВИКОНАННЯ

Якщо в процесі знайдеш:
- Повідомлення які важко класифікувати (toast чи banner чи modal) — порадься з контекстом, зафіксуй сумнівні випадки в `discovered_issues_during_task8.md`
- `setContextMsg` використовується не тільки для повідомлень але і для іншого state → не видаляй state, тільки забери з нього emoji-логіку
- Виклик з іншого модуля (DocumentProcessor, Notebook) → НЕ чіпай, фіксуй як майбутній TASK
- SystemModal і systemConfirm/systemAlert вже існують і добре працюють → переюзовуй їх, не дублюй логіку

**Критерій якості:** адвокат після TASK 8 бачить професійні повідомлення з пропозиціями дії замість технічного жаргону. Жоден alert не виглядає як "помилка системи", всі помилки виглядають як "ось що сталось і ось що можна зробити".

Не вважай TASK дзвоном з небес. Адаптуйся.

---

**Кінець TASK 8.**
