# TASK 2 — ACTIONS реєстр документів/проваджень + PERMISSIONS для агентів

**Дата формування:** 08.05.2026
**Фаза:** 1.5 (Канон даних і ACTIONS) — другий TASK
**Виконавець:** Claude Code (Opus 4.7, 1M context)
**Орієнтовний обсяг:** 5-8 годин
**Передумови:** TASK 1 завершений і закомічений (canonical schema + factory + extended + v4→v5 migration)

---

## ПРИНЦИПИ ВИКОНАННЯ

**Творчо і виважено.** Цей TASK торкається критичної інфраструктури — реєстру ACTIONS і матриці PERMISSIONS. Будь-яка помилка тут блокує функціонал агентів. Перевіряй усе двічі.

**Перевіряй перед змінами.** Перед редагуванням — `view` файлу. Номери рядків з TASK можуть бути неточними після TASK 1 patch (drag-n-drop creates document) — реальний код пріоритетніший. Шукай по контексту (назвах функцій, ключових словах).

**Користуйся діагностикою.** В репо є `diagnostic_report_2026-05-07.md`. Особливо корисні розділи 1.4 (PERMISSIONS) і 1.6 (ACTIONS). Звіртайся при сумнівах. Згадай, що діагностика від 07.05.2026, а зараз 08.05.2026 і вже виконані TASK 1 + TASK 1 patch — деякі точки в коді змістилися.

**Документація йде разом з кодом.** Якщо щось у CLAUDE.md в зачеплених розділах застаріло — додай в кінець існуючого файлу `recommended_task_claude_md_audit.md` нову секцію "TASK 2 — ACTIONS і PERMISSIONS зміни" з конкретними рекомендаціями. Не оновлюй CLAUDE.md в цьому TASK — окремий TASK CLAUDE.md Audit на майбутнє.

**SaaS-готовність.** ACTIONS і PERMISSIONS — це базис для майбутнього multi-user. Кожен ACTION має потенційно перевірятись через `checkRolePermission` (зараз заглушка повертає true для всіх). Закладай поля які знадобляться.

**Без тимчасових рішень.** TASK 1 patch ввів тимчасовий обхід через `update_case_field('documents', [...])` для drag-n-drop. Цей TASK його закриває чисто.

---

## КОНТЕКСТ

### Архітектурні рішення (з `dossier_architecture_decisions.md`)

**ACTIONS + executeAction архіваріус-патерн** (з `context_dossier_session_2026-05-07_v1_1.md` пункт 1.1):

> Усі зміни даних справи проходять через `executeAction`. Document Processor не пише в `caseData.documents[]` напряму. DP — субагент агента досьє.

**Дозволи в PERMISSIONS:**
- `dossier_agent` — `add_document`, `update_document`, `add_proceeding`, `update_proceeding`, `update_processing_context`, плюс існуючі (notes/hearings/deadlines)
- `document_processor_agent` — `add_documents`, `update_processing_context`. Заборонено: `destroy_case`, hearings/deadlines (не його зона)
- `qi_agent` — `add_document` (одиничне додавання при QI-команді)
- `dashboard_agent` — без нових дозволів (документи не його зона)

**Заборонено всім агентам** (тільки UI з підтвердженням):
- `delete_document` — мають mode `full | registry_only | archive`
- `delete_proceeding` — каскадно обнуляє procId документів
- `destroy_case` — вже існуюче правило

### Поточний стан (з `diagnostic_report_2026-05-07.md`)

**ACTIONS реєстр** — 30 ключів у `App.jsx:4558-5165`. `add_document`, `add_documents`, `update_document`, `delete_document`, `update_processing_context`, `add_proceeding`, `update_proceeding`, `delete_proceeding` — **всі відсутні**.

**PERMISSIONS** — у `App.jsx:5168-5209` три агенти: `qi_agent`, `dashboard_agent`, `dossier_agent`. `document_processor_agent` — **відсутній**.

**executeAction** — у `App.jsx:5216-5304`. Сигнатура `(agentId, action, params, userId)`. Послідовність перевірок: PERMISSIONS allowlist → ACTIONS exists → checkTenantAccess → checkRolePermission (заглушка) → checkCaseAccess → виклик ACTIONS[action] → AuditLog якщо `shouldAudit(action)` → activityTracker.

**`destroy_case`** — відсутній у ACTIONS, реалізований як UI-only через `deleteCasePermanently` (`App.jsx:5208`). Перевір чи додалось щось в TASK 1 — імовірно ні.

**audit_actions.md** — є комплементарний документ з переліком audit-able actions.

**`requireUI: true`** — патерн позначення дій тільки для UI. Перевір чи зараз він якось використовується чи це тільки документація.

### Що з цього випливає

Робота розбивається на 6 підзадач:
- **TASK 2.1.** Додати `add_document` ACTION (одиничне додавання, для drag-n-drop)
- **TASK 2.2.** Додати `add_documents` ACTION (batch для DP, замінює тимчасовий update_case_field)
- **TASK 2.3.** Додати `update_document` ACTION (зміна полів документа)
- **TASK 2.4.** Додати `delete_document` ACTION з трьома режимами + `requireUI: true`
- **TASK 2.5.** Додати `add_proceeding`, `update_proceeding`, `delete_proceeding` ACTIONS
- **TASK 2.6.** Додати `update_processing_context` ACTION (для DP після обробки)
- **TASK 2.7.** Розширити PERMISSIONS — додати `document_processor_agent` + нові дії в існуючі ролі
- **TASK 2.8.** Замінити тимчасовий обхід з drag-n-drop патча на чистий `add_document`
- **TASK 2.9.** Перевірити що executeAction коректно валідує всі нові дії

Виконуй послідовно. Між підзадачами — швидкий sanity-check (білд проходить, sanity-tests).

---

## TASK 2.1 — ACTION `add_document`

### Знайди реєстр ACTIONS

`view` `src/App.jsx` навколо рядків 4558-5165. Знайди структуру:

```javascript
const ACTIONS = {
  create_case: async (params) => { ... },
  close_case: async (params) => { ... },
  // ...
};
```

### Додай новий ACTION

Розташування: де логічно — поряд з іншими "add_*" діями (orient на add_note, add_hearing). Приблизно після `delete_hearing` або перед `add_note`.

```javascript
add_document: async (params) => {
  // params: { caseId, document } 
  // document — повний об'єкт після createDocument()
  
  if (!params.caseId) {
    return { success: false, error: 'caseId обов'язковий' };
  }
  if (!params.document) {
    return { success: false, error: 'document обов'язковий' };
  }
  
  // Валідація через validateDocument
  const { valid, errors } = validateDocument(params.document);
  if (!valid) {
    return { success: false, error: `Невалідний документ: ${errors.join(', ')}` };
  }
  
  // Знайти справу
  const caseIndex = cases.findIndex(c => c.id === params.caseId);
  if (caseIndex === -1) {
    return { success: false, error: `Справу ${params.caseId} не знайдено` };
  }
  
  // Перевірити чи документ з таким id вже існує
  const existing = cases[caseIndex].documents?.find(d => d.id === params.document.id);
  if (existing) {
    return { success: false, error: `Документ ${params.document.id} вже існує у справі` };
  }
  
  // Додати документ
  setCases(prev => prev.map((c, idx) => 
    idx === caseIndex 
      ? { ...c, documents: [...(c.documents || []), params.document], updatedAt: new Date().toISOString() }
      : c
  ));
  
  return { 
    success: true, 
    documentId: params.document.id,
    message: `Документ "${params.document.name}" додано у справу`
  };
},
```

### Імпорт `validateDocument`

Перевір що `validateDocument` імпортовано з `documentFactory.js` в App.jsx. Якщо ні — додай імпорт.

### Audit для add_document

Подивись `src/services/auditLogService.js:7-21` — чи є `add_document` в `AUDIT_ACTIONS`. Швидше за все немає. Додай.

`shouldAudit('add_document')` має повертати true, бо створення документа — важлива подія для audit log.

### Критерії приймання TASK 2.1
- ACTION `add_document` додано в реєстр ACTIONS
- Валідація через validateDocument працює
- Дублікати id обробляються правильно
- AUDIT_ACTIONS оновлено
- Білд проходить

---

## TASK 2.2 — ACTION `add_documents` (batch)

Поряд з `add_document`. Це batch версія для DocumentProcessor.

```javascript
add_documents: async (params) => {
  // params: { caseId, documents } — масив об'єктів документів
  
  if (!params.caseId) {
    return { success: false, error: 'caseId обов'язковий' };
  }
  if (!Array.isArray(params.documents) || params.documents.length === 0) {
    return { success: false, error: 'documents має бути непорожнім масивом' };
  }
  
  // Валідація всіх документів перед додаванням (атомарність)
  const validationErrors = [];
  for (let i = 0; i < params.documents.length; i++) {
    const { valid, errors } = validateDocument(params.documents[i]);
    if (!valid) {
      validationErrors.push(`Документ ${i}: ${errors.join(', ')}`);
    }
  }
  if (validationErrors.length > 0) {
    return { 
      success: false, 
      error: `Валідація не пройдена для ${validationErrors.length} документів`,
      errors: validationErrors
    };
  }
  
  // Знайти справу
  const caseIndex = cases.findIndex(c => c.id === params.caseId);
  if (caseIndex === -1) {
    return { success: false, error: `Справу ${params.caseId} не знайдено` };
  }
  
  // Перевірка дублікатів за id
  const existingIds = new Set((cases[caseIndex].documents || []).map(d => d.id));
  const duplicates = params.documents.filter(d => existingIds.has(d.id));
  if (duplicates.length > 0) {
    return { 
      success: false, 
      error: `${duplicates.length} документів з такими id вже існують у справі`,
      duplicates: duplicates.map(d => d.id)
    };
  }
  
  // Атомарно додати всі документи
  setCases(prev => prev.map((c, idx) => 
    idx === caseIndex 
      ? { 
          ...c, 
          documents: [...(c.documents || []), ...params.documents], 
          updatedAt: new Date().toISOString() 
        }
      : c
  ));
  
  return { 
    success: true, 
    addedCount: params.documents.length,
    documentIds: params.documents.map(d => d.id),
    message: `Додано ${params.documents.length} документів у справу`
  };
},
```

### Особливість audit для batch

В audit log хочеться бачити "DocumentProcessor додав 18 документів" однією подією, не 18. Перевір як зараз `writeAuditLog` обробляє виклики через executeAction. Якщо потрібен спеціальний форматер для batch — додай.

Хелпер `formatAuditMessage(action, params, result)` може отримати `addedCount` з результату і сформувати правильне повідомлення.

### Критерії приймання TASK 2.2
- ACTION `add_documents` додано
- Валідація атомарна — або всі додаються, або жоден
- Дублікати правильно обробляються
- AUDIT_ACTIONS оновлено для batch
- Audit log пише одну подію з addedCount

---

## TASK 2.3 — ACTION `update_document`

```javascript
update_document: async (params) => {
  // params: { caseId, documentId, fields }
  // fields — об'єкт з полями для оновлення (тільки канонічні легкі поля)
  
  if (!params.caseId || !params.documentId || !params.fields) {
    return { success: false, error: 'caseId, documentId, fields обов'язкові' };
  }
  
  // Allowlist полів які можна оновлювати через цей ACTION
  const ALLOWED_UPDATE_FIELDS = [
    'name', 'category', 'author', 'documentNature', 'namingStatus',
    'isKey', 'procId', 'driveUrl', 'folder', 'pageCount', 'date',
    'icon', 'status'
  ];
  
  const invalidFields = Object.keys(params.fields).filter(f => !ALLOWED_UPDATE_FIELDS.includes(f));
  if (invalidFields.length > 0) {
    return { 
      success: false, 
      error: `Заборонено оновлювати поля: ${invalidFields.join(', ')}` 
    };
  }
  
  // Знайти справу і документ
  const caseIndex = cases.findIndex(c => c.id === params.caseId);
  if (caseIndex === -1) {
    return { success: false, error: `Справу ${params.caseId} не знайдено` };
  }
  const docIndex = (cases[caseIndex].documents || []).findIndex(d => d.id === params.documentId);
  if (docIndex === -1) {
    return { success: false, error: `Документ ${params.documentId} не знайдено` };
  }
  
  // Створити оновлений документ
  const updatedDoc = {
    ...cases[caseIndex].documents[docIndex],
    ...params.fields,
    updatedAt: new Date().toISOString()
  };
  
  // Валідація через validateDocument
  const { valid, errors } = validateDocument(updatedDoc);
  if (!valid) {
    return { success: false, error: `Невалідний документ після оновлення: ${errors.join(', ')}` };
  }
  
  // Оновити в state
  setCases(prev => prev.map((c, idx) => 
    idx === caseIndex 
      ? { 
          ...c, 
          documents: c.documents.map((d, dIdx) => dIdx === docIndex ? updatedDoc : d),
          updatedAt: new Date().toISOString()
        }
      : c
  ));
  
  return { 
    success: true, 
    documentId: params.documentId,
    updatedFields: Object.keys(params.fields),
    message: `Документ "${updatedDoc.name}" оновлено`
  };
},
```

### Чому allowlist полів

Захист від випадкового перезапису критичних полів типу `id`, `addedAt`, `addedBy`, `driveId`. Ці поля не повинні змінюватись через update_document — вони фіксуються при створенні.

### Критерії приймання TASK 2.3
- ACTION `update_document` додано
- Allowlist полів працює
- Валідація після оновлення
- Audit log fіксує які поля змінено

---

## TASK 2.4 — ACTION `delete_document` з трьома режимами

```javascript
delete_document: async (params) => {
  // params: { caseId, documentId, mode }
  // mode: 'full' | 'registry_only' | 'archive'
  
  if (!params.caseId || !params.documentId) {
    return { success: false, error: 'caseId і documentId обов'язкові' };
  }
  
  const mode = params.mode || 'full';
  if (!['full', 'registry_only', 'archive'].includes(mode)) {
    return { success: false, error: `Невідомий режим: ${mode}` };
  }
  
  // Знайти справу і документ
  const caseIndex = cases.findIndex(c => c.id === params.caseId);
  if (caseIndex === -1) {
    return { success: false, error: `Справу ${params.caseId} не знайдено` };
  }
  const doc = (cases[caseIndex].documents || []).find(d => d.id === params.documentId);
  if (!doc) {
    return { success: false, error: `Документ ${params.documentId} не знайдено` };
  }
  
  if (mode === 'archive') {
    // Тільки змінюємо status
    setCases(prev => prev.map((c, idx) => 
      idx === caseIndex 
        ? { 
            ...c, 
            documents: c.documents.map(d => 
              d.id === params.documentId 
                ? { ...d, status: 'archived', updatedAt: new Date().toISOString() }
                : d
            ),
            updatedAt: new Date().toISOString()
          }
        : c
    ));
    return { 
      success: true, 
      mode: 'archive',
      documentId: params.documentId,
      message: `Документ "${doc.name}" архівовано`
    };
  }
  
  // mode === 'full' або 'registry_only'
  // Спочатку видаляємо з реєстру
  setCases(prev => prev.map((c, idx) => 
    idx === caseIndex 
      ? { 
          ...c, 
          documents: c.documents.filter(d => d.id !== params.documentId),
          updatedAt: new Date().toISOString()
        }
      : c
  ));
  
  // Видалити з documents_extended
  try {
    const extended = await loadExtendedForCase(params.caseId, cases[caseIndex]);
    delete extended[params.documentId];
    await saveExtendedForCase(params.caseId, cases[caseIndex], extended);
  } catch (err) {
    console.warn('Не вдалось видалити запис з documents_extended:', err);
    // Не блокуємо основну операцію
  }
  
  if (mode === 'registry_only') {
    return { 
      success: true, 
      mode: 'registry_only',
      documentId: params.documentId,
      message: `Документ "${doc.name}" видалено з реєстру (файли залишились на Drive)`
    };
  }
  
  // mode === 'full' — видалити файли з Drive
  // 01_ОРИГІНАЛИ
  if (doc.driveId) {
    try {
      await deleteDriveFile(doc.driveId);
    } catch (err) {
      console.warn(`Не вдалось видалити файл з Drive: ${err.message}`);
      // Не блокуємо основну операцію — файл міг бути видалений раніше вручну
    }
  }
  
  // 02_ОБРОБЛЕНІ — OCR-кеш
  // Знайти і видалити <basename>_<driveId>.txt у 02_ОБРОБЛЕНІ
  // Логіка пошуку — як в ocrService.js (за іменем + driveId)
  // Не падати якщо не знайдено
  try {
    await deleteOcrCacheForDocument(cases[caseIndex], doc);
  } catch (err) {
    console.warn(`Не вдалось видалити OCR-кеш: ${err.message}`);
  }
  
  return { 
    success: true, 
    mode: 'full',
    documentId: params.documentId,
    message: `Документ "${doc.name}" видалено повністю (з реєстру і з Drive)`
  };
},
```

### Хелпер `deleteOcrCacheForDocument`

Якщо такої функції немає — створи в `src/services/documentsService.js` (або `documentFactory.js` поряд з createDocument). Логіка:

1. Знайти підпапку 02_ОБРОБЛЕНІ у каталозі справи
2. Знайти файл `<sanitizedName>_<driveId>.txt`  
3. Видалити через Drive API

Цей хелпер також буде корисний при перевірці цілісності.

### `requireUI: true`

В описі ACTIONS додай позначку:
```javascript
delete_document: {
  handler: async (params) => { ... },
  requireUI: true,  // Заборонено агентам — тільки через UI з підтвердженням
  audit: true
}
```

Перевір реальну структуру ACTIONS у коді — чи кожен ACTION це функція чи об'єкт з полями. Адаптуй позначку під реальну структуру.

Якщо реально в коді ACTIONS — це просто мапа `name → function`, то `requireUI: true` треба реалізувати інакше:
- Через окремий Set `UI_ONLY_ACTIONS = new Set(['destroy_case', 'delete_document', 'delete_proceeding'])`
- В executeAction перевіряти `if (UI_ONLY_ACTIONS.has(action) && !params._fromUI) return { success: false, error: 'Дія тільки через UI' }`
- UI коли викликає executeAction — додає `params._fromUI: true`
- Агенти ніколи не передають `_fromUI`

Це найпростіша реалізація. Перевір як зараз працює `destroy_case` — якщо він просто немає в ACTIONS, можна піти тим самим шляхом (не додавати в реєстр взагалі, мати окрему UI-only функцію). Але для делетів я б додав в ACTIONS з `_fromUI` перевіркою — це чистіше.

### Критерії приймання TASK 2.4
- ACTION `delete_document` додано з трьома режимами
- `_fromUI` перевірка працює — агенти отримують error, UI отримує success
- AUDIT_ACTIONS оновлено
- documents_extended cleanup працює
- Drive cleanup працює (з graceful failures)

---

## TASK 2.5 — ACTIONS для проваджень

Три ACTION'и: `add_proceeding`, `update_proceeding`, `delete_proceeding`.

```javascript
add_proceeding: async (params) => {
  // params: { caseId, proceeding }
  // proceeding: { id, type, name, parentProcId, color, court, caseNumber, dateOpened, judges, ... }
  
  if (!params.caseId || !params.proceeding) {
    return { success: false, error: 'caseId і proceeding обов'язкові' };
  }
  
  if (!params.proceeding.id || !params.proceeding.name || !params.proceeding.type) {
    return { success: false, error: 'proceeding має мати id, name, type' };
  }
  
  const caseIndex = cases.findIndex(c => c.id === params.caseId);
  if (caseIndex === -1) {
    return { success: false, error: `Справу ${params.caseId} не знайдено` };
  }
  
  const existingProcs = cases[caseIndex].proceedings || [];
  
  // Перевірка дубля id
  if (existingProcs.find(p => p.id === params.proceeding.id)) {
    return { success: false, error: `Провадження ${params.proceeding.id} вже існує` };
  }
  
  // Перевірка унікальності назви в межах справи
  if (existingProcs.find(p => p.name === params.proceeding.name)) {
    return { success: false, error: `Провадження з назвою "${params.proceeding.name}" вже існує` };
  }
  
  // Перевірка parentProcId — батько має існувати
  if (params.proceeding.parentProcId) {
    if (!existingProcs.find(p => p.id === params.proceeding.parentProcId)) {
      return { success: false, error: `Батьківське провадження ${params.proceeding.parentProcId} не знайдено` };
    }
  }
  
  // Додати провадження
  const proceeding = {
    ...params.proceeding,
    addedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  setCases(prev => prev.map((c, idx) => 
    idx === caseIndex 
      ? { ...c, proceedings: [...existingProcs, proceeding], updatedAt: new Date().toISOString() }
      : c
  ));
  
  return { 
    success: true, 
    proceedingId: proceeding.id,
    message: `Провадження "${proceeding.name}" додано у справу`
  };
},

update_proceeding: async (params) => {
  // params: { caseId, proceedingId, fields }
  
  if (!params.caseId || !params.proceedingId || !params.fields) {
    return { success: false, error: 'caseId, proceedingId, fields обов'язкові' };
  }
  
  // Allowlist — тип провадження не редагується
  const ALLOWED_UPDATE_FIELDS = [
    'name', 'parentProcId', 'color', 'court', 'caseNumber', 
    'dateOpened', 'judges', 'description'
  ];
  
  const invalidFields = Object.keys(params.fields).filter(f => !ALLOWED_UPDATE_FIELDS.includes(f));
  if (invalidFields.length > 0) {
    return { success: false, error: `Заборонено оновлювати поля: ${invalidFields.join(', ')}` };
  }
  
  const caseIndex = cases.findIndex(c => c.id === params.caseId);
  if (caseIndex === -1) {
    return { success: false, error: `Справу ${params.caseId} не знайдено` };
  }
  
  const procIndex = (cases[caseIndex].proceedings || []).findIndex(p => p.id === params.proceedingId);
  if (procIndex === -1) {
    return { success: false, error: `Провадження ${params.proceedingId} не знайдено` };
  }
  
  // Перевірка циклів parentProcId — не можна зробити батьком саме себе або нащадка
  if (params.fields.parentProcId) {
    if (params.fields.parentProcId === params.proceedingId) {
      return { success: false, error: 'Провадження не може бути батьком самого себе' };
    }
    // Перевірка чи новий parentProcId не є нащадком цього провадження
    if (isDescendant(cases[caseIndex].proceedings, params.fields.parentProcId, params.proceedingId)) {
      return { success: false, error: 'Циклічна залежність — не можна зробити нащадка батьком' };
    }
  }
  
  setCases(prev => prev.map((c, idx) => 
    idx === caseIndex 
      ? { 
          ...c, 
          proceedings: c.proceedings.map((p, pIdx) => 
            pIdx === procIndex 
              ? { ...p, ...params.fields, updatedAt: new Date().toISOString() }
              : p
          ),
          updatedAt: new Date().toISOString()
        }
      : c
  ));
  
  return { 
    success: true, 
    proceedingId: params.proceedingId,
    updatedFields: Object.keys(params.fields)
  };
},

delete_proceeding: async (params) => {
  // params: { caseId, proceedingId }
  // Видалення провадження не видаляє документи — їх procId обнуляється
  
  if (!params.caseId || !params.proceedingId) {
    return { success: false, error: 'caseId і proceedingId обов'язкові' };
  }
  
  const caseIndex = cases.findIndex(c => c.id === params.caseId);
  if (caseIndex === -1) {
    return { success: false, error: `Справу ${params.caseId} не знайдено` };
  }
  
  const proc = (cases[caseIndex].proceedings || []).find(p => p.id === params.proceedingId);
  if (!proc) {
    return { success: false, error: `Провадження ${params.proceedingId} не знайдено` };
  }
  
  // Перевірка чи є дочірні провадження — якщо так, попередити
  const children = (cases[caseIndex].proceedings || []).filter(p => p.parentProcId === params.proceedingId);
  if (children.length > 0) {
    return { 
      success: false, 
      error: `Не можна видалити — є ${children.length} дочірніх проваджень. Спочатку видаліть або переприв'яжіть їх.`,
      childrenIds: children.map(c => c.id)
    };
  }
  
  // Знайти всі документи з цим procId і обнулити procId
  const affectedDocs = (cases[caseIndex].documents || []).filter(d => d.procId === params.proceedingId);
  
  setCases(prev => prev.map((c, idx) => 
    idx === caseIndex 
      ? { 
          ...c,
          proceedings: c.proceedings.filter(p => p.id !== params.proceedingId),
          documents: c.documents.map(d => 
            d.procId === params.proceedingId 
              ? { ...d, procId: null, updatedAt: new Date().toISOString() }
              : d
          ),
          updatedAt: new Date().toISOString()
        }
      : c
  ));
  
  return { 
    success: true, 
    proceedingId: params.proceedingId,
    affectedDocumentsCount: affectedDocs.length,
    message: `Провадження "${proc.name}" видалено. ${affectedDocs.length} документів стали "без провадження".`
  };
},
```

### Хелпер `isDescendant`

```javascript
function isDescendant(proceedings, candidateId, ancestorId) {
  // Чи candidateId є нащадком ancestorId
  let current = proceedings.find(p => p.id === candidateId);
  while (current && current.parentProcId) {
    if (current.parentProcId === ancestorId) return true;
    current = proceedings.find(p => p.id === current.parentProcId);
  }
  return false;
}
```

Розташування — або в App.jsx як приватна функція, або в `src/services/proceedingsService.js`. Якщо створюєш новий файл — імпорти оновити.

### `requireUI` для delete_proceeding

`delete_proceeding` теж має бути UI-only через `_fromUI` патерн з TASK 2.4.

### Критерії приймання TASK 2.5
- Три ACTIONS додано
- Перевірка циклів parentProcId
- Каскадне обнулення procId документів при delete_proceeding
- delete_proceeding блокується якщо є дочірні
- AUDIT_ACTIONS оновлено

---

## TASK 2.6 — ACTION `update_processing_context`

```javascript
update_processing_context: async (params) => {
  // params: { caseId, context }
  // context — об'єкт lastProcessingContext який пише DocumentProcessor після обробки
  
  if (!params.caseId || !params.context) {
    return { success: false, error: 'caseId і context обов'язкові' };
  }
  
  const caseIndex = cases.findIndex(c => c.id === params.caseId);
  if (caseIndex === -1) {
    return { success: false, error: `Справу ${params.caseId} не знайдено` };
  }
  
  // Перевірити структуру context
  const requiredFields = ['processedAt', 'documentsCount', 'summary'];
  const missing = requiredFields.filter(f => !params.context[f]);
  if (missing.length > 0) {
    return { success: false, error: `У context відсутні поля: ${missing.join(', ')}` };
  }
  
  setCases(prev => prev.map((c, idx) => 
    idx === caseIndex 
      ? { ...c, lastProcessingContext: params.context, updatedAt: new Date().toISOString() }
      : c
  ));
  
  return { 
    success: true, 
    message: `Контекст обробки оновлено для справи` 
  };
},
```

### Audit для update_processing_context

Це службова дія — не потребує audit log. У `AUDIT_ACTIONS` НЕ додавати.

### Критерії приймання TASK 2.6
- ACTION `update_processing_context` додано
- Структура context валідується
- Audit log не пише цю дію (службова)

---

## TASK 2.7 — Розширити PERMISSIONS

`view` `src/App.jsx:5168-5209`. Знайди структуру:

```javascript
const PERMISSIONS = {
  qi_agent: [...],
  dashboard_agent: [...],
  dossier_agent: [...]
};
```

Оновити:

```javascript
const PERMISSIONS = {
  qi_agent: [
    // існуючі дозволи...
    'add_document',  // QI-команда може додати документ зі скріншотом
    'update_document',  // Якщо QI-команда редагує
    'add_proceeding',
    'update_proceeding'
  ],
  
  dashboard_agent: [
    // існуючі дозволи без змін — документи не його зона
  ],
  
  dossier_agent: [
    // існуючі дозволи...
    'add_document',
    'update_document',
    // delete_document — НЕМАЄ (тільки UI)
    'add_proceeding',
    'update_proceeding',
    // delete_proceeding — НЕМАЄ (тільки UI)
    'update_processing_context'
  ],
  
  document_processor_agent: [  // НОВА РОЛЬ
    'add_documents',  // batch
    'update_processing_context',
    'update_case_status'  // опційно, якщо обробка змінила статус
    // delete — нічого
    // hearings/deadlines — нічого
    // create/destroy_case — нічого
  ]
};
```

### Critical: повний перелік існуючих дозволів

Скопіюй точний поточний перелік для `qi_agent`, `dashboard_agent`, `dossier_agent` з реального коду. Просто додавай нові, не переписуй існуючі від руки — буде помилка.

### Перевірка checkRolePermission

`view` `src/services/permissionService.js:26-33`. Зараз заглушка повертає true для всіх. Не чіпай — це окремий TASK Multi-user Activation.

### Критерії приймання TASK 2.7
- `document_processor_agent` додано в PERMISSIONS
- `dossier_agent` отримав нові дозволи без втрати існуючих
- `qi_agent` отримав add_document, add_proceeding
- delete_document і delete_proceeding не дозволені нікому з агентів

---

## TASK 2.8 — Замінити тимчасовий обхід в drag-n-drop

Знайди реалізацію drag-n-drop у CaseDossier (з TASK 1 patch). Орієнтовно:

```javascript
// Тимчасовий код з TASK 1 patch
await executeAction('dossier_agent', 'update_case_field', {
  caseId: caseData.id,
  field: 'documents',
  value: [...existingDocs, newDoc]
});
```

Заміни на:

```javascript
await executeAction('dossier_agent', 'add_document', {
  caseId: caseData.id,
  document: newDoc
});
```

### Перевір допуск 'documents' в update_case_field allowlist

В TASK 1 patch ймовірно додав 'documents' як тимчасово дозволене поле в `update_case_field`. Тепер цю поправку треба прибрати — щоб документи більше не можна було модифікувати через update_case_field (порушує single-purpose патерн).

Знайди `update_case_field` в App.jsx навколо `4595`. Якщо в allowlist є 'documents' — прибери. Якщо це призводить до інших обвалень — перевір де ще використовується update_case_field з documents (можливо є ще місця).

### Критерії приймання TASK 2.8
- drag-n-drop використовує `add_document` замість `update_case_field`
- 'documents' прибрано з update_case_field allowlist
- Drag-n-drop досі працює — документи створюються в реєстрі з ⚠

---

## TASK 2.9 — Sanity-tests і перевірка executeAction

Після всіх змін проведи sanity-tests:

```javascript
// 1. add_document
const newDoc = createDocument({ name: 'Test', driveId: 'fake_id', size: 100, addedBy: 'lawyer_manual' });
await executeAction('dossier_agent', 'add_document', { caseId: 'case_001', document: newDoc });

// 2. add_documents (batch) 
const docs = [doc1, doc2, doc3];
await executeAction('document_processor_agent', 'add_documents', { caseId: 'case_001', documents: docs });

// 3. update_document — дозволене поле
await executeAction('dossier_agent', 'update_document', { 
  caseId: 'case_001', documentId: newDoc.id, fields: { isKey: true } 
});

// 4. update_document — заборонене поле
await executeAction('dossier_agent', 'update_document', { 
  caseId: 'case_001', documentId: newDoc.id, fields: { addedBy: 'fake' } 
});
// expect: { success: false, error: 'Заборонено оновлювати поля: addedBy' }

// 5. delete_document без _fromUI
await executeAction('dossier_agent', 'delete_document', { 
  caseId: 'case_001', documentId: newDoc.id, mode: 'full' 
});
// expect: { success: false, error: 'Дія тільки через UI' }

// 6. delete_document з _fromUI
await executeAction('dossier_agent', 'delete_document', { 
  caseId: 'case_001', documentId: newDoc.id, mode: 'archive', _fromUI: true 
});
// expect: { success: true, mode: 'archive' }

// 7. add_proceeding з parentProcId
const proc = { id: 'proc_test', type: 'appeal', name: 'Test Apeal', parentProcId: 'proc_first' };
await executeAction('dossier_agent', 'add_proceeding', { caseId: 'case_001', proceeding: proc });

// 8. delete_proceeding без _fromUI
await executeAction('dossier_agent', 'delete_proceeding', { caseId: 'case_001', proceedingId: 'proc_test' });
// expect: { success: false, error: 'Дія тільки через UI' }

// 9. document_processor_agent НЕ може створити справу
await executeAction('document_processor_agent', 'create_case', { ... });
// expect: { success: false, error: 'Немає повноважень: create_case' }
```

Запусти sanity-tests через node script (як робив у TASK 1). Перевір що всі поведінки правильні.

### Критерії приймання TASK 2.9
- Усі 9 тестів проходять з очікуваними результатами
- Білд проходить
- Жодного існуючого ACTION не зламано

---

## SAAS IMPLICATIONS

Цей TASK закладає базис для multi-tenant. Усі нові ACTIONS:
- Поважають `checkTenantAccess` через executeAction
- Можуть бути перевірені через `checkRolePermission` (зараз заглушка, в майбутньому матриця ролей)
- Audit log пише userId і tenantId за існуючою інфраструктурою

Коли в системі будуть юристи бюро з різними ролями (Owner / Senior / Junior / Assistant), матриця PERMISSIONS може мати додаткові ролі типу `assistant_agent` з обмеженими правами. Зараз це абстрактні агентські ролі, не людські. У TASK Multi-user Activation вони з'єднаються з ролями користувачів.

---

## BILLING IMPLICATIONS

ACTIONS `add_document`, `add_documents` будуть тригерами для подій ai_usage:
- При додаванні документа через DP — `ai_usage` запис з типом 'document_processing' пишеться в `processingHistory` цього документа
- При роботі агента з документом (читання, редагування) — `ai_usage` пишеться через `activityTracker.report()`

Структура для цього в TASK 2 не реалізується — це робота TASK Document Processor v2 (Фаза 2). Зараз тільки готуємо базу: `processingHistory` як порожній масив у extended.

---

## КОМІТ І ПУШ

Після всіх змін і sanity-tests:

```
git commit -m "feat: TASK 2 — ACTIONS registry for documents/proceedings + PERMISSIONS for document_processor_agent + replace drag-n-drop temporary workaround with add_document"
git push origin main
```

GitHub Actions задеплоїть за 2-3 хвилини.

---

## ОЧІКУВАНІ АРТЕФАКТИ ВИКОНАННЯ

При здачі TASK **створи файл звіту** `report_task2.md` у корені репо. Цей файл — основний канал комунікації результатів. Адвокат завантажить його в адмін-чат для аналізу.

Структура файлу:

### Резюме TASK 2

Короткий абзац що зроблено.

### Виправлення / реалізація з TASK

- Кожна підзадача (2.1-2.9) — один рядок з результатом ✓ або з поясненням якщо було відхилення
- Точні file:line де додано нові ACTIONS
- Точні file:line де оновлено PERMISSIONS

### Створені файли

| Файл | Призначення |
|------|-------------|
| (якщо створював нові) | (короткий опис) |

### Змінені файли

- src/App.jsx — діапазони рядків і що додано
- (інші файли) — що змінено

### Відхилення від TASK з обґрунтуванням

Якщо щось зробив інакше ніж описано в TASK — поясни чому. (структура ACTIONS виявилась іншою, _fromUI патерн був реалізований інакше, тощо)

### Знахідки

Якщо створив `discovered_issues_during_task2.md` — перерахуй короткими рядками що там.

### Sanity-tests результати

Усі 9 тестів з TASK 2.9 — який результат для кожного:
- Test 1: add_document — ✓ success
- Test 2: add_documents batch — ✓ success, addedCount=3
- Test 3: update_document allowed field — ✓
- Test 4: update_document forbidden field — ✓ error як очікувалось
- Test 5: delete_document без _fromUI — ✓ blocked
- Test 6: delete_document з _fromUI — ✓ archived
- Test 7: add_proceeding з parentProcId — ✓
- Test 8: delete_proceeding без _fromUI — ✓ blocked
- Test 9: document_processor_agent → create_case — ✓ blocked (немає дозволу)

### Рекомендації для CLAUDE.md

Якщо додав нову секцію в `recommended_task_claude_md_audit.md` — короткий перелік пунктів.

### Білд + push

- npm run build — статус
- Sanity-tests — короткий результат
- Коміт hash і повідомлення
- git push origin main — статус

### Пояснення в термінал для адвоката

Після створення файлу `report_task2.md` виведи в термінал зрозуміле людське пояснення для адвоката (не технічно підкованого користувача). Розкажи **простою мовою без технічного жаргону**:

- Що ти зробив (одним абзацом, простими словами)
- Як це впливає на роботу системи (що тепер може система чого не могла раніше)
- Чи все працює (білд, тести)
- Що адвокату треба зробити далі (ну наприклад "перевір на сайті чи drag-n-drop досі додає документи в реєстр")
- Куди зберігся детальний звіт ("повний технічний звіт у файлі report_task2.md в корені репо — завантаж його в чат для аналізу")

Стиль як ніби ти пояснюєш родичу що ти робив на роботі. Без термінів типу "executeAction", "PERMISSIONS", "ACTION'и" — це все має лишитись у файлі звіту. Адвокату важливо зрозуміти **результат і вплив**, не реалізацію.

Приклад правильного тону пояснення (це не зразок змісту, а тон):

> Я закінчив додавання нових команд у систему — тепер агенти (помічники AI) можуть правильно додавати, оновлювати і видаляти документи у справах. Раніше при перетягуванні файлу в досьє система записувала його через тимчасовий обхід — тепер це робиться правильним шляхом.
>
> Що змінилося для тебе:
> - При перетягуванні файлу в досьє — все працює як раніше, але внутрішньо чистіше
> - Видалення документів отримало три варіанти (повне / тільки з реєстру / архівувати) — UI з'явиться у наступних TASK
> - Document Processor тепер має свої окремі дозволи і не може робити того що не повинен
>
> Усе працює: білд проходить чисто, всі 9 перевірок успішні, зміни задеплоєно на сайт.
>
> Перевір що drag-n-drop у досьє Кісельової досі додає документи з ⚠ — якщо так, все ОК.
>
> Повний технічний звіт — у файлі `report_task2.md` в корені репо. Завантаж його в адмін-чат щоб подивитись деталі.

---

## ВЛАСНА АНАЛІТИКА І ТВОРЧЕ ВИКОНАННЯ

Цей TASK описує цільовий стан з підказками реалізації. Якщо в процесі виявиш:

- Кращий спосіб організації коду → роби, поясни в коментарі
- Помилку в архітектурному рішенні → зупинись, опиши в `discovered_issues_during_task2.md`
- Реальна структура ACTIONS відрізняється від моєї версії (може бути об'єкт `{handler, audit, requireUI}` замість простої функції) → адаптуй під реальність, не міняй архітектуру всього реєстру
- `_fromUI` патерн вже існує в іншому вигляді → використай існуючий
- При sanity-tests щось ламається → зупинись, з'ясуй причину перед коммітом

Не вважай TASK дзвоном з небес. Перевіряй реальний стан коду перед кожною зміною.

---

**Кінець TASK 2.**
