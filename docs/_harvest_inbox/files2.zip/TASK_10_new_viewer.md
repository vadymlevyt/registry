# TASK 10 — Новий Viewer документа з перемикачем Скан/Текст і повним підвалом

**Дата формування:** 09.05.2026
**Фаза:** 1.6 — UI Reform (шостий TASK)
**Виконавець:** Claude Code (Opus 4.7, 1M context)
**Орієнтовний обсяг:** 6-8 годин
**Передумови:** TASK 1-9 завершені і закомічені (з усіма patch'ами)

---

## ПРИНЦИПИ ВИКОНАННЯ

**Творчо, виважено, охайно.** Цей TASK — перший де ми реально починаємо створювати **новий UX досьє з нуля** замість міграції стилів. Якість коду тут особливо важлива бо Viewer — це те що адвокат бачить найчастіше при роботі зі справою.

**Перевіряй перед змінами.** Поточний Viewer у CaseDossier — це шматок коду який рендерить PDF або зображення в правій панелі. Подивись як він влаштований зараз через `view` файлу і `grep` ключових слів. Структура яку проектуєш у TASK може потребувати адаптації під реальний код.

**Тести разом з кодом.** Кожна нова логіка (перемикач Скан/Текст, кнопки шапки/підвалу) має юніт-тест. Складніше — інтеграційні тести. Без тестів TASK не вважається завершеним.

**SaaS-готовність.** Viewer працює з документами які мають канонічну схему (TASK 1). Параметри як `documentNature` ('searchable'/'scanned') вже є — використовуй їх. Не хардкодь поведінку.

**Без тимчасових рішень.** Якщо немає тексту OCR для документа — не фейкови його, не лиши `// TODO`. Покажи коректне порожне-state з пропозицією дії.

---

## АДАПТИВНІСТЬ

Адвокат працює переважно з планшета (Lenovo Yoga Tab 13, 2160×1350) у landscape. Viewer — primary робоче місце.

**Цільові breakpoint'и:**
- ≥1280px — повний layout (Viewer 66% + список 33%)
- 768-1279px — компактний (Viewer 75% + список 25% або модалка)
- <768px — мобільний (Viewer на повний екран, список замінює його через перемикач)

**Що перевіряти у Viewer:**
- Шапка з назвою + метаданими + кнопками — на planшеті portrait кнопки не повинні переноситись на 2 рядки. На <768px — другорядні кнопки в overflow меню.
- Перемикач [🖼 Скан] [📝 Текст] — touch-friendly (min 44px).
- Підвал кнопок — на mobile вертикальний layout або компактна іконкова рядок.
- PDF контент — масштабується через CSS, fit-to-width на mobile.

Якщо знаходиш складну адаптивність яка потребує великого refactor — фіксуй у `discovered_issues_during_task10.md` для майбутнього Mobile-First TASK.

---

## КОНТЕКСТ

### З mockup'ів (`dossier_ui_mockups.md` Блок 5)

Цільова структура Viewer'а:

```
┌──────────────────────────────────────────────────────────┐
│ [🖼 Скан] [📝 Текст]   назва.pdf  ⭐ ключовий  🔧  ✕    │
│ pleading · ours · 🟢 Перша · 15.03.2026 · 7 стор · 2.4MB │
│──────────────────────────────────────────────────────────│
│                                                          │
│              [PDF/Image content або Text]                │
│                                                          │
│──────────────────────────────────────────────────────────│
│  ⤴ Drive   ⬇ Завантажити   📋 Копіювати                  │
│  📤 Поділитись   🤖 Обговорити   ⟳ Перерозпізнати       │
└──────────────────────────────────────────────────────────┘
```

**Шапка (елементи):**
- Перемикач `[🖼 Скан] [📝 Текст]` — **тільки для scanned**, для searchable приховано
- Назва документа (повна, інфікована залежно від ширини)
- Toggle ⭐ "ключовий" — клік перемикає `isKey` field
- `🔧` — відкриває панель деталей (TASK 11, поки не реалізовано — заглушка)
- `✕` — закрити viewer (повертає до списку)

**Метарядок (під шапкою):**
- Категорія (з людською назвою), автор, провадження з кольоровим кружечком, дата, к-ть сторінок, розмір файлу
- Розділені `·`
- Якщо поле відсутнє — пропускається (не показуємо "невідомо")

**Контент:**
- Режим **Скан** — PDF.js render з canvas, або `<img>` для зображень
- Режим **Текст** — текстовий вміст з OCR (з `02_ОБРОБЛЕНІ` папки на Drive)
- Якщо searchable PDF — завжди Text режим (немає сенсу показувати картинку)
- Якщо немає тексту OCR — показуємо empty state з кнопкою "Перерозпізнати"

**Підвал (6 кнопок):**
1. **⤴ Drive** — `window.open(driveUrl)` в новій вкладці
2. **⬇ Завантажити** — скачати оригінал
3. **📋 Копіювати** — текст у буфер обміну (тільки для текстового режиму, для скана — placeholder "Перейдіть в режим Текст")
4. **📤 Поділитись** — Web Share API (якщо доступний)
5. **🤖 Обговорити** — відкриває бічну панель агента з контекстом цього документа (передає `documentId` як параметр)
6. **⟳ Перерозпізнати** — тільки для scanned, виклик `ocrService.reprocess(driveId, { force: true })`

### Що з цього випливає

TASK 10 розбивається на 7 підзадач:

- **10.1** Структура Viewer компонента (новий файл `DocumentViewer.jsx` або переробка існуючого)
- **10.2** Шапка з метаданими і кнопками
- **10.3** Перемикач Скан/Текст
- **10.4** Контентна частина з PDF.js і текстом
- **10.5** Підвал з 6 кнопками
- **10.6** Інтеграція з CaseDossier (заміна старого Viewer'а)
- **10.7** Тести і документація

---

## TASK 10.1 — Структура DocumentViewer компонента

### Розташування

```
src/components/DocumentViewer/
├── index.jsx              — головний компонент
├── DocumentViewer.css     — стилі
├── DocumentViewerHeader.jsx
├── DocumentViewerContent.jsx
├── DocumentViewerFooter.jsx
└── ScanTextToggle.jsx
```

Виносимо в окрему директорію бо Viewer розростеться (TASK 11 — панель деталей буде поруч).

### Принцип проектування

Контрольований компонент. Батько (CaseDossier) передає документ і обробники подій. Viewer не керує своїм state поза візуальною логікою (наприклад mode перемикача).

```jsx
<DocumentViewer
  document={selectedDocument}
  caseData={caseData}
  driveToken={driveToken}
  onClose={() => setSelectedDocId(null)}
  onUpdate={(documentId, fields) => executeAction('dossier_agent', 'update_document', { caseId, documentId, fields })}
  onOpenDetails={(documentId) => setDetailsDocId(documentId)}
  onDiscussWithAgent={(documentId) => openAgentPanel({ contextDocumentId: documentId })}
  onReprocess={(driveId) => ocrService.reprocess(driveId, { force: true })}
/>
```

### Базова структура

```jsx
import { useState, useEffect } from 'react';
import { DocumentViewerHeader } from './DocumentViewerHeader.jsx';
import { DocumentViewerContent } from './DocumentViewerContent.jsx';
import { DocumentViewerFooter } from './DocumentViewerFooter.jsx';
import './DocumentViewer.css';

/**
 * DocumentViewer — переглядач документа справи.
 * 
 * Підтримує два режими:
 * - Скан — PDF render або зображення (для scanned документів)
 * - Текст — текстовий вміст з OCR (для всіх якщо є текст)
 * 
 * Searchable документи — завжди в режимі Текст без перемикача.
 * Scanned — перемикач видимий, дефолт згідно localStorage або Скан.
 */
export function DocumentViewer({
  document,
  caseData,
  driveToken,
  onClose,
  onUpdate,
  onOpenDetails,
  onDiscussWithAgent,
  onReprocess
}) {
  const [mode, setMode] = useState(() => loadModePreference(document?.id));
  
  // Якщо searchable — завжди text mode
  const isScanned = document?.documentNature === 'scanned';
  const effectiveMode = isScanned ? mode : 'text';
  
  // Зберігати режим в localStorage при зміні
  useEffect(() => {
    if (isScanned && document?.id) {
      saveModePreference(document.id, mode);
    }
  }, [mode, document?.id, isScanned]);
  
  if (!document) {
    return <DocumentViewerEmpty />;
  }
  
  return (
    <div className="document-viewer">
      <DocumentViewerHeader
        document={document}
        caseData={caseData}
        showModeToggle={isScanned}
        mode={effectiveMode}
        onModeChange={setMode}
        onToggleKey={(isKey) => onUpdate(document.id, { isKey })}
        onOpenDetails={() => onOpenDetails(document.id)}
        onClose={onClose}
      />
      <DocumentViewerContent
        document={document}
        mode={effectiveMode}
        driveToken={driveToken}
        caseData={caseData}
      />
      <DocumentViewerFooter
        document={document}
        mode={effectiveMode}
        onDiscussWithAgent={() => onDiscussWithAgent(document.id)}
        onReprocess={() => onReprocess(document.driveId)}
      />
    </div>
  );
}

function loadModePreference(documentId) {
  if (!documentId) return 'scan';
  return localStorage.getItem(`viewer_mode_${documentId}`) || 'scan';
}

function saveModePreference(documentId, mode) {
  localStorage.setItem(`viewer_mode_${documentId}`, mode);
}

function DocumentViewerEmpty() {
  return (
    <div className="document-viewer document-viewer--empty">
      <div className="document-viewer__empty-content">
        <FileText size={64} />
        <p>Виберіть документ зі списку щоб переглянути</p>
      </div>
    </div>
  );
}
```

### Критерії приймання TASK 10.1

- Структура файлів створена
- Базовий компонент рендериться без помилок
- localStorage збереження mode для scanned документів
- Empty state коли немає документа

---

## TASK 10.2 — Шапка з метаданими і кнопками

### `DocumentViewerHeader.jsx`

```jsx
import { Star, Wrench, X } from 'lucide-react';
import { ICON_SIZE } from '../UI/icons.js';
import { ScanTextToggle } from './ScanTextToggle.jsx';
import { Tooltip } from '../UI';
import { CATEGORY_LABELS } from './labels.js';  // людські назви категорій

/**
 * Шапка Viewer'а: перемикач режиму, назва, метарядок, кнопки.
 */
export function DocumentViewerHeader({
  document,
  caseData,
  showModeToggle,
  mode,
  onModeChange,
  onToggleKey,
  onOpenDetails,
  onClose
}) {
  const proceeding = caseData?.proceedings?.find(p => p.id === document.procId);
  
  return (
    <header className="document-viewer__header">
      <div className="document-viewer__header-row">
        {showModeToggle && (
          <ScanTextToggle mode={mode} onChange={onModeChange} />
        )}
        
        <h2 className="document-viewer__title" title={document.name}>
          {document.name}
        </h2>
        
        <div className="document-viewer__header-actions">
          <Tooltip content={document.isKey ? 'Зняти позначку ключового документа' : 'Позначити як ключовий'}>
            <button
              className={`document-viewer__star ${document.isKey ? 'is-active' : ''}`}
              onClick={() => onToggleKey(!document.isKey)}
              aria-label="Ключовий документ"
            >
              <Star size={ICON_SIZE.md} fill={document.isKey ? 'var(--color-gold)' : 'none'} />
            </button>
          </Tooltip>
          
          <Tooltip content="Деталі документа">
            <button
              className="document-viewer__icon-button"
              onClick={onOpenDetails}
              aria-label="Деталі"
            >
              <Wrench size={ICON_SIZE.md} />
            </button>
          </Tooltip>
          
          <Tooltip content="Закрити">
            <button
              className="document-viewer__icon-button"
              onClick={onClose}
              aria-label="Закрити"
            >
              <X size={ICON_SIZE.md} />
            </button>
          </Tooltip>
        </div>
      </div>
      
      <DocumentMeta document={document} proceeding={proceeding} />
    </header>
  );
}

function DocumentMeta({ document, proceeding }) {
  const items = [];
  
  if (document.category) items.push(CATEGORY_LABELS[document.category] || document.category);
  if (document.author) items.push(AUTHOR_LABELS[document.author] || document.author);
  if (proceeding) items.push(<ProceedingTag proceeding={proceeding} />);
  if (document.date) items.push(formatDate(document.date));
  if (document.pageCount) items.push(`${document.pageCount} стор`);
  if (document.size) items.push(formatFileSize(document.size));
  
  if (items.length === 0) return null;
  
  return (
    <div className="document-viewer__meta">
      {items.map((item, i) => (
        <span key={i} className="document-viewer__meta-item">
          {item}
        </span>
      ))}
    </div>
  );
}

function ProceedingTag({ proceeding }) {
  const colorVar = `var(--color-proceeding-${proceeding.type === 'first_instance' ? 'first' : proceeding.type})`;
  return (
    <span className="document-viewer__proceeding-tag">
      <span 
        className="document-viewer__proceeding-dot" 
        style={{ background: colorVar }}
      />
      {proceeding.title}
    </span>
  );
}
```

### Файл `labels.js` для людських назв

```javascript
// src/components/DocumentViewer/labels.js

export const CATEGORY_LABELS = {
  pleading: 'Позов',
  motion: 'Клопотання',
  court_act: 'Судовий акт',
  evidence: 'Доказ',
  contract: 'Договір',
  correspondence: 'Кореспонденція',
  identification: 'Документ особи',
  other: 'Інше'
};

export const AUTHOR_LABELS = {
  ours: 'Наш',
  opponent: 'Опонент',
  court: 'Суд',
  third_party: 'Третя сторона'
};

export function formatDate(isoDate) {
  // 2026-03-15 → 15.03.2026
  if (!isoDate) return '';
  const [y, m, d] = isoDate.split('-');
  return `${d}.${m}.${y}`;
}

export function formatFileSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}
```

### Критерії приймання TASK 10.2

- Шапка рендерить назву, метарядок, 3 кнопки
- Перемикач Скан/Текст видимий тільки для scanned документів
- Зірочка ⭐ змінює isKey через onUpdate
- Tooltip на кожній кнопці
- Метадані пропускають відсутні поля (не показуємо "невідомо")
- Колір провадження через CSS-змінні з tokens.css

---

## TASK 10.3 — Перемикач Скан/Текст

### `ScanTextToggle.jsx`

```jsx
import { Image, FileText } from 'lucide-react';
import { ICON_SIZE } from '../UI/icons.js';
import './ScanTextToggle.css';

/**
 * Перемикач режиму Viewer для scanned документів.
 * 
 * Props:
 * - mode: 'scan' | 'text'
 * - onChange: function(newMode)
 */
export function ScanTextToggle({ mode, onChange }) {
  return (
    <div className="scan-text-toggle" role="tablist">
      <button
        role="tab"
        aria-selected={mode === 'scan'}
        className={`scan-text-toggle__option ${mode === 'scan' ? 'is-active' : ''}`}
        onClick={() => onChange('scan')}
      >
        <Image size={ICON_SIZE.sm} />
        <span>Скан</span>
      </button>
      <button
        role="tab"
        aria-selected={mode === 'text'}
        className={`scan-text-toggle__option ${mode === 'text' ? 'is-active' : ''}`}
        onClick={() => onChange('text')}
      >
        <FileText size={ICON_SIZE.sm} />
        <span>Текст</span>
      </button>
    </div>
  );
}
```

```css
.scan-text-toggle {
  display: inline-flex;
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  padding: 2px;
  flex-shrink: 0;
}

.scan-text-toggle__option {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  padding: var(--space-1) var(--space-3);
  background: transparent;
  border: none;
  color: var(--color-text-2);
  font-size: var(--text-xs);
  font-weight: var(--weight-medium);
  border-radius: var(--radius-xs);
  cursor: pointer;
  transition: all var(--transition-fast);
  min-height: 28px;
}

.scan-text-toggle__option:hover {
  color: var(--color-text);
}

.scan-text-toggle__option.is-active {
  background: var(--color-surface-2);
  color: var(--color-accent);
}

@media (max-width: 768px) {
  .scan-text-toggle__option {
    min-height: 36px;
    padding: var(--space-2) var(--space-3);
  }
}
```

### Критерії приймання TASK 10.3

- Toggle працює, активний стан візуально позначений
- aria-selected для accessibility
- Touch-friendly на mobile (мин 36px)

---

## TASK 10.4 — Контентна частина

### `DocumentViewerContent.jsx`

```jsx
import { useEffect, useState } from 'react';
import { FileText, RefreshCw } from 'lucide-react';
import { Button } from '../UI';

/**
 * Контентна частина Viewer'а.
 * 
 * Скан режим: PDF.js рендер або <img>
 * Текст режим: текстовий вміст з 02_ОБРОБЛЕНІ
 */
export function DocumentViewerContent({ document, mode, driveToken, caseData }) {
  if (mode === 'scan') {
    return <ScanContent document={document} driveToken={driveToken} />;
  }
  
  return <TextContent document={document} caseData={caseData} driveToken={driveToken} />;
}

function ScanContent({ document, driveToken }) {
  // Існуюча PDF.js логіка з CaseDossier — переюзовуй
  // Якщо PDF — render через pdf.js
  // Якщо image — <img src={drive blob URL}>
  // Якщо інший формат — fallback "Не підтримується для попереднього перегляду"
  
  return (
    <div className="document-viewer__content document-viewer__content--scan">
      {/* PDF.js render або img */}
    </div>
  );
}

function TextContent({ document, caseData, driveToken }) {
  const [text, setText] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    
    loadDocumentText(document, caseData, driveToken)
      .then(content => {
        if (!cancelled) {
          setText(content);
          setLoading(false);
        }
      })
      .catch(err => {
        if (!cancelled) {
          setError(err.message);
          setLoading(false);
        }
      });
    
    return () => { cancelled = true; };
  }, [document.id, document.driveId, driveToken]);
  
  if (loading) return <div className="document-viewer__loading">Завантаження тексту...</div>;
  
  if (error) {
    return (
      <div className="document-viewer__empty-state">
        <FileText size={48} />
        <p>Не вдалось завантажити текст</p>
        <p className="document-viewer__empty-state-detail">{error}</p>
      </div>
    );
  }
  
  if (!text) {
    return (
      <div className="document-viewer__empty-state">
        <FileText size={48} />
        <p>Текст для цього документа ще не розпізнано</p>
        <Button 
          variant="secondary" 
          icon={<RefreshCw size={14} />}
          onClick={() => onReprocess(document.driveId)}
        >
          Розпізнати зараз
        </Button>
      </div>
    );
  }
  
  return (
    <div className="document-viewer__content document-viewer__content--text">
      <pre className="document-viewer__text">{text}</pre>
    </div>
  );
}

async function loadDocumentText(document, caseData, driveToken) {
  // Логіка завантаження тексту з 02_ОБРОБЛЕНІ:
  // 1. Знайти .md файл з тим самим базовим іменем у 02_ОБРОБЛЕНІ
  // 2. Прочитати через Drive API
  // 3. Повернути зміст
  // Якщо немає — кинути помилку або повернути null
}
```

### Critical: переюзовуй існуючу PDF.js логіку

В CaseDossier зараз вже є PDF rendering. Знайди його через grep `pdfjsLib` або `pdf-lib` або `getDocument`. Переюзовуй цю логіку — не пиши з нуля. Якщо існуюча логіка прив'язана до конкретного state CaseDossier — винеси в окремий хук `usePdfRenderer(document, driveToken)`.

### Критерії приймання TASK 10.4

- Скан режим коректно рендерить PDF або зображення
- Текст режим завантажує текст з 02_ОБРОБЛЕНІ через Drive API
- Empty state коли немає тексту з кнопкою "Розпізнати зараз"
- Loading state під час завантаження
- Error state при помилці з людським повідомленням

---

## TASK 10.5 — Підвал з 6 кнопками

### `DocumentViewerFooter.jsx`

```jsx
import { ExternalLink, Download, Copy, Share2, Bot, RefreshCw } from 'lucide-react';
import { Button } from '../UI';
import { ICON_SIZE } from '../UI/icons.js';
import { toast } from '../../services/toast.js';
import { messages } from '../../services/messages.js';

export function DocumentViewerFooter({
  document,
  mode,
  onDiscussWithAgent,
  onReprocess
}) {
  const isScanned = document.documentNature === 'scanned';
  
  const handleOpenInDrive = () => {
    if (!document.driveId) {
      toast.warning('Файл недоступний на Drive');
      return;
    }
    window.open(`https://drive.google.com/file/d/${document.driveId}/view`, '_blank');
  };
  
  const handleDownload = async () => {
    if (!document.driveId) {
      toast.warning('Файл недоступний на Drive');
      return;
    }
    try {
      // Логіка завантаження через Drive API
      const blob = await downloadFromDrive(document.driveId);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = document.name;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Download failed:', err);
      const msg = messages.documents.uploadFailed?.(document.name) || {
        title: 'Не вдалось завантажити',
        description: 'Перевірте підключення і спробуйте ще раз'
      };
      toast.error(msg.title, { description: msg.description });
    }
  };
  
  const handleCopy = async () => {
    if (mode !== 'text') {
      toast.info('Перейдіть в режим Текст щоб скопіювати вміст');
      return;
    }
    try {
      // Get text from current state — потрібен ref або контекст
      const text = await getCurrentText();
      await navigator.clipboard.writeText(text);
      toast.success('Скопійовано', { duration: 2000 });
    } catch (err) {
      console.error('Copy failed:', err);
      toast.error('Не вдалось скопіювати', {
        description: 'Браузер заблокував доступ до буфера обміну'
      });
    }
  };
  
  const handleShare = async () => {
    if (!navigator.share) {
      toast.info('Поділитись недоступне в цьому браузері');
      return;
    }
    try {
      await navigator.share({
        title: document.name,
        url: `https://drive.google.com/file/d/${document.driveId}/view`
      });
    } catch (err) {
      if (err.name !== 'AbortError') {
        console.error('Share failed:', err);
      }
    }
  };
  
  return (
    <footer className="document-viewer__footer">
      <Button
        variant="ghost"
        size="sm"
        icon={<ExternalLink size={ICON_SIZE.sm} />}
        onClick={handleOpenInDrive}
      >
        Drive
      </Button>
      
      <Button
        variant="ghost"
        size="sm"
        icon={<Download size={ICON_SIZE.sm} />}
        onClick={handleDownload}
      >
        Завантажити
      </Button>
      
      <Button
        variant="ghost"
        size="sm"
        icon={<Copy size={ICON_SIZE.sm} />}
        onClick={handleCopy}
        disabled={mode !== 'text'}
      >
        Копіювати
      </Button>
      
      {navigator.share && (
        <Button
          variant="ghost"
          size="sm"
          icon={<Share2 size={ICON_SIZE.sm} />}
          onClick={handleShare}
        >
          Поділитись
        </Button>
      )}
      
      <Button
        variant="ghost"
        size="sm"
        icon={<Bot size={ICON_SIZE.sm} />}
        onClick={onDiscussWithAgent}
      >
        Обговорити
      </Button>
      
      {isScanned && (
        <Button
          variant="ghost"
          size="sm"
          icon={<RefreshCw size={ICON_SIZE.sm} />}
          onClick={onReprocess}
        >
          Перерозпізнати
        </Button>
      )}
    </footer>
  );
}
```

### Адаптивність підвалу

```css
.document-viewer__footer {
  display: flex;
  gap: var(--space-1);
  padding: var(--space-2) var(--space-4);
  border-top: 1px solid var(--color-border);
  background: var(--color-surface);
  flex-wrap: wrap;
}

@media (max-width: 768px) {
  .document-viewer__footer {
    justify-content: space-around;
  }
  
  .document-viewer__footer .ui-button {
    min-height: 44px;
  }
}

@media (max-width: 480px) {
  .document-viewer__footer .ui-button__label {
    display: none;
  }
  
  /* На дуже малих екранах — тільки іконки */
}
```

### Критерії приймання TASK 10.5

- 6 кнопок працюють (5 для searchable, 6 з Перерозпізнати для scanned)
- Drive відкриває в новій вкладці
- Завантаження через Drive API з error handling
- Копіювання тільки в text режимі (інакше підказка)
- Share через Web Share API (з fallback)
- Обговорити викликає onDiscussWithAgent з documentId
- Перерозпізнати тільки для scanned

---

## TASK 10.6 — Інтеграція з CaseDossier

### Знайди старий Viewer

В CaseDossier через grep знайди де зараз рендериться правий блок Viewer'а — імовірно навколо `selectedDoc`, `documentBlob`, `pdfPages`. Це може бути inline JSX великий блок.

### Заміни на новий

```jsx
// Було (схематично):
{selectedDoc && (
  <div style={{ /* старий inline-стиль */ }}>
    {/* PDF.js рендеринг inline */}
    {/* Кнопки inline */}
  </div>
)}

// Стало:
import { DocumentViewer } from '../DocumentViewer';

{selectedDoc && (
  <DocumentViewer
    document={selectedDoc}
    caseData={caseData}
    driveToken={driveToken}
    onClose={() => setSelectedDocId(null)}
    onUpdate={(documentId, fields) => {
      executeAction('dossier_agent', 'update_document', {
        caseId: caseData.id,
        documentId,
        fields
      });
    }}
    onOpenDetails={(documentId) => {
      // TASK 11 — поки заглушка
      toast.info('Панель деталей у розробці');
    }}
    onDiscussWithAgent={(documentId) => {
      openAgentPanel({ contextDocumentId: documentId });
    }}
    onReprocess={(driveId) => {
      ocrService.reprocess(driveId, { force: true });
    }}
  />
)}
```

### Видалити старий код

Після того як новий Viewer працює — видали старий inline JSX і пов'язані state змінні якщо не використовуються.

### Критерії приймання TASK 10.6

- Новий DocumentViewer інтегровано замість старого
- Існуючі workflow'и працюють (вибір документа → відкриття → закриття)
- Старий код видалено
- Жоден існуючий тест не зламався

---

## TASK 10.7 — Тести і документація

### Юніт-тести

**`tests/unit/DocumentViewer.test.jsx`**:
- Рендериться з document
- Empty state коли document=null
- Виклик onClose при кліку на ✕
- Зірочка перемикає isKey через onUpdate
- 🔧 викликає onOpenDetails

**`tests/unit/ScanTextToggle.test.jsx`**:
- Рендерить два варіанти
- Активний клас на active
- Виклик onChange при кліку

**`tests/unit/DocumentViewerHeader.test.jsx`**:
- Метадані пропускають відсутні поля
- Перемикач показується тільки для scanned

**`tests/unit/DocumentViewerFooter.test.jsx`**:
- 5 кнопок для searchable, 6 для scanned
- Копіювати disabled в scan режимі
- Share прихований якщо navigator.share відсутній

### Інтеграційні тести

**`tests/integration/documentViewer-workflow.test.jsx`**:
- Відкриття документа → клік ⭐ → onUpdate викликаний з isKey: true
- Перемикання режимів зберігається в localStorage
- Перерозпізнати викликає onReprocess з правильним driveId

### Документація

Створи `src/components/DocumentViewer/README.md`:
- Призначення
- Props таблиця
- Приклади використання
- Залежності (PDF.js, ocrService)
- Логіка scan/text режимів

### Критерії приймання TASK 10.7

- Юніт-тести покривають кожен компонент
- Інтеграційні тести покривають основні workflow'и
- README створено
- `npm test` зелений

---

## SAAS IMPLICATIONS

DocumentViewer параметризовано через props — без хардкоду тенант-специфіки. Підтримує канонічну схему документа з TASK 1, тому будь-який тенант з власною конфігурацією категорій працюватиме.

Перемикач Scan/Text збережений у localStorage (per documentId) — у майбутньому SaaS може мігрувати в registry per user.

---

## BILLING IMPLICATIONS

Перерозпізнання (Перерозпізнати) викликає Document AI — це платна операція. Облік через ai_usage (вже є в системі) — кожне перерозпізнання записується з токенами і вартістю.

---

## КОМІТ І ПУШ

```bash
git commit -m "feat: TASK 10 — new DocumentViewer (Scan/Text toggle, header with metadata, footer with 6 actions, lucide icons, fully responsive)"
git push origin main
```

---

## ОЧІКУВАНІ АРТЕФАКТИ ВИКОНАННЯ

Створи файл звіту `report_task10.md` у корені репо.

### Структура звіту

**Резюме TASK 10** — один абзац

**Реалізація з TASK** — таблиця 10.1-10.7

**Створені файли** — таблиця

**Змінені файли** — CaseDossier (заміна старого Viewer'а)

**Видалені файли** — старий inline-код Viewer'а в CaseDossier

**Тести і покриття**

**Адаптивність** — що зроблено для mobile/tablet

**Знахідки** — discovered_issues_during_task10.md якщо є

**Білд + push**

### Пояснення в термінал для адвоката

Стиль як родичу. Без термінів "компонент", "props", "PDF.js".

Приклад тону:

> Я переробив переглядач документів повністю. Тепер коли ти клікаєш на документ у списку справи — справа з'являється новий, акуратніший Viewer.
>
> **Що нового:**
> - **Перемикач [🖼 Скан] [📝 Текст]** — для сканованих документів. Можна швидко переключитись між картинкою і текстом OCR. Для пошукових PDF (типу позов який ти створив у Word і експортував) — перемикача немає, одразу текст.
> - **Шапка з метаданими** — назва, категорія, автор, провадження, дата, к-ть сторінок, розмір файлу — все одним рядком під назвою.
> - **Зірочка "ключовий документ"** — клік перемикає, без модалки.
> - **Підвал з 6 кнопками** — Drive (відкрити в Drive), Завантажити, Копіювати (тільки в режимі Текст), Поділитись (Web Share API), Обговорити (відкриває агента з контекстом цього документа), Перерозпізнати (тільки для сканів).
>
> **Що ще не зроблено:**
> - Кнопка 🔧 (деталі) поки заглушка — повноцінна панель з усіма канонічними полями для редагування буде в наступному TASK 11.
>
> **Адаптивність:** на планшеті landscape — повний layout. На portrait і мобільному — кнопки з іконками без тексту, перемикач збільшений для пальців.
>
> Тести зелені, білд чистий. Деталі — у `report_task10.md`.

---

## ВЛАСНА АНАЛІТИКА І ТВОРЧЕ ВИКОНАННЯ

Якщо в процесі виявиш:
- PDF.js логіка надто переплетена з CaseDossier — винеси в окремий хук перш ніж DocumentViewer його викличе
- Текст з 02_ОБРОБЛЕНІ не завантажується через Drive API — перевір чи правильна логіка пошуку файлу (NFC normalization, базове ім'я)
- 🔧 Деталі — у TASK не реалізовано (це TASK 11), достатньо placeholder з toast.info
- Web Share API не доступний на десктопі — нормально, кнопка прихована
- localStorage переповнюється модами для всіх документів — додай TTL або limit (наприклад зберігати тільки останні 100)

**Критерій якості:** адвокат відкриває документ і одразу бачить все що треба: яке провадження, яка дата, скільки сторінок. Не треба клікати "більше деталей". Перехід між Скан і Текст — миттєвий. Кнопки внизу очевидні.

Не вважай TASK дзвоном з небес. Адаптуйся.

---

**Кінець TASK 10.**
